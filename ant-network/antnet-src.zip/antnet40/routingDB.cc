// -*- C++ -*-
// Copyright (C) 2003 Leherstuh f�r Betrieb System/ Verteilte System, 
// Universitaet Dortmund 
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

// Author: Muddassar Farooq
// Informatik III, Universitaet Dortmund
// Germany

//-------------------------------------------------------------
// file: routingDB.cpp
// This class calculates the shortest distance 
// in terms of number of hops from a node to all
// destinations
//-------------------------------------------------------------

#include "routingDB.h"

Define_Module(routingDB);

routingDB::~routingDB()
{
	delete hTable;
}

void routingDB::initialize()
{
    debug = false;
    cTopology *topo = new cTopology("topo");

    // this can probably be made more flexible
    topo->extractByModuleType(par("nodeType"), NULL);
    
    if (debug)
      ev << "cTopology found " << topo->nodes() << " nodes\n";

    // find the numbers of hops from all nodes to other nodes and store them
    //
    // note that we do route calculation (call unweightedSingleShortestPathsTo())
    // only n times, while per-node calculation would require n^2 invocations.
    //
    for (int i=0; i<topo->nodes(); i++)
    {
        RTEntry key;
        cTopology::Node *destNode = topo->node(i);
        key.destAddress = destNode->module()->par("address");

        topo->unweightedSingleShortestPathsTo(destNode);

        for (int j=0; j<topo->nodes(); j++)
        {
            if (i==j) continue;
            cTopology::Node *sourceNode = topo->node(j);
            if (sourceNode->paths()==0) continue; // not connected

            key.sourceAddress = sourceNode->module()->par("address");
	    int hops = static_cast<int>(sourceNode->distanceToTarget());

	    if (debug)
	      ev << "  from " << key.sourceAddress << " towards " << key.destAddress << " Hops are " << hops << endl;
	    
            (*hTable)[key] = hops;
        }
    }
    delete topo;
}

int routingDB::getNumberOfIdealHops(int sourceAddress, int destAddress)
{
    RTEntry key;
    key.sourceAddress = sourceAddress;
    key.destAddress = destAddress;

    hopsTable::iterator it = (*hTable).find(key);
    if (it == (*hTable).end() )
	{
        return -1;
	}

    int hops = (*it).second;
    return hops;
}
