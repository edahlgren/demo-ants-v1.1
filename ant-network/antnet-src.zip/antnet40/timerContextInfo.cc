//-------------------------------------------------------------
// file: timerContextInfo.cpp
//        (part of simpleNet Routing Simulation - an OMNeT++ demo simulation)
//-------------------------------------------------------------

#include <string.h>
#include <ostream>
#include "timerContextInfo.h"


Register_Class( timerContextInfo );

timerContextInfo::timerContextInfo(const char *name):cObject()
{
	resendAttempt = 0;
	timerID = 0;
	timerType = 0;
	GateID = 0;
	neighbor = 0;
	msg = NULL;
}



timerContextInfo::timerContextInfo(cMessage *message, const char *name):cObject()
{
	resendAttempt = 0;
	timerID = 0;
	timerType = 0;
	GateID = 0;
	neighbor = 0;

	int kind = message->kind();

	if( kind == (int) NETLAYER_HELLO_PACKET)
	{
		
		msg = (helloAndReplyMessage*) message->dup();

	}

	else
	{
		throw new cException( "Timer Message assocaited to Unknown Type");
	}

}

timerContextInfo::timerContextInfo(const timerContextInfo& rhs):cObject()
{
	this->resendAttempt = 0;
	this->timerID = 0;
	this->timerType = 0;
	this->GateID = 0;
	this->neighbor = 0;
	this->msg = NULL;

	operator=(rhs);

}

timerContextInfo&  timerContextInfo::operator=(const timerContextInfo& rhs)
{
	if( this == &rhs)
	{
		return *this;
	}

	else
	{
		delete msg;
		cObject::operator=(rhs);
		this->resendAttempt = rhs.resendAttempt;
		this->timerID = rhs.timerID;
		this->timerType = rhs.timerType;
		this->GateID = rhs.GateID;
		this->neighbor = rhs.neighbor;

		int kind = rhs.msg->kind();

		if( kind == (int) NETLAYER_HELLO_PACKET)
		{
			
			msg = (helloAndReplyMessage*) rhs.msg->dup();

		}

		else
		{
			throw new cException( "Timer Message assocaited to Unknown Type");
		}
		return *this;
	}
}

timerContextInfo::~timerContextInfo()
{
	delete msg;
}

cObject* timerContextInfo::dup() const
{
	return new timerContextInfo(*this);
}

void timerContextInfo::info(char *buf)
{
	cObject::info(buf);
	sprintf( buf+strlen(buf), "MessageID", msg->kind());
}

void timerContextInfo::writeContents(ostream& os)
{
	os<< "\n ResendAttempts: ";
	os<<resendAttempt;
	os<< "\n timer ID: ";
	os<<timerID;
	os<< "\n timerType: ";
	os<<timerType;
	os<<"\n Gate ID: " << endl;
	os<< GateID;
	os<<"Neighbor : ";
	os<<neighbor;
	msg->writeContents(os);
}

void timerContextInfo::setResendAttempt(int attempts)
{
	resendAttempt = attempts;
}

int timerContextInfo::getResendAttempt()
{
	return resendAttempt;
}

void timerContextInfo::setTimerID(int timer)
{
	timerID = timer;
}

int timerContextInfo::getTimerID()
{
	return timerID;
}

void timerContextInfo::setGateID(int gate)
{
	GateID = gate;
}

int timerContextInfo::getGateID()
{
	return GateID;
}

void timerContextInfo::setTimerType(int type)
{
	timerType = type;
}

int timerContextInfo::getTimerType()
{
	return timerType;
}

void timerContextInfo::setNeighbor(int num)
{
	neighbor = num;
}

int timerContextInfo::getNeighbor()
{
	return neighbor;
}
		
void timerContextInfo::setMsg(cMessage *message)
{
	if(msg != NULL)
	{
		// reclaim memory
		delete msg;
	}
	int kind = message->kind();

	if( kind == (int) NETLAYER_HELLO_PACKET)
	{
		
		msg = (helloAndReplyMessage*) message->dup();

	}
	else
	{
		throw new cException( "Timer Message assocaited to Unknown Type");
	}
}

cMessage* timerContextInfo::getMsg()
{
	int kind = msg->kind();

	if( kind == (int) NETLAYER_HELLO_PACKET)
	{
		
		return (helloAndReplyMessage*) msg->dup();

	}

	else
	{
		throw new cException( "Timer Message assocaited to Unknown Type");
	}
}
