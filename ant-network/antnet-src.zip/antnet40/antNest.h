// -*- C++ -*-
// Copyright (C) 2003 Leherstuh f�r Betrieb System/ Verteilte System,
// Universitaet Dortmund
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

// Author: Muddassar Farooq
// Informatik III, Universitaet Dortmund
// Germany

//-------------------------------------------------------------
// file: antNest.h
//        (part of AntNet Routing Simulation)
//-------------------------------------------------------------

#ifndef __ANT_NEST_H
#define __ANT_NEST_H

#ifdef _MSC_VER

#define STL_USING_ALL
#include "STL.h"
#endif

#include <omnetpp.h>
#include "ant.h"
#include "protocolParameters.h"
#include "routingTable.h"
#include "antSink.h"
#include "router.h"
#include "statistics.h"

#define MAXFLOAT 65356

#define LIFELIMIT 30.0

struct nodeProbPair
{
	int neighbor;
	double value;
};

typedef nodeProbPair nodeProbPair;

class antNest: public cSimpleModule
{
	public:

                antNest() : cSimpleModule() {
                  averageOfTimeToDest = NULL;
                  varianceOfTimeToDest = NULL;
                  bestTimeToDest = NULL;
                  timeWindowSamples = NULL;
                  bestTimeToDestInWindow = NULL;
                }
  
	protected:
                bool logResults;
		double expMeanCoefficient;
		double windowSizeCoefficient;
		double zetaConfidenceLevel;
		double explorationProbablity;
		double rescalingPower;
		double queueWeight;
		double forkProbability;
		double maxHopsCoefficient;
		double squashFunctionCoefficient;
		double probabilisticRouting;
		double timeWeight;
		double ageLimit;
		int hopsLimit;
		int	exponentialWinSize;
		int squreExpWinSize;
		int windowSize;


		int numNodes;
		int numNeighbors;
		int myAddress;

		int queueSize;
		double weightQueue;
		int antsDeleted;


		double *averageOfTimeToDest;
		double *varianceOfTimeToDest;
		double *bestTimeToDest;
		int *timeWindowSamples;
		double *bestTimeToDestInWindow;
		simtime_t converganceTime;

		statistics *sPtr;
		char sFileName[100];

		protoTCB nTcb; //transmission control block

		Ant *current;
		Router *ptr; // we need to access this class
		cMessage *initRouter;


	protected:

		int chooseNextHop(int destination);
		void findSourceForAnt(Ant *msg);
		bool nodeAlreadyVisited(int node);
 		bool doCycleExist(int node);
		bool checkIfAntIsObsoleteThenDelete();
		bool checkIfAntReachedAgeOrHopsLimitThenDelete();
		double getReinforcement(double tripTime, int destNode);
		void rescaleProbabilitiesForDataPackets(int destNode);

		double squashingFunction(int neighbors, double reinf);
		double squashedReinforcement(double reinf);
		void updateLocalTrafficModel(double Tdest, int destNode);
		void updateProbabilityModel(int neighbor, int destNode, double r, bool increment);
	    void updateRoutingTable(int destNode);
		void updateRoutingTableAndTrafficeModelEntries(int destNode, int lastNeighbor, double timeToDest);
		void heuristicCorrectionFactor(int& count, nodeProbPair *hFactor);
		void goodnessForFeasibleLinks(int destNode, int& count, nodeProbPair *goodnessProb);
		double totalDelayOfFeasiblelinks();
		bool allNeighborsVisited();
		bool nodeCycleAlreadyVisited(int node);

		int selectLinkWithHighestGoodness(int count, nodeProbPair *goodnessProb);
		int selectLinkInRandomUniformWay();
		int selectLinkInRandomPropotionalWay(int count, nodeProbPair *goodnessProb);

		int selectLinkInRandomUniformWayAntsGeneratedAtThisNode();

		void initializeNestFromRouter();
		void processBackwardAnts();
		void processForwardAnts();
		bool doForwardAntActions();
		void doBackwardAntActions();
		void selectLinks();


	public:
		virtual ~antNest();

		//virtual functions to be redefined
		virtual void handleMessage(cMessage *msg);
		virtual void finish();
		virtual void initialize();

};

#endif
