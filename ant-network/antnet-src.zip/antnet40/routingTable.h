// -*- C++ -*-
// Copyright (C) 2003 Leherstuh f�r Betrieb System/ Verteilte System, 
// Universitaet Dortmund 
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

// Author: Muddassar Farooq
// Informatik III, Universitaet Dortmund
// Germany

//-------------------------------------------------------------
// file: routingTable.h
//        (part of AntNet Routing Simulation)
//-------------------------------------------------------------

#ifndef __ROUTING_TABLE_H
#define __ROUTING_TABLE_H

#include <iostream>
#include <omnetpp.h>
#include "protocolParameters.h"

class routingTable
{
	public:
		struct RTEntry 
		{
			int neighborPort;
			int destAddress;

			bool operator<(const RTEntry& b) const 
			{
			   return destAddress<b.destAddress || (destAddress==b.destAddress && neighborPort<b.neighborPort);
			}
		};
		typedef map<RTEntry,double> antRoutingTable; // (destaddr via neigbhbor) -> prob


	protected:
		antRoutingTable rTable;


	public:
		routingTable(const char* name = NULL);
		routingTable(const routingTable& rhs);
		routingTable& operator=(const routingTable& rhs);
		virtual ~routingTable();

		void printRoutingTable(int router = 20);
		double getDestViaThisNeighborProb(int dest, int neighbor);
		void setDestViaThisNeighborProb(int dest, int neighbor, double prob);

};

#endif