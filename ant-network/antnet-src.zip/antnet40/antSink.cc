// -*- C++ -*-
// Copyright (C) 2003 Leherstuh f�r Betrieb System/ Verteilte System, 
// Universitaet Dortmund 
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

// Author: Muddassar Farooq
// Informatik III, Universitaet Dortmund
// Germany

//-------------------------------------------------------------
// file: antSink.cpp
//        (part of AntNet Routing Simulation)
//-------------------------------------------------------------

#include <stdio.h>
#include "antSink.h"
#include "Messages_m.h"
#include "ant.h"

Define_Module( antSink );


void antSink::activity()
{

//	eeForwardAntsDelay.setName("End to End Ant Delay Statistics");
//	forwardAntsDelay.setName("End to End Ant Delay");
//	cumForwardAntsThroughPut.setName("Cum througput for forward ants");
//	cumIntervalForwardAntsThroughPut.setName("Intervalthrougput for forward ants");

	eeBackwardAntsDelay.setName("End to End Ant Delay Statistics");
	backwardAntsDelay.setName("End to End Ant Delay");
	cumBackwardAntsThroughPut.setName("Cum througput for Backward ants");
//	cumIntervalBackwardAntsThroughPut.setName("Intervalthrougput for Backward ants");



	cPar& sleepTime = par("sleepTimeAtStart");
	double interval = (double) par("throughputInterval");
	measureThroughPut = new cMessage("measureTPut");
	
	intervalForwardAntsReceivedValue = 0.0;
	intervalBackwardAntsReceivedValue = 0.0;
	cumForwardAntsReceivedValue = 0.0;
	cumBackwardAntsReceivedValue = 0.0;

	const char *statModulePath = par("statModulePath");
	cModule *tmp1 = simulation.moduleByPath(statModulePath);
	sPtr= check_and_cast<statistics *> (tmp1);	
	

	debug = false;
	logResults = par("logResults");


	wait( sleepTime );


	double lastSimTime = simTime();

	//schedule this message

	scheduleAt( lastSimTime + interval, measureThroughPut);

	for(;;)
	{
		// to determine throughput, we need to schedule an even every 
		// INTERVAL seconds

		cMessage *msg = receive();

		// packet received from network and increase the counter

		if(dynamic_cast<Ant *> (msg) != NULL)  
		{
			if( msg->kind() == NETLAYER_FORWARD_ANT)
			{
				// if message is received is network packet then queue it 
				// and get the stastics
				double eed = simTime() - msg->creationTime();
				if(debug)
				{
					ev<< "Received Message" << msg->name() << "End to End Ant Delay" << eed << "sec"<< endl;
				}

				if(logResults)
				{

	//				forwardAntsDelay.record( eed );
	//				eeForwardAntsDelay.collect( eed );
				}
				intervalForwardAntsReceivedValue +=  1.0;
				Ant *aPacket = (Ant*) msg;
				delete aPacket;
			}

			else if( msg->kind() == NETLAYER_BACKWARD_ANT)
			{
				Ant *aPacket = (Ant *) msg;
				int hops = aPacket->getHops();
				ev<<"Hops are: " << hops << endl;
				// if message is received is network packet then queue it 
				// and get the stastics
				double eed = simTime() - msg->creationTime();
				if(debug)
				{
					ev<< "Received Message" << msg->name() << "End to End Ant Delay" << eed << "sec"<< endl;
				}

				if(logResults)
				{
				
					backwardAntsDelay.record( eed );
				    eeBackwardAntsDelay.collect( eed );
				}

 				intervalBackwardAntsReceivedValue +=  1.0;
				sPtr->incrTotalAntsReceived();
				sPtr->incrAntHops( hops);
				sPtr->insertAntLife( eed );
				delete aPacket;
			}

			else
			{
				throw new cException(" Received Unknown Value:Forward/Backward Ant expected");
			}
		}

		else if( msg == measureThroughPut ) //time to measure throughput
		{
			simtime_t currentSimTime = simTime();
			

			double intervalForwardAntsThroughPut = 
				(intervalForwardAntsReceivedValue)/(currentSimTime - lastSimTime);

			double intervalBackwardAntsThroughPut = 
				(intervalBackwardAntsReceivedValue)/(currentSimTime - lastSimTime);

			cumForwardAntsReceivedValue += intervalForwardAntsReceivedValue;
			cumBackwardAntsReceivedValue += intervalBackwardAntsReceivedValue;

			double cumForwardAntsThroughPutValue = cumForwardAntsReceivedValue /currentSimTime;
			double cumBackwardAntsThroughPutValue = cumBackwardAntsReceivedValue /currentSimTime;

			lastSimTime = currentSimTime;
			
			//store the statistics
			if(logResults)
			{

	//			cumForwardAntsThroughPut.record( cumForwardAntsThroughPutValue );
	//			cumBackwardAntsThroughPut.record( intervalBackwardAntsThroughPut);
			}

			intervalForwardAntsReceivedValue = 0.0;
			intervalBackwardAntsReceivedValue = 0.0;
		
			// schedule next throughput measurement event

			scheduleAt( currentSimTime + interval, measureThroughPut);
		}
	}
}


void antSink::finish()
{ 
  if (logResults || debug)
    ev << "*** Module: " << fullPath() << "***" << endl;

/*
  if (logResults) {
    ev << "Total Forward Ants destined at this Router: "<< eeForwardAntsDelay.samples() << endl;
    ev << "Avg Packet Delay:    " << eeForwardAntsDelay.mean() << endl;
    ev << "Max Packet Delay:    " << eeForwardAntsDelay.max() << endl;
    ev << "Standard deviation:   " << eeForwardAntsDelay.stddev() << endl;
    ev << endl; 

    ev << "Total Backward Ants destined at this Router: "<< eeBackwardAntsDelay.samples() << endl;
    ev << "Avg Backward Ant Delay:    " << eeBackwardAntsDelay.mean() << endl;
    ev << "Max Backward Ant Delay:    " << eeBackwardAntsDelay.max() << endl;
    ev << "Standard deviation: Backward Ants  " << eeBackwardAntsDelay.stddev() << endl;
  }
*/
  
  if (debug) {  
    ev << "Stack allocated:      " << stackSize() << " bytes";
    ev << " (includes " << ev.extraStackForEnvir() << " bytes for environment)" << endl;
    ev << "Stack actually used: " << stackUsage() << " bytes" << endl;
  }
  
  if (logResults || debug)
    ev << endl;
}
