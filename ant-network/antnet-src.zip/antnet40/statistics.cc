// -*- C++ -*-
// Copyright (C) 2003 Leherstuh f�r Betrieb System/ Verteilte System, 
// Universitaet Dortmund 
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

// Author: Muddassar Farooq
// Informatik III, Universitaet Dortmund
// Germany

//-------------------------------------------------------------
// file: statisitics.h -- A Singleton Class for Global Statisitics
//        (part of AntNet Routing Simulation)
//-------------------------------------------------------------

#include "statistics.h"

Define_Module( statistics );

statistics::statistics() : cSimpleModule()
{
	totalBitsGenerated = 0;
	totalBitsDelivered = 0;
	totalBitsLost = 0;

	totalAntsGenerated = 0;
	totalAntsDelivered = 0;
	totalAntsDeleted = 0;
	queueDelay = 0;
	qEntries = 0;

	packetDelay = 0;
	pEntries = 0;
	i = 0;
	packetsInQueue = 0;
	hops = 0;
	hEntries = 0;
	antHops = 0;
	aEntries = 0;
	totalBitsUnDelivered = 0;
	bitsGenerated = 0;
	bitsDelivered = 0;
	totalAntsBitsOnNetwork = 0;
	entriesInRoutingTable = 0;
	totalBandWidth = 0;
	totalDownBitsGenerated = 0;

	dEntries = 0;
	antsProcessed = 0;

	eHopsEntries = 0;
}

statistics::~statistics()
{
	map<int,pair<double,double>*>::const_iterator J;

	for(J = tPutMap.begin(); J != tPutMap.end(); J++)
	{
		delete (*J).second;
	}
}

void statistics::initialize()
{
	strcpy(sFileName,par("statFile"));
	numStations = par("numStations");
}

void statistics::incrAntsProcessed()
{
	antsProcessed++;
}

void statistics::incrEntriesInRoutingTable(int entries)
{
	entriesInRoutingTable += static_cast<double> (entries);
}

void statistics::incrTotalBandWidthInNetwork(double bandwidth)
{
	totalBandWidth += bandwidth;
}

void statistics::incrTotalAntBits(double size)
{
	totalAntsBitsOnNetwork += size;
}

void statistics::incrNumHops(int nHops)
{
	hops += nHops;
	hEntries++;
}

void statistics::incrTotalDownBitsGenerated()
{
	totalDownBitsGenerated++;
}

void statistics::incrBitsGenerated(double bits)
{
	bitsGenerated += bits;
}

void statistics::incrBitsDelivered(double bits)
{
	bitsDelivered += bits;
}


void statistics::incrAntHops(int aHops)
{
	antHops += aHops;
	aEntries++;
}

void statistics::incrTotalBitsGenerated()
{
	totalBitsGenerated++;
}

void statistics::incrTotalBitsDelivered()
{
	totalBitsDelivered++;
}

void statistics:: incrTotalBitsLost()
{
	totalBitsLost++;
}

void statistics::incrTotalBitsUndeliverable()
{
	totalBitsUnDelivered++;
}


void statistics:: incrTotalAntsGenerated()
{
	totalAntsGenerated++;
}

void statistics:: incrTotalAntsReceived()
{
	totalAntsDelivered++;
}

void statistics:: incrTotalAntsDeleted()
{
	totalAntsDeleted++;
}

void statistics:: insertQueueDelay(double qDelay)
{
	queueDelay+= qDelay,
	qEntries++;
}

void statistics::insertPacketDelay(double delay)
{
	pDelay.collect(delay);

	packetDelay += delay;
	pEntries++;
}

void statistics::insertAntLife(double lValue)
{
	antLife.collect(lValue);
}

void statistics::incrPacketInQueue(double lPacket)
{
	packetsInQueue += lPacket;
}


void statistics::insertThroughPutPacketDelay(double tPut, double tDelay, int time)
{
	map<int,pair<double,double>*>::iterator I = tPutMap.find(time);
	if( I != tPutMap.end() )
	{
		pair<double,double> &thePair = *((*I).second);
		thePair.first += tPut;
		thePair.second += tDelay;
	}
	else
	{
		pair<double,double> *p = new pair<double,double>(tPut,tDelay);
		tPutMap[time] = p;
	}
}

void statistics::calculateThroughPutPacketDelay(int time)
{
	double totalThroughPut = 0.0;
	int i = 0;
}

double statistics::ninteythPercentile(cStdDev tVal)
{

	double mean = tVal.mean();
	double stdDev = tVal.stddev();
	double z = 1.29;

	double value = mean + z * stdDev;
	return value;
}

void statistics::showStatistics()
{
        int _simTime = simTime();
	totalAntsBitsOnNetwork = totalAntsBitsOnNetwork/_simTime;

	sFile = fopen(sFileName,"w+");

	fprintf(sFile, "Sim Time:  %ds\n", _simTime);
	fprintf(sFile, "Messages Generated:  %.3f\n", totalBitsGenerated); 
	fprintf(sFile, "Messages Received:  %.3f\n", totalBitsDelivered); 
	fprintf(sFile, "Messages Dropped:  %.3f\n", totalBitsLost);
	fprintf(sFile, "Messages Undeliverable:  %.3f\n\n", totalBitsUnDelivered);

	fprintf(sFile, "Packets in Queue:  %.3f\n",packetsInQueue);
	fprintf(sFile, "Percent Received:  %.3f\n\n",(totalBitsDelivered/(totalBitsGenerated-totalBitsUnDelivered-totalDownBitsGenerated)*100.0));

	fprintf(sFile, "Ants Generated:  %.3f\n", totalAntsGenerated); 
	fprintf(sFile, "Ants Received:  %.3f\n",totalAntsDelivered);
	fprintf(sFile, "Ants Dropped:  %.3f\n",totalAntsDeleted);
	fprintf(sFile, "Average Ant Hops:  %.3f\n", (float) antHops/aEntries);
	fprintf(sFile, "Average Ant Life:  %.3f\n", (float) antLife.mean());
	double aLife = ninteythPercentile(antLife);
	fprintf(sFile, "90th Percentile Ant Life:  %.3f\n", aLife);
	fprintf(sFile, "Ants Bits:  %.3f\n\n", (float) totalAntsBitsOnNetwork);
	
	fprintf(sFile, "Total BandWidth:  %.3f\n", (float) totalBandWidth);
	fprintf(sFile, "Control Overhead:  %.3f\n", (float) totalAntsBitsOnNetwork/totalBandWidth*100.0);	
	fprintf(sFile, "Queue Delay:  %.3f\n",queueDelay/qEntries);
	fprintf(sFile, "Packet Delay:  %.3f\n",packetDelay/pEntries);
	double ninteyDelay = ninteythPercentile(pDelay);
	fprintf(sFile, "90th Percentile Packet Delay:  %.3f\n",ninteyDelay);
	fprintf(sFile, "Throughput:  %.3f\n", bitsDelivered/(_simTime*1000000));
	double fHops = (float) hops /hEntries;
	fprintf(sFile, "Average Packet Hops:  %.3f\n", fHops);
	fprintf(sFile, "Entries in Routing Table:  %.3f\n", entriesInRoutingTable/numStations);

	/*
	calculateThroughPutPacketDelay(_simTime);
	for(int k = 0; k < _simTime; k++)
	{
		fprintf(sFile,"%d %.2f\n",k,(*tPutMap[k]).first);
	}

	for(int l = 0; l < _simTime; l++)
	{
		fprintf(sFile,"%d %.4f\n",l,((*tPutMap[l]).second)/numStations);
	}
	*/
	
	fclose(sFile);
}

void statistics::finish()
{
  ev << "*** Module " << fullPath() << " ***" << endl;
  showStatistics();
}

