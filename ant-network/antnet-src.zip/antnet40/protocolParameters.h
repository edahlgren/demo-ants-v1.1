//-------------------------------------------------------------
// file: stateMachine.h
//        (part of simpleNet Routing Simulation - an OMNeT++ demo simulation)
//-------------------------------------------------------------

#ifndef __STATEMACHINE_H
#define __STATEMACHINE_H

#ifdef _MSC_VER

#define STL_USING_ALL
#include "STL.h"
using namespace std;
#endif

#include <omnetpp.h>
#include "statistics.h"
#include "Messages_m.h"
#include "ant_m.h"
#include "ant.h"
#include "tools.h"

const int setFlag = 1;
const int resetFlag = 0;

#define UNIFORM_RANDOM_SELECTION_FAILED -1

/* 
 * This flag controls the two algorithms
 * If this has been defined then the algorithm is AntNet-CO which has
 * the flying ants concepts else it is AntNet-CL, the algorithm that
 * has been discussed in the journal of artificial intelligence
 */


//#define __FLYINGANTS

enum State 
{
	INIT_S = 0,
	NORMAL_S,
	numStates
};

enum Messages
{
	START_UP_MESSAGE = 20,
	HELLO_RESEND_TIMER = 21 ,
	TOPOLOGY_UPDATING_TIMER = 22,
	EOT_TIMER = 24,
	TRANSMIT_PACKET = 100,
};

enum Event
{
    NETLAYER_HELLO_PACKET_EVENT,
    NETLAYER_HELLO_REPLY_PACKET_EVENT,
    NETLAYER_DATA_PACKET_EVENT,
	NETLAYER_FORWARD_ANT_EVENT,
	NETLAYER_BACKWARD_ANT_EVENT,
	END_OF_TRANSMISSION_EVENT,
	START_UP_MESSAGE_EVENT,
	HELLO_RESEND_TIMER_EVENT,
	TOPOLOGY_UPDATING_TIMER_EVENT,
	TRANSMIT_PACKET_EVENT,
	numEvents
};

enum Source
{
	ANT_NEST,
	ANT_GEN,
	ROUTER,
};


struct protocolTCB
{
	Event event;
	State state;
	Source source;

};

typedef protocolTCB protoTCB;

#endif
