//-------------------------------------------------------------
// file: timerContext.h
//        (part of simpleNet Routing Simulation - an OMNeT++ demo simulation)
//-------------------------------------------------------------

#ifndef __TIMER_CONTEXT_INFO_H
#define ___TIMER_CONTEXT_INFO_H

#include <omnetpp.h>
#include "Messages_m.h"

using namespace std;

class timerContextInfo: public cObject
{
	private:
		int resendAttempt;
		int timerID;
		int timerType;
		int GateID;
		int neighbor;

		cMessage *msg;
	public:
		timerContextInfo(cMessage *msg, const char *name = NULL);
		timerContextInfo(const char *name = NULL);
		timerContextInfo(const timerContextInfo& rhs);
		timerContextInfo& operator=(const timerContextInfo& rhs);

		virtual ~timerContextInfo();
		virtual cObject* dup() const;
		virtual void info(char *buf);
		virtual void writeContents(ostream& os);


		void setResendAttempt(int attemps);
		int getResendAttempt();

		void setTimerID(int timer);
		int getTimerID();

		void setTimerType(int type);
		int getTimerType();

		void setNeighbor(int num);
		int getNeighbor();

		void setGateID(int gate);
		int getGateID();
		
		void setMsg(cMessage *rhs);
		cMessage* getMsg();
};

#endif
