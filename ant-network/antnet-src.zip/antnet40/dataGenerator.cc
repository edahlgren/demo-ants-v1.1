// -*- C++ -*-
// Copyright (C) 2003 Leherstuh f�r Betrieb System/ Verteilte System, 
// Universitaet Dortmund 
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

// Author: Muddassar Farooq
// Informatik III, Universitaet Dortmund
// Germany

//-------------------------------------------------------------
// file: dataGenerator.cpp
//        (part of AntNet Routing Simulation)
//-------------------------------------------------------------


#include <stdio.h>
#include "dataGenerator.h"
#include "Messages_m.h"

Define_Module( dataGenerator );

void dataGenerator::initialize()
{
  
    numMessages = par("numMessages");
	myAddress = par("address");
	numStations = par("numStations");
	converganceTime = (double) par("converganceTime");
	sleepTime = par("sleepTimeAtStart");
	factor = par("factor");

	
	length = (double) par("messageLength");
	
	sessionSize = (double) par("sessionSize");

	i = 0;
	
	sessionId=0;
	packetId = 0;

	beginWindow = 0.0;

	destWin.first = generateDestination(numStations);
	destWin.second = (int) RANDOMDESTINATION;

	const char *statModulePath = par("statModulePath");
	cModule *tmp1 = simulation.moduleByPath(statModulePath);
	sPtr= check_and_cast<statistics *> (tmp1);	
	
	debug = false;
	logResults = par("logResults");
	sleep = false;

	hotSpot = (int) par("hotSpot");

	hotSession = new cMessage("hotSession",SEND_HOT_SESSION_P);

	if( hotSpot != -1)
	{
		startTime = (double) par("startTime");
		endTime = (double) par("endTime");
		hotmpia = (double) par("hotmpia");
		scheduleAt( simTime() + startTime , hotSession);
	}
	
	cMessage* sendEventMsg=new cMessage("s", SEND_SCHEDULING_P);

	scheduleAt( simTime()+sleepTime, sendEventMsg);	   	    	  	  
    //cout<<"msia "<<msia<<endl;
}

void dataGenerator::handleMessage(cMessage* msg)
{
	// After Initialization one should stop sending the packets
	// before statisitcs is actually started

	int eventType = msg->kind();

	if(eventType == SEND_HOT_SESSION_P)
	{
		sendHotDestination();
	}

	else if(eventType >= SEND_SCHEDULING_P)
	{   
	  //1. create a session
		if(eventType==SEND_SCHEDULING_P)
		{
			creatSession();

			msia = (double) par("msiaTime");

			scheduleAt( simTime()+ msia, msg);	   	    	  	  
		}
		  //2. generate packet for a seesion
		else
		{
			
			int theSession=eventType-SEND_SCHEDULING_P;
			
			sendForSession(theSession);

			if( session[theSession].second == 0 )
			{
				
				stopSession( theSession, msg );
			}
			else	      
				scheduleSession( theSession, msg );
		}	  
	}

}

void dataGenerator::creatSession()
{
	sessionId++;

	int x;

	// set the selection mode with destination selection
	setDestinationSelectionMode();

	//create a packet to a random destination.
	if(destWin.second == (int) PREVIOUSDESTINATION )
	{
		x = getRandom(10) > 5 ? destWin.first : generateDestination(numStations);

	}
	else if (destWin.second == (int) RANDOMDESTINATION)
	{
		x = generateDestination(numStations);

		destWin.first = x;
	}

	pair<int,int> p(x,sessionSize);

	session[sessionId]=p;

	cMessage* sendEventMsg=new cMessage("s", SEND_SCHEDULING_P+sessionId);

	scheduleAt( simTime()+TIME_SMALLEST_UNIT_DOUBLE, sendEventMsg);	   	    	  	  
}


void dataGenerator::sendForSession(int id)
{  

	char msgname[70];
	i++;
	// select a destinatin randomly (but not the local station)
	// one ensures that we generate a destination address 0-4 and then increase it by 
	// one in case the address is local one or a variant of it

	int dest = session[id].first;

	sprintf(msgname, "Packet%d-Source%d-Destination %d", i, myAddress, dest);

	// create Packet

	length = (double) par("messageLength");

	samplePacket *msg = new samplePacket(msgname);

	msg->setSourceAddress(myAddress);
	msg->setKind( (int) NETLAYER_DATA_PACKET);
	msg->setDestAddress(dest);
	msg->setId(packetId++);
	msg->setSessionId(id);
	msg->setSessionSize(sessionSize);
	msg->setHasPayLoad(true);
	msg->setTimestamp();
	msg->setData("Here is some application dummy data");

	// send this packet on the gate out that is connected to the router at network layer, that
	// will take the routing decisions

	if(debug)
	{
		ev << "Generated application data to send: \"" << msgname << "\", "
			"length=" << length << "bytes, dest=" << dest << endl;
	}

	if(session[id].second >= length*BYTE )
	{
		msg->setLength( BYTE * length);

		session[id].second=session[id].second-BYTE * length;
	}
	else
	{
		msg->setLength(session[id].second);
		session[id].second=0;
	}

	if (simTime() >= converganceTime)
	{
		samplePacket *sendCopy = (samplePacket *) msg->dup();
		send(sendCopy, "toRouter");
	}

	// now send the copy
	send(msg, "toAntGen");
	sPtr->incrTotalBitsGenerated();
	sPtr->incrBitsGenerated( msg->length() );
}

void dataGenerator::scheduleSession(int id, cMessage* msg)
{
  mpia = (double) par("iaTime");
  scheduleAt( simTime()+ mpia, msg);	   	    	  	  
}

void dataGenerator::stopSession(int id, cMessage* msg)
{
  session.erase(id);
  delete msg;
}
int dataGenerator::getRandom(int i)
{
	return intuniform(0,i-1);
}

int dataGenerator::generateDestination(int k)
{
	int dest = intuniform(0,k - 2);
	if(dest >= myAddress) dest++;
	return dest;
}

void dataGenerator::setDestinationSelectionMode()
{
	endWindow = simTime();
	double window = endWindow - beginWindow;

	if( window >= (double) TIMEWINDOW)
	{
		// toggle the destination

		beginWindow = endWindow;

		if(destWin.second == (int) RANDOMDESTINATION)
		{
			destWin.second = (int) PREVIOUSDESTINATION;
		}
		else 
		{
			destWin.second = (int) RANDOMDESTINATION;

		}
	}

	// do not do anything as we need not to toggle our mode
}

void dataGenerator::sendHotDestination()
{
	char msgname[70];
	// select a destinatin randomly (but not the local station)
	// one ensures that we generate a destination address 0-4 and then increase it by 
	// one in case the address is local one or a variant of it

	int dest = hotSpot;
	sprintf(msgname, "Packet%d-Source%d-Destination %d", i, myAddress, dest);

	// create Packet

	length = (double) par("messageLength");

	samplePacket *msg = new samplePacket(msgname);

	msg->setSourceAddress(myAddress);
	msg->setKind( (int) NETLAYER_DATA_PACKET);
	msg->setDestAddress(dest);
	msg->setHasPayLoad(true);
	msg->setTimestamp();
	msg->setData("Here is some application dummy data");
	msg->setLength( BYTE * length);

	samplePacket *sendCopy = (samplePacket *) msg->dup();
	send(sendCopy, "toRouter");

	// now send the copy
	send(msg, "toAntGen");
	sPtr->incrTotalBitsGenerated();
	sPtr->incrBitsGenerated( msg->length() );

	if(simTime() < endTime)
	{
		hotmpia = (double) par("hotmpia");
		scheduleAt( simTime() + hotmpia , hotSession);
	}
}

void dataGenerator::finish()
{
  if (logResults || debug)
    ev << "*** Module: " << fullPath() << "***" << endl;

  if (debug) {  
    ev << "Stack allocated:      " << stackSize() << " bytes";
    ev << " (includes " << ev.extraStackForEnvir() << " bytes for environment)" << endl;
    ev << "Stack actually used: " << stackUsage() << " bytes" << endl;
    ev << "Total Messages Generated are  " << messageGenerated << endl;
  }
  
  if (logResults || debug)
    ev << endl;
}
