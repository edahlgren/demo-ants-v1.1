// -*- C++ -*-
// Copyright (C) 2003 Leherstuh f�r Betrieb System/ Verteilte System, 
// Universitaet Dortmund 
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

// Author: Muddassar Farooq
// Informatik III, Universitaet Dortmund
// Germany


//-------------------------------------------------------------
// file: DataSink.cpp
//        (part of AntNet Routing Simulation)
//-------------------------------------------------------------

#include <stdio.h>
#include "dataSink.h"
#include "Messages_m.h"

Define_Module( dataSink );

void dataSink::initialize()
{
	eePacketDelay.setName("End to End Packet Delay Statistics");
	packetDelay.setName("End to End Packet Delay");
	cumThroughPut.setName("Cum Through Put in bits/sec");

	const char *statModulePath = par("statModulePath");
	cModule *tmp1 = simulation.moduleByPath(statModulePath);
	sPtr= check_and_cast<statistics *> (tmp1);	

	const char *routingDBPath = par("routingDBPath");
	cModule *tmp2 = simulation.moduleByPath(routingDBPath);
	rDB = check_and_cast<routingDB *>(tmp2);	

	debug = false;
	logResults = par("logResults");

	measureThroughPut = new cMessage("measureTPut");
	startMeasuring = new cMessage("startMeasuringTPut");

	pDelay = 0.0;
	numberPackets = 0;

	sleepTime = (double) par("sleepTimeAtStart");
	interval = (double) par("throughputInterval");

	intervalBitsReceivedValue = 0.0;

	scheduleAt( simTime() + sleepTime, startMeasuring);
}

void dataSink::handleMessage(cMessage *msg)
{
	// packet received from network and increase the counter

	if(dynamic_cast<samplePacket *> (msg) != NULL)  
	{
		samplePacket *tmp = (samplePacket*) msg;
		// if message is received is network packet then queue it 
		// and get the stastics
		double eed = simTime() - tmp->creationTime();
		int hops = tmp->getHops();
		int idealHops = rDB->getNumberOfIdealHops(tmp->getSourceAddress(),tmp->getDestAddress());
		int extraHops = hops-idealHops;
		if(debug)
		{
			ev<< "Received Message" << tmp->name() << "End to End Packet Delay is" << eed << "sec"<< endl;
		}
		
		if(logResults)
		{
			packetDelay.record( eed );
			tHops.collect( hops );
			eePacketDelay.collect( eed );
		}


		sPtr->insertPacketDelay( eed );
		sPtr->incrNumHops( hops );
		sPtr->incrTotalBitsDelivered();
		sPtr->incrBitsDelivered(msg->length());
		
		intervalBitsReceivedValue +=  msg->length();
		pDelay += eed;
		numberPackets++;
		int sId = tmp->getSessionId();
		int sSize = tmp->getSessionSize();
		int sAddress = tmp->getSourceAddress();
		int pId = tmp->getId();
		
		delete tmp;
	}

	else if (msg == startMeasuring)
	{
		delete msg;
		lastSimTime = simTime();
		// schedule next throughput measurement event

		scheduleAt( lastSimTime + interval, measureThroughPut);
	}

	else if( msg == measureThroughPut) //do not measure throughput
	{
		simtime_t currentSimTime = simTime();
		

		double intervalThroughPutValue = ( intervalBitsReceivedValue )/(currentSimTime - lastSimTime);
		lastSimTime = currentSimTime;
		cumBitsReceivedValue += intervalBitsReceivedValue;

		double cumThroughPutValue = cumBitsReceivedValue/currentSimTime;
		double averagePacketDelay = 0;
		if(numberPackets != 0.0)
		{
			averagePacketDelay = pDelay/numberPackets;
		}
		pDelay = 0.0;
		numberPackets = 0;

		//store the statistics

		if(logResults)
		{
			cumThroughPut.record( intervalThroughPutValue );
		}

		intervalBitsReceivedValue = 0;
		sPtr->insertThroughPutPacketDelay(intervalThroughPutValue,averagePacketDelay,i);
		i++;

	
		// schedule next throughput measurement event

		scheduleAt( currentSimTime + interval, measureThroughPut);
		

	}
}


void dataSink::finish()
{ 
  if (logResults || debug)
    ev << "*** Module: " << fullPath() << "***" << endl;
  
  if (logResults) {
    ev << "Total Packets destined at this Router: "<< eePacketDelay.samples() << endl;
    ev << "Avg Packet Delay:    " << eePacketDelay.mean() << endl;
    ev << "Max Packet Delay:    " << eePacketDelay.max() << endl;
    ev << "Standard deviation:   " << eePacketDelay.stddev() << endl << endl;
    ev << "Avg Hops:    " << tHops.mean() << endl;
    ev << "Maximum Hops:    " << tHops.max() << endl;
    ev << "Standard deviation of Hops:   " << tHops.stddev() << endl;
  }
  
  if (debug) {
    ev << "Stack allocated:      " << stackSize() << " bytes";
    ev << " (includes " << ev.extraStackForEnvir() << " bytes for environment)" << endl;
    ev << "Stack actually used: " << stackUsage() << " bytes" << endl;
  }
  
  if (logResults || debug)
    ev << endl;
}
