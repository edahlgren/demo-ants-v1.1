// -*- C++ -*-
// Copyright (C) 2003 Leherstuh f�r Betrieb System/ Verteilte System, 
// Universitaet Dortmund 
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

// Author: Muddassar Farooq
// Informatik III, Universitaet Dortmund
// Germany

//-------------------------------------------------------------
// file: router.h
//        (part of AntNet Routing Simulation)
//-------------------------------------------------------------

#ifndef ___ROUTER_H
#define ___ROUTER_H

#include "protocolParameters.h"
#include "buffer.h"
#include "routingTable.h"

const int originalHelloSize = 1024;
const int normalSize = 20;
const double hopsLimitFactor = 1.75;
const double lifeLimit = 10.0;

class Router : public cSimpleModule
{
	private:
		map<int, Buffer*> *qBuffer; // per port one buffer object
		map<int,cMessage*> *msgServiced;
		map<int,cMessage*> *sendControlOrDataPacket;
		map<int,pair<double,double>*> *bandWidthPdelay; 
		map<int,pair<int,int>*> *neighborPortID; // a list of neighbors that are up at this time

		statistics *sPtr;

		bool routerDown;
		bool agentProcTime;
		double contextSwitchTime;


		protoTCB tcb; //transmission control block

		cMessage *startUpMessage;

		int IPAddress;
		int hopsLimit;

		int queueSize;
		int resendAttempts;
		int bHelloSize;
		unsigned long dataRate;
		unsigned int dataPacketLength;
		double qWeightFactor;

		int numNodes;
		int numNeighbors;
		double converganceTime;
		bool probabilisticRouting;
		routingTable *rTable;
		int *neighborAtIndex;

		double startTime;
		double endTime;
		

		bool debug;
		bool logResults;

	protected:
		cFSM fsm;
		enum 
		{
			INIT = 0,
			NORMAL = FSM_Steady(1),

		};
		
		void buildGateIDToNeighborMap();
		Buffer* getBufferForThisPort(int port);
	
	public:
                Router() : cSimpleModule() {
	          qBuffer = new map<int, Buffer*>();
	          neighborPortID = new map<int,pair<int,int>*>();
	          msgServiced = new map<int,cMessage*>();
	          sendControlOrDataPacket = new map<int,cMessage*>();
	          bandWidthPdelay = new map<int,pair<double,double>*>();

	          IPAddress = -1;
	          contextSwitchTime = 0;
	          numNeighbors = 0;
                }  
		virtual ~Router();

		void analyzeEvent(cMessage *msg);
		void performExitInitActions(cMessage *msg);
		void performActionsInNormalState(cMessage *msg);

		void processHelloPacket(helloPacket* msg);
		void processHelloReplyPacket(helloPacket* msg);
		void processDataPacket(samplePacket *msg);
		void processTransmitPacket(cMessage *msg);
		int chooseNextHop(samplePacket *msg);
	
		void enqueHelloPacketInBuffers();
		double estimateTimeToNextNode(int neighbor);
		void initAntRoutingTable(double initial);

		void queueManagementForMessage(cMessage *msg, int port);
		double processMessageWhenQueueIsEmpty(cMessage * msg, int port);
		void processMessageWhenQueueIsNotEmpty(cMessage * msg, int port);
		double transmitPacket(cMessage * msg, int port);
		int findInputGateIDForNeighbor(int node);
		void processForwardAnt(Ant *msg);
		void processBackwardAnt(Ant *msg);
		bool neighborDown(int port);
		void clearAllBuffersOfRouter();
		int getNumNeighbors();
		int getNumNodes();
		int totalQueueLength();
		double getProb(int destination, int neighbor);
		void setProb(int destination, int neighbor, double prob); 
		int findNeighborAtIndex(int index);
		int findIndexForNeighbor(int neighbor);
		int getMyAddress();
		double bitsInQueue(int neighbor);
		int queueLength(int neighbor);
		double getBandwidth(int neighbor);
		int getQueueMaxLen();
		void findSourceForAnt(Ant *msg);
		

		//virtual functions to be redefined
		virtual void initialize();
		virtual void handleMessage(cMessage *msg);
		virtual void finish();
};


#endif
