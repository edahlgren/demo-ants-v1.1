// Copyright (C) 2003 Leherstuh f�r Betrieb System/ Verteilte System, 
// Universitaet Dortmund 
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

// Author: Muddassar Farooq
// Informatik III, Universitaet Dortmund
// Germany

//-------------------------------------------------------------
// file: buffer.cpp
//        (part of AntNet Routing Simulation)
//-------------------------------------------------------------

#include "buffer.h"

Buffer::Buffer(int port, unsigned int qSize)
{
	debug = true;
	portIndex = port;
	queueSize = qSize;
	normalQueueCapacity = 0;
	quickQueueCapacity = 0;
	theQueue = new vector<cMessage*>();
	theQuickQueue = new deque<cMessage*>();

}

Buffer::~Buffer()
{

	this->clear();
	delete theQueue;
	delete theQuickQueue;
}

int Buffer::getPortIndex()
{
	return portIndex;
}

void Buffer::setPortIndex(int value)
{
	portIndex = value;
}

void Buffer::clear(int& antCount, int& dataCount)
{
	//vector<Packet*>* theQueue;//normal buffer
	for(unsigned int i=0; i< theQueue->size(); i++)
	{
		cMessage* p = (*theQueue)[i];
		if( p->kind() == NETLAYER_DATA_PACKET )
		{
			dataCount++;
		}
#ifdef __FLYINGANTS
#else
		else if( p->kind() == NETLAYER_FORWARD_ANT)
		{
			antCount++;

		}
#endif
		normalQueueCapacity -= p->length();
		delete (*theQueue)[i];
	}

	(*theQueue).clear();

	//deque<Packet*>* theQuickQueue;//quick buffer
	while(!theQuickQueue->empty())
	{
		cMessage* p=theQuickQueue->front();
#ifdef __FLYINGANTS
		if( p->kind() == NETLAYER_FORWARD_ANT || p->kind() == NETLAYER_BACKWARD_ANT )
#else
		if(p->kind() == NETLAYER_BACKWARD_ANT )
#endif
		{
			antCount++;
		}

		quickQueueCapacity -= p->length();
		theQuickQueue->pop_back();
	}
}

void Buffer::clear()
{
	//vector<Packet*>* theQueue;//normal buffer
	for(unsigned int i=0; i< theQueue->size(); i++)
	{
		cMessage* p = (*theQueue)[i];
		normalQueueCapacity -= p->length();
		delete (*theQueue)[i];
	}

	(*theQueue).clear();

	//deque<Packet*>* theQuickQueue;//quick buffer
	while(!theQuickQueue->empty())
	{
		cMessage* p=theQuickQueue->front();
		quickQueueCapacity -= p->length();
		theQuickQueue->pop_back();
	}
}


int Buffer::getQuickQueueSize()
{
  return theQuickQueue->size();
}

int Buffer::getNormalQueueSize()
{
  return theQueue->size();
}

int Buffer::getNormalQueueCapacity()
{
	return normalQueueCapacity;
}

int Buffer::getQuickQueueCapacity()
{
	return quickQueueCapacity;
}


bool Buffer::enqueueInNormalQueue(cMessage *p)
{
	int type = p->kind();
	if(theQueue->size() >= queueSize)
	{
#ifdef __FLYINGANTS
		if(type == NETLAYER_DATA_PACKET)
#else
		if(type == NETLAYER_DATA_PACKET || type == NETLAYER_FORWARD_ANT)
#endif
		{
			if(debug)
			{
				ev << "Queue full, DROPPED !" << endl;
			}
			return false;
		}
	}

	p->setTimestamp();
#ifdef __FLYINGANTS
	if( type == NETLAYER_DATA_PACKET)
#else
	if(type == NETLAYER_DATA_PACKET || type == NETLAYER_FORWARD_ANT)
#endif
	{
		theQueue->push_back(p);
		normalQueueCapacity += p->length();
		return true;
	}
	else
	{
		char msg[100];
		sprintf(msg,"Unknown Message in enqueInNormalQueue: %d",type);
		perror(msg);
		exit(-1);
	}
}

bool Buffer::enqueueInQuickQueue(cMessage *p)
{
	int type = p->kind();

	if(theQuickQueue->size() >= queueSize)
	{
#ifdef __FLYINGANTS
		if(type == NETLAYER_FORWARD_ANT || type == NETLAYER_BACKWARD_ANT)
#else
		if(type == NETLAYER_BACKWARD_ANT)
#endif
		{
			if(debug)
			{
				cout << "Priority Queue full, ANT DROPPED !" << endl;
			}
			return false;
		}
		else if (type == NETLAYER_HELLO_PACKET)
		{
			if(debug)
			{
				cout << "Priority Queue full, HELLO DROPPED !" << endl;
			}
			return false;
		}
		else if (type == NETLAYER_HELLO_REPLY_PACKET)
		{
			if(debug)
			{
				cout << "Priority Queue full, REPLY DROPPED !" << endl;
			}
			return false;
		}
	}

	p->setTimestamp();

#ifdef __FLYINGANTS
	if(type == NETLAYER_FORWARD_ANT || type == NETLAYER_BACKWARD_ANT)
#else
	if(type == NETLAYER_BACKWARD_ANT)
#endif
	{
		theQuickQueue->push_back(p);
		quickQueueCapacity += p->length();
		return true;
	}
	else if(type == NETLAYER_HELLO_PACKET || type == NETLAYER_HELLO_REPLY_PACKET)
	{
		theQuickQueue->push_front(p);
		quickQueueCapacity += p->length();
		return true;
	}
	else
	{
		char msg[100];
		sprintf(msg,"Unknown Message in enqueInQuickQueue: %d",type);
		perror(msg);
		exit(-1);
	}
}

bool Buffer::empty()
{
	if( theQuickQueue->empty() && theQueue->empty() )
	{
		return true;
	}
	return false;
}

cMessage* Buffer::fetchNextPacketToSend()
{
	// check whether the priority buffer has some packets to be delivered

	if( !theQuickQueue->empty())
	{
    //get the packet
		cMessage* p=theQuickQueue->front();
		theQuickQueue->pop_front();
		quickQueueCapacity -= p->length();
		return p;

	}

	// check whether data packets are to be delivered

	else if( !theQueue->empty())
	{
		cMessage* p;
 		vector<cMessage*>::iterator I = theQueue->begin();
		p = *I;
		normalQueueCapacity -= p->length();
		theQueue->erase(I);
		return p;
	}

	else
	{
		perror("asked to fetch new packet while buffer is empty");
		exit(-1);
	}
}
