
#########################################################################
# Parse args
#########################################################################

import argparse

parser = argparse.ArgumentParser()
parser.add_argument("data")
parser.add_argument("column")
parser.add_argument("-o", "--output")
parser.add_argument("--add-column-name", action="store_true")
parser.add_argument("--add-count", action="store_true")
args = parser.parse_args()

data_file = args.data
column_name = args.column
output_file = args.output
add_column_name = args.add_column_name
add_count = args.add_count

#########################################################################
# Sanitize args
#########################################################################

import os.path
import sys

if not os.path.isfile(data_file):
    sys.exit('Data file must exist')

labels = []
with open(data_file) as f:
    labels = f.readline().strip().split(',')

colno = -1
for i, col in enumerate(labels):
    if col == column_name:
        colno = i

if colno < 0:
    sys.exit('Cannot find column name in CSV header')
    
if not output_file:
    output_file = 'output.csv'

#########################################################################
# Iterate through the lines of the data file,
# move the label column to the left, and maybe
# modify it.
#########################################################################

with open(data_file) as fin:
    with open(output_file, 'w') as fout:

        idx = 0
        for line in fin:
            # Split the line into CSV elements
            elems = line.rstrip('\n').split(',')
            
            # Bring column data to the front
            elems.insert(0, elems.pop(colno))

            # If not the header, maybe adjust the first
            # element to be a better label
            if idx > 0:
                label = elems[0]
                if add_column_name:
                    label = '%s %s' % (column_name, label)
                if add_count:
                    label = '%s (#%s)' % (label, idx)
                elems[0] = label

            # Write the elements as a line to the output
            fout.write(','.join(elems) + '\n')

            # Increment the counter
            idx += 1

# That's all folks (output file is closed when with is out of scope.
