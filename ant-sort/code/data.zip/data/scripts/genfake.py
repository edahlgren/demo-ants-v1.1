
#########################################################################
# Parse args
#########################################################################

import argparse

parser = argparse.ArgumentParser()
parser.add_argument("-o", "--out-dir")
args = parser.parse_args()

output_dir = args.out_dir

#########################################################################
# Sanitize args
#########################################################################

import os.path
import sys

if not output_dir:
    output_dir = "."

if not os.path.isdir(output_dir):
    sys.exit('Output directory must exist')


#########################################################################
# Define fake data generators
#########################################################################

import math
import random

def fake_docs(output):
    ndocs = 90
    nkeys = 20

    keys = [
        'Computer Graphics',
        'Splines',
        'Mesh',
        'Visualization',
        'Topic Maps',
        'Fisheye Views',
        'Graphs',
        'Artificial Life',
        'Game of Life',
        'Turing',
        'Chaos',
        'Self-organisation',
        'Artificial Intelligence',
        'Bayesian Reasoning',
        'Symbolic',
        'Expert System',
        'Neural Network',
        'Knowledge',
        'Representation',
        'Robot'
    ]
    
    vecs = []
    vec = [0.0 for x in range(nkeys)]
    for j in range(0, ndocs):
        if j < 30:
            for k in range(0, 7):
                vec[k] = float(math.floor(3.0 + random.random()*3.0))
                
            for k in range(k, 20):
                vec[k] = float(math.floor(random.random()*3.0))

        elif j < 60:
            for k in range(0, 7):
                vec[k] = float(math.floor(random.random()*3.0))

            for k in range(7, 12):
                vec[k] = float(math.floor(3.0 + random.random()*3.0))

            for k in range(12, 20):
                vec[k] = float(math.floor(random.random()*3.0))
                
        else:
            for k in range(0, 12):
                vec[k] = float(math.floor(random.random()*3.0))

            for k in range(12, 20):
                vec[k] = float(math.floor(30.0 + random.random()*5.0))

        vecs.append(vec.copy())

    def getclass(j):
        if j < 30:
            return 1
        elif j < 60:
            return 2
        else:
            return 3

    with open(output, 'w') as fout:
        # Write header
        fout.write(','.join(['Class'] + keys) + '\n')

        # Write data vectors
        for i, vec in enumerate(vecs):
            vecstr = ','.join(map(str, vec))
            label = 'Class %d (#%d)' % (getclass(i), i+1)
            fout.write(label + ',' + vecstr + '\n')

#########################################################################
# Write fake data to the output dir
#########################################################################

docs_path = os.path.join(output_dir, 'fake_docs.csv')
fake_docs(docs_path)
