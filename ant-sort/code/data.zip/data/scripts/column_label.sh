#!/bin/bash

DATA_FILE=$1
LABELS_FILE=$2
OUTPUT_FILE=$3

if [ -z "${DATA_FILE}" ]
then
    echo "No data file supplied"
    exit 1
fi

if [ -z "${LABELS_FILE}" ]
then
    echo "No labels file supplied"
    exit 1
fi

if [ -z "${OUTPUT_FILE}" ]
then
    OUTPUT_FILE="output.csv"
fi

# Create the output file with labels
cp $LABELS_FILE $OUTPUT_FILE

# Append the data to the output file
cat $DATA_FILE >> $OUTPUT_FILE
