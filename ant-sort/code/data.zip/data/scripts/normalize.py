#########################################################################
# Parse args
#########################################################################

import argparse

parser = argparse.ArgumentParser()
parser.add_argument("data")
parser.add_argument("-o", "--output")
args = parser.parse_args()

data_file = args.data
output_file = args.output

#########################################################################
# Sanitize args
#########################################################################

import os.path
import sys

if not os.path.isfile(data_file):
    sys.exit('Data file must exist')

if not output_file:
    output_file = 'output.csv'

#########################################################################
# Normalize the data
#########################################################################

import pandas as pd
from sklearn import preprocessing

# Read CSV file into a Pandas data frame
df = pd.read_csv(data_file)

# Get name of first column (index)
col0 = df.columns[0]

# Set it as the row labels, so it's not part of the
# data to be normalized
df = df.set_index(col0)

# Initialize a scaling normalizer
mm_scaler = preprocessing.MinMaxScaler()

# Actually scale the data
array_scaled = mm_scaler.fit_transform(df)

# Create a new data frame with the scaled data, copying
# the column and row names from the original
df_scaled = pd.DataFrame(data=array_scaled,
                         index=df.index,
                         columns=df.columns)

# Write out the normalized data, truncating floats to 6
# decimal points
df_scaled.to_csv(output_file, float_format='%.6f')
