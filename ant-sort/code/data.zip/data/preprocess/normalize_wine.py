import pandas as pd

#########################################################################
# Read data, reduce to data-only matrix
#########################################################################

# Read the wine data into memory
df_wine = pd.read_csv("/root/data/wine.data", header=None)

# Assign column names
column_labels = ["Alcohol", "Malic acid", "Ash", "Alcalinity of ash", "Magnesium", "Total phenols", "Flavanoids", "Nonflavanoid phenols", "Proanthocyanins", "Color intensity", "Hue", "OD280/OD315", "Proline"]
df_wine.columns = ["Class"] + column_labels

# Remove the first column to get a data-only matrix
df_slim = df_wine.drop('Class', 1)

#########################################################################
# Normalize
#########################################################################

# Import a scaler that will scale the data in each column between
# [0, 1], where Euclidean distance is an effective measure of
# similarity
from sklearn import preprocessing
mm_scaler = preprocessing.MinMaxScaler()

# Scale the data
array_scaled = mm_scaler.fit_transform(df_slim)

#########################################################################
# Write to CSV
#########################################################################

# Label rows
def makeClassLabel(c, index):
    return "Class %d (#%d)" % (c, index+1)

row_labels = []
for index, row in df_wine.iterrows():
    row_labels.append(makeClassLabel(row['Class'], index))

df_out = pd.DataFrame(data=array_scaled, index=row_labels, columns=column_labels)
df_out.to_csv("/root/data/wine_normal.csv", float_format='%.6f')
