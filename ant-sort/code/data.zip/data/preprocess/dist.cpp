#include <cxxopts.hpp>
#include <iostream>
#include <fstream>

cxxopts::Options options(char *progname) {
  cxxopts::Options options(progname, " - Test program");
  options.add_options()
    ("i,input", "Name of CSV file containing data vectors", cxxopts::value<std::string>());
  return options;
}

struct data {
  int binsize;
  int bindim;
  std::vector<std::string> binNames;
  std::vector<std::vector<float>> bin;

  float get(int row, int col);
  void print();
  int load(std::string filename);
  float cosine_distance(int vec1, int vec2);
};

float data::get(int row, int col) {
  return bin.at(row).at(col);
}

void data::print() {
  for (int i = 0; i < binsize; i++) {
    for (int j = 0; j < bindim; j++) {
      if (j > 0)
	std::cout << "  ";
      std::cout << get(i, j);
    }
    std::cout << std::endl;
  }
}

std::vector<std::string> splitCommas(std::string str) {
  std::stringstream ss(str);
  std::vector<std::string> result;

  while (ss.good()) {
    std::string substr;
    std::getline(ss, substr, ',');
    result.push_back(substr);
  }

  return result;
}

int data::load(std::string filename) {
  std::ifstream ifs(filename, std::ifstream::in);
  if (!ifs.is_open()) {
    std::cerr << "Failed to open input file" << std::endl;
    return 0;
  }
  
  std::string line;
  if (!std::getline(ifs, line)) {
    std::cerr << "Failed to read first line of input file" << std::endl;
    return 0;
  }
  
  std::vector<std::string> parts = splitCommas(line);
  if (parts.size() < 2) {
    std::cerr << "Malformed CSV file: need at least one dimension" << std::endl;
    return 0;
  }
  
  // Number of dimensions
  bindim = parts.size() - 1;
  
  // Parse the other lines (the actual data vectors).
  binsize = 0;
  while (std::getline(ifs, line)) {
    
    // Split the line into (binName, <v0, v1, v2, ...>)
    parts = splitCommas(line);
    if (parts.size() != bindim + 1) {
      std::cerr << "Malformed CSV file: need consistent dimensions" << std::endl;
      return 0;
    }
    
    // Parse the data vector label.
    std::string binName = parts.at(0);
    
    // Parse data vector.
    std::vector<float> vec;
    for (int i = 0; i < bindim; i++) {
      float d = std::stof(parts.at(i + 1));
      vec.push_back(d);
    }
    
    // Add the data vector.
    binNames.push_back(binName);
    bin.push_back(vec);
    binsize++;
  }
  
  // Check that we parsed at least 2 vectors --- we can't cluster a
  // single data item (actually we can't do much we 2 either, but
  // this is minimal sanity check).
  if (binsize < 2) {
    std::cerr << "Found only one data vector, need at least two" << std::endl;
    return 0;
  }
  
  if (ifs.bad()) {
    std::cerr << "Failed to read from file" << std::endl;
    return 0;
  }

  return 1;
}

float data::cosine_distance(int vec1, int vec2) {
  float dot = 0.0, denom_a = 0.0, denom_b = 0.0;

  for (unsigned int i = 0; i < bindim; ++i) {
    float vec1_i = get(vec1, i);
    float vec2_i = get(vec2, i);

    dot += vec1_i * vec2_i;
    denom_a += vec1_i * vec1_i;
    denom_b += vec2_i * vec2_i;
  }

  float result = dot / (std::sqrt(denom_a) * std::sqrt(denom_b));
  if (result == 1)
    return 0;
  
  return 1 - result;
}

int main(int argc, char ** argv) {
  // Parse args
  cxxopts::Options opts = options(argv[0]);
  std::string inputFile;
  try {
    cxxopts::ParseResult args = opts.parse(argc, argv);
    if (!args.count("input")) {
      std::cerr << "Required option: input" << std::endl;
      exit(1);
    }
    inputFile = args["input"].as<std::string>();
  } catch (const cxxopts::OptionException& e) {
    std::cerr << "Error parsing options: " << e.what() << std::endl;
    exit(1);
  }

  // Load the data
  data d;
  if (!d.load(inputFile)) {
    std::cerr << "Failed to load data from CLI args" << std::endl;
    exit(1);
  }

  int cmp = 0;
  for (int i = 0; i < d.binsize; i++) {
    std::cout << "  " << d.cosine_distance(cmp, i);

    if (((i+1) % 5) == 0)
      std::cout << std::endl;
  }
  std::cout << std::endl;

  // Exit.
  exit(0);
}
