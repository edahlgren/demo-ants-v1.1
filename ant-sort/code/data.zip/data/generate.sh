#!/bin/bash

set -e

DATASET=$1

if [ "$DATASET" = "clean" ]; then
    rm *.csv
    exit 0
fi

if [ -z "$DATASET" ]; then
    DATASET="all"
fi

if [ "$DATASET" = "fake" ] || [ "$DATASET" = "all" ]; then

    # Generate all types of fake data
    echo "Generating fake data:"

    # Execute the script
    python3.6 scripts/genfake.py
    echo "  Created fake_docs.csv"
fi

if [ "$DATASET" = "wine" ] || [ "$DATASET" = "all" ]; then

    # Generate normalized wine data from the UCI wine dataset
    echo "Generating wine data:"

    # Add column labels
    echo "  Adding column labels ..."
    scripts/column_label.sh repo/wine.data repo/wine.labels col_labeled.csv

    # Add row labels
    echo "  Adding row labels ..."
    python3.6 scripts/row_label.py col_labeled.csv "Class" -o row_labeled.csv --add-column-name --add-count
    
    # Normalize the data
    echo "  Normalizing data ..."
    python3.6 scripts/normalize.py row_labeled.csv -o wine.csv

    # Remove temporary files
    echo "  Removing temporary files ..."
    rm col_labeled.csv
    rm row_labeled.csv
    echo "  Created wine.csv"
fi
