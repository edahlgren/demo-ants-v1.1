/*  Ant-based Clustering
    Copyright (C) 2004 Julia Handl
    Email: Julia.Handl@gmx.de

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "databin.h"

data::data(conf *c) {
  dimensions = c->bindim;
  color = 0;
  cluster = 0;

  vector = new float[dimensions];
  for (int i = 0; i < dimensions; i++) {
    vector[i] = 0;
  }
}

data::data(conf *c, float *d) {
  dimensions = c->bindim;
  color = 0;
  cluster = 0;
  
  vector = new float[dimensions];
  for (int i = 0; i < dimensions; i++) {
    vector[i] = d[i];
  }
}

data::data(conf *c, float *d, int col, int cl) {
  dimensions = c->bindim;
  color = col;
  cluster = cl;
  
  vector = new float[dimensions];
  for (int i = 0; i < dimensions; i++) {
    vector[i] = d[i];
  }
}

data::~data() {
  delete [] vector;
}

const int data::length() {
  dimensions;
}

float data::square(float x) {
  return x*x;
}

float &data::operator[](const int i) {
  return vector[i];
}

const float data::distanceto(data &dd) {
  // Computes the Euclidean distance only.
  data &d = (data &)dd;
  float result = 0.0;

  for (int i = 0; i < dimensions; i++) {
    result += square(d.vector[i] - vector[i]);
  }
  return sqrt(result);
}

void data::add(data &d) {
  for (int i = 0; i < dimensions; i++) {
	  vector[i] = d.vector[i];
  }
}

void data::div(int divisor) {
  for (int i=0; i < dimensions; i++) {
    vector[i] /= double(divisor);
  }
}

void data::set(data &d) {
  for (int i=0; i < dimensions; i++) {
	  vector[i] = d.vector[i];
  }
}

void data::set(float *d) {
  for (int i=0; i < dimensions; i++) {
	  vector[i] = d[i];
  }
}

// Added: Pass in data** via conf->datavecs.
databin::databin(conf * c) {
    par = c;

    // Copy conf.bin -> databin.bin
    bin = new data*[par->binsize];
    if (bin == NULL) {
      cerr << "Databin: Memory allocation failed" << endl;
      exit(1);
    }
    
    for (int i = 0; i < par->binsize; i++) {
      // Copy conf->bin[i] -> this.bin[i] wrapped in class data
      std::vector<float> &vec = par->bin.at(i);
      bin[i] = new data(par, &vec[0]);
      if (bin[i] == NULL) {
        cerr << "Databin: Memory allocation failed" << endl;
        exit(1);
      }
    }
    
    distancematrix = new tmatrix(par->binsize);
    if (distancematrix == NULL) {
      cerr << "Databin: Memory allocation failed" << endl;
      exit(0);
    }

    // Precompute distances and means.
    par->mu = 0.0;
    par->max = 0.0;
    
    for (int i=0; i<par->binsize; i++) {
      for (int j=0; j<i; j++) {
        (*distancematrix)(i,j) = bin[i]->distanceto(*(bin[j]));
        par->mu += (*distancematrix)(i,j);
        par->max = max(par->max, (*distancematrix)(i,j));
      }
    }
    par->mu /= 0.5*(par->binsize-1)*par->binsize;

    // Normalize the data.
    for (int i=0; i<par->binsize; i++) {
      for (int j=0; j<i; j++) {
        (*distancematrix)(i,j) = (*distancematrix)(i,j) / par->max;
      }
    }
    par->max /= par->max;
    par->mu /= par->max;
}

databin::~databin() {
  for (int i=0; i<par->binsize; i++) {
    delete bin[i];
  }
  delete [] bin;
  delete distancematrix;
}

const float databin::d(const int index1, const int index2) {
  return bin[index1]->distanceto(*bin[index2]);
}

const float databin::precomputed_d(const int index1, const int index2) {
  return (*distancematrix)(index1,index2);
}

data &databin::operator[](const int i) {
    return *bin[i];
}
