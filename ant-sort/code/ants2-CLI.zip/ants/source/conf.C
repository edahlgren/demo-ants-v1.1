/*  Ant-based Clustering
    Copyright (C) 2004 Julia Handl
    Email: Julia.Handl@gmx.de

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include "conf.h"

std::vector<std::string> splitCommas(std::string str) {
  std::stringstream ss(str);
  std::vector<std::string> result;

  while (ss.good()) {
    std::string substr;
    std::getline(ss, substr, ',');
    result.push_back(substr);
  }

  return result;
}

int conf::load(cxxopts::ParseResult args) {
  if (loaded) {
      cerr << "Cannot load configuration twice" << endl;
      exit(1);
  }

  /////////////////////////////////////////////////////
  // Data parameters
  /////////////////////////////////////////////////////

  if (!args.count("input")) {
    cerr << "Required option: input" << endl;
    return loaded;
  }
  
  dataFile = args["input"].as<std::string>();
  
  // Parse the data file into:
  //
  // float **bin;
  // int binsize;
  // int bindim;
  // vector<string> binNames;
  // int imax;
  // int jmax;

  // Try to open the file.
  std::ifstream ifs(dataFile, std::ifstream::in);
  if (!ifs.is_open()) {
    cerr << "Failed to open input file" << endl;
    return loaded;
  }

  // Parse the first line (CSV header) to get number of dimensions.
  // The dimension labels are ignored but could be kept around for
  // debugging and labeling results.
  std::string line;
  if (!std::getline(ifs, line)) {
    cerr << "Failed to read first line of input file" << endl;
    return loaded;
  }

  std::vector<std::string> parts = splitCommas(line);
  if (parts.size() < 2) {
    cerr << "Malformed CSV file: need at least one dimension" << endl;
    return loaded;    
  }

  // Number of dimensions
  bindim = parts.size() - 1;
    
  // Parse the other lines (the actual data vectors).
  binsize = 0;
  while (std::getline(ifs, line)) {

    // Split the line into (binName, <v0, v1, v2, ...>)
    parts = splitCommas(line);
    if (parts.size() != bindim + 1) {
      cerr << "Malformed CSV file: need consistent dimensions" << endl;
      return loaded;    
    }

    // Parse the data vector label.
    std::string binName = parts.at(0);

    // Parse data vector.
    std::vector<float> vec;
    for (int i = 0; i < bindim; i++) {
      float d = std::stof(parts.at(i + 1));
      vec.push_back(d);
    }

    // Add the data vector.
    binNames.push_back(binName);
    bin.push_back(vec);
    binsize++;
  }

  // Sanity check.
  if (binsize != bin.size()) {
    cerr << "Bug: binsize (" << binsize << ") does not match number of parsed data vectors (" << bin.size() << ")" << endl;
    return loaded;
  }

  // Check that we parsed at least 2 vectors --- we can't cluster a
  // single data item (actually we can't do much we 2 either, but
  // this is minimal sanity check).
  if (binsize < 2) {
    cerr << "Found only one data vector, need at least two" << endl;
    return loaded;
  }
  
  if (ifs.bad()) {
    cerr << "Failed to read from file" << endl;
    return loaded;
  }
  
  /////////////////////////////////////////////////////
  // ACCL parameters
  /////////////////////////////////////////////////////

  if (!args.count("num-ants")) {
    colonysize = 10;
  } else {
    colonysize = args["num-ants"].as<int>();
  }

  if (!args.count("ant-memory")) {
    memorysize = 10;
  } else {
    memorysize = args["ant-memory"].as<int>();
  }

  if (!args.count("neighborhood")) {
    initradius = 1;
  } else {
    initradius = args["neighborhood"].as<int>();
  }

  if (!args.count("runs")) {
    generations = 50;
  } else {
    generations = args["runs"].as<int>();
  }

  if (!args.count("iterations")) {
    generation_length = 40000;
  } else {
    generation_length = args["iterations"].as<int>();
  }

  if (!args.count("speed")) {
    maxspeed = 50;
  } else {
    maxspeed = args["speed"].as<int>();
  }
    
  /////////////////////////////////////////////////////
  // Grid parameters
  //
  // Can probably choose the minimum/maximum values
  // from the data itself.
  /////////////////////////////////////////////////////

  if (!args.count("grid-width")) {
    imax = (int)sqrt(double(binsize * 10));  
  } else {
    imax = args["grid-width"].as<int>();
  }

  if (!args.count("grid-height")) {
    // Make a square by default.
    jmax = imax;
  } else {
    jmax = args["grid-height"].as<int>();
  }

  // Done!
  loaded = 1;
  
  return loaded;
}
