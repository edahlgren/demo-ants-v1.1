/*  Ant-based Clustering
    Copyright (C) 2004 Julia Handl
    Email: Julia.Handl@gmx.de

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

/***************************************************

date: 7.4.2003

author: Julia Handl (julia.Handl@gmx.de)

description: 
- wrapper class for data
- data input
- data normalisation
- precomputation of dissimilarity matrix

***************************************************/

#ifndef DATABIN_JH_2003
#define DATABIN_JH_2003

#include "conf.h"
#include "tmatrix.h"
#include "databin.h"
#include <fstream>
#include <cstdlib>
#include "math.h"
#include "random.h"
#include "string.h"

using namespace std;

// Not sure what these are for, but leaving for now.

#define NRANSI
#define MAXBIT 30
#define MAXDIM 6
static int iminarg1,iminarg2;
#define IMIN(a,b) (iminarg1=(a),iminarg2=(b),(iminarg1) < (iminarg2) ? (iminarg1) : (iminarg2))

///////////////////////////////////////////////////////////////////////////
// Concrete version data class: wraps a vector of floats
///////////////////////////////////////////////////////////////////////////

class data {

 private:
  float * vector;
  int dimensions;
  
 public:
  // (supervised)
  int color;
  int cluster;
  
 public:
  ~data();
  
  // Default constructor
  data(conf * c);
    
  // Constructor for a data item that is initialized to the vector <d>
  // (unsupervised)
  data(conf *c, float *d);

  // Constructor for a data item that is initialized to the vector <d> and 
  // assigned  cluster number <cluster> and color <color>
  // (supervised)
  data(conf *c, float *d, int color, int cluster);

  // Length of data vector.
  const int length();

  // Squares x.
  float square(float x);

  // Read/Write access to a float in the vector.
  float &operator[](const int i);

  // Distance computation between d and this vector.
  const float distanceto(data &d);

  // Add d to this vector.
  void add(data &d);

  // Divide this vector by i.
  void div(int i);

  // Overwrite this vector with d.
  void set(data &d);
  void set(float *d);
};

///////////////////////////////////////////////////////////////////////////
// Concrete version databin class: wraps an array of vectors of floats
///////////////////////////////////////////////////////////////////////////

class databin {

 protected:
  // Pointer to configuration.
  conf *par; 

  // Array of data vectors.
  data **bin;   

 public:
  // Precomputed dissimilarity matrix.
  tmatrix *distancematrix;

  // Removed: maxvalue, minvalue, mean, std

  databin(conf *c);
  ~databin();

  // On the fly distance computation between two vectors.
  const float d(const int index1, const int index2);

  // Get cached distance between two vectors.
  const float precomputed_d(const int index1, const int index2);

  // Read/Write access to vectors.
  data &operator[](const int i);

  // Removed: find, regenerate, permutate
};

#endif
