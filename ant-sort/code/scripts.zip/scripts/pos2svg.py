
#########################################################################
# Parse args
#########################################################################

import argparse

parser = argparse.ArgumentParser()
parser.add_argument("positions")
parser.add_argument("-o", "--output")
args = parser.parse_args()

positions_file = args.positions
output_file = args.output

#########################################################################
# Sanitize args
#########################################################################

import os.path
import sys

if not os.path.isfile(positions_file):
    sys.exit('Positions file must exist')

if not output_file:
    output_file = 'positions.svg'

#########################################################################
# Parse the data from the positions file 
#########################################################################

import re

pattern = "Class \d+ \(#\d+\)"
def canonical_class(label):
    if re.match(pattern, label):
        return True
    return False

# Map canonical class numbers to colors
color_map = {}
coloridx = 0
color_names = [
    "red",
    "blue",
    "yellow",
    "green",
    "orange",
    "purple",
    "cyan",
    "magenta",
]

# Save grid size and data positions
imax = 0
jmax = 0
data = []

with open(positions_file) as fin:

    idx = 0
    for line in fin:
        # Split the line into CSV elements
        elems = line.rstrip('\n').split(',')
        if len(elems) != 3:
            sys.exit('Need exactly 3 comma-separated data elements per line')
            
            
        # Handle the header
        if idx == 0:
            # Find the number in "X(#)"
            m = re.search('\d+', elems[1])
            imax = int(m.group(0))
            
            # Find the number in "Y(#)"
            m = re.search('\d+', elems[1])
            jmax = int(m.group(0))
            
        # Handle the data lines
        else:
            label = elems[0]

            # Canonical class? We can color-code then
            if canonical_class(label):
                m = re.search('(?<=Class )\d+', label)
                classidx = int(m.group(0))
                if not classidx in color_map:
                    color_map[classidx] = coloridx
                    coloridx += 1

            # Nope, just use a single color
            else:
                if not 1 in color_map:
                    color_map[1] = coloridx

            _coloridx = color_map[classidx]
            if _coloridx >= len(color_names):
                sys.exit('Supports only 8 unique colors, too many class types')

            color = color_names[_coloridx]

            # Append the data
            data.append([color, int(elems[1]), int(elems[2])])
            
        idx += 1

#########################################################################
# Create the SVG plot
#########################################################################

scale = 5

headerTemplate = "<svg width=\"%d\" height=\"%d\" viewBox=\"0 0 %d %d\" xmlns=\"http://www.w3.org/2000/svg\">"

circleTemplate = "  <circle id=\"circle-%d\" cx=\"%d\" cy=\"%d\" r=\"1\" fill=\"%s\" stroke=\"grey\" stroke-width=\"0.25px\" />"

with open(output_file, 'w') as fout:

    # Write SVG header
    header = headerTemplate % (imax * scale, jmax * scale, imax * scale, jmax * scale)
    fout.write(header + '\n')

    # Write SVG circles as data points
    for i, d in enumerate(data):
        color = d[0]
        xpos = d[1]
        ypos = d[2]
        circle = circleTemplate % (i+1, xpos * scale, ypos * scale, color)
        fout.write(circle + '\n')

    # Write SVG footer
    fout.write('</svg>\n')
