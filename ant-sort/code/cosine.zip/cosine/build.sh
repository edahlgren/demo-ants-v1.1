g++ -I. -g -O2 -finline-functions -std=c++11 dist.cpp -o dist
