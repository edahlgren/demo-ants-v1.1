# This should really be a Makefile that attempts to compile everything,
# include the picocli files.

javac -sourcepath javaants:javaants/topicmap:javaants/exception:picocli picocli/*.java
javac -sourcepath javaants:javaants/topicmap:javaants/exception:picocli javaants/*.java
javac -sourcepath javaants:javaants/topicmap:javaants/exception:picocli javaants/exception/*.java
javac -sourcepath javaants:javaants/topicmap:javaants/exception:picocli javaants/topicmap/*.java

jar cfe ant-cluster.jar javaants.topicmap.JavaAntsCLI javaants picocli
