/*  
    Copyright (C) 2004 Julia Handl
    Email: Julia.Handl@gmx.de

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

/*****************************************************************
	Julia Handl - 18004385
	Monash University, 1.7.2001

	File: Save.java
	Package: JavaAnts.TopicMap

	Description:

	* Action Listener: Makes parameter changes of ConfDialog valid 
	  (i.e. modifies the corrseponding configuration object)
		
                                                                                                                        	
*****************************************************************/

package javaants.topicmap;

import java.awt.event.*;
import javaants.Document;
import javaants.Configuration;
import java.awt.*;

/** Triggers update of paramter settings, attached with save button of configuration dialog
*/
public class Save implements ActionListener {
	private Configuration conf;
	private ConfDialog dialog;
	private Frame frame;
	private TopicMap map;
	
	

	
/*********** Constructor ************************************************************************************/

	/** Constructor
	* @param conf the current paramter setting
	* @param dialog the parent confoguration dialog
	* @param frame a parent frame
	* @param map the current topic map (might have to be updated)
	*/
	public Save(Configuration conf, ConfDialog dialog, Frame frame, TopicMap map) {
		this.dialog = dialog;
		this.conf = conf;
		this.frame = frame;
		this.map = map;
	
	}



	/** Write new parameter settings and trigger map update if necessary */
	public void actionPerformed(ActionEvent evt) {

			// make changes valid
			conf.setspeed(dialog.getspeed());
			conf.setxsize(dialog.getxsize());
			conf.setysize(dialog.getysize());
			conf.setmemsize(dialog.getmemsize());
			conf.setruns(dialog.getruns());
			conf.setnants(dialog.getnants());
			conf.setkd(dialog.getkd());
			conf.setkp(dialog.getkp());
			conf.setalpha(dialog.getalpha());
			conf.setsigma(dialog.getsigma());
			conf.setndocs(dialog.getndocs());
			conf.setnkeys(dialog.getnkeys());
			conf.sethomogenous(dialog.gethomogenous());
			conf.setchoice(dialog.getchoice());
			conf.setAdaptAlpha(dialog.getadaptalpha());

	
			
			conf.save();

		
			// if the map is not generated for the first time
			// then remove the old one
			if (map != null) frame.remove(map);		
			
		
	
	}
}     
