/*  
    Copyright (C) 2004 Julia Handl
    Email: Julia.Handl@gmx.de

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

/*****************************************************************

Erin Dahlgren, 07/2019

* CLI
                                                                                                                     	
*****************************************************************/

package javaants.topicmap;

import picocli.CommandLine;
import picocli.CommandLine.Option;

import javaants.*;
import javaants.exception.*;
import java.lang.*;
import java.util.*;
import java.util.stream.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;

// TODO --- Add preprocessing step that takes a directory of documents
// and does the TF-IDF step based on a set of keywords, generating the
// matrix input data.

// TODO --- Add hover capabilities to the SVG by writing out an actual
// html with CSS that embeds the scattered and output SVG.

class CLI {

    // TODO --- Add descriptions.

    ///////////////////////////////////////////////////////////////
    // For generating test data.
    ///////////////////////////////////////////////////////////////

    @Option(names = "--generate-fake-data", description = "TODO")
    File testGenFile;

    // TODO --- Fill out the color map file for the test data.
    
    @Option(names = "--with-colors", description = "TODO")
    File colorMapFile;

    ///////////////////////////////////////////////////////////////
    // For running the algorithm.
    ///////////////////////////////////////////////////////////////

    @Option(names = { "-i", "--input"}, description = "TODO")
    File inputFile;

    // TODO --- Fill out the scattered file with the positions
    // of the documents pre algorithm post scatter.

    @Option(names = { "-s", "--scattered"}, description = "TODO")
    File scatteredFile;
    
    @Option(names = { "-o", "--output"}, description = "TODO")
    File outputFile;

    @Option(names = {"-a", "--algo"}, description = "TODO")
    String algo = "default";

    // TODO --- Add more options that can be controlled on the
    // command line.
    
    ///////////////////////////////////////////////////////////////
    // For visualizing the output.
    ///////////////////////////////////////////////////////////////
    
    @Option(names = "--svg", description = "TODO")
    boolean convertSVG;
    
    @Option(names = "--color-map", description = "TODO")
    File colorMap;

    ///////////////////////////////////////////////////////////////
    // For general help
    ///////////////////////////////////////////////////////////////

    @Option(names = {"-h", "--help"}, usageHelp = true, description = "Display this help message")
    boolean helpRequested;

    ///////////////////////////////////////////////////////////////
    // Default file names
    ///////////////////////////////////////////////////////////////

    String defaultTestGenFile = "data.csv";
    String defaultScatteredFile = "scattered.csv";
    String defaultOutputFileCSV = "output.csv";
    String defaultOutputFileSVG = "output.svg";
}

///////////////////////////////////////////////////////////////
// Main CLI entrypoint
///////////////////////////////////////////////////////////////

public class JavaAntsCLI {
    
    public static void main(String args[]) {
	
	// Parse the CLI args.
	CLI cli = new CLI();
	CommandLine commandLine = new CommandLine(cli);
	commandLine.parse(args);

	// Handle help flag.
	if (cli.helpRequested) {
	    // Print useful guide.
	    commandLine.usage(System.out);

	    // Exit.
	    System.exit(0);
	}

	// Write out fake test data and exit?
	if (cli.testGenFile != null) {
	    // Generate new test data.
	    Data data = generateData();

	    // Write it out.
	    boolean ok = writeData(cli.testGenFile, data);

	    // Exit.
	    System.exit(ok ? 0 : 1);
	}

	// Convert CSV output of algorithm to SVG and exit?
	if (cli.convertSVG) {
	    if (cli.inputFile == null) {
		System.err.println("Need input file (document positions) to convert to SVG.");
		System.exit(1);
	    }
	    if (cli.outputFile == null) {
		cli.outputFile = new File(cli.defaultOutputFileSVG);
		
		if (cli.outputFile == null) {
		    System.err.println("Failed to open any output file");
		    System.exit(1);		
		}
	    }

	    boolean ok = convertToSVG(cli.inputFile, cli.outputFile, cli.colorMap);
	    System.exit(ok ? 0 : 1);
	}

	// Run the demo using an input file?
	if (cli.inputFile != null) {
	    // Parse data from file.
	    Data data = parseData(cli.inputFile);
	    if (data == null) {
		System.err.println("Failed to parse matrix data from file");
		System.exit(1);
	    }

	    // Parse and print the configuration.
	    Configuration config = makeConfig(data, cli.algo);
	    if (config == null) {
		System.err.println("Failed parse options for config");
		System.exit(1);		
	    }
	    System.out.println(config.toString());
	    
	    // Run the algorithm.
	    TopicMap map = runAnts(config, data);

	    // Fixup output file if needed.
	    if (cli.outputFile == null) {
		cli.outputFile = new File(cli.defaultOutputFileCSV);
		
		if (cli.outputFile == null) {
		    System.err.println("Failed to open any output file");
		    System.exit(1);		
		}
	    }

	    // Write the document positions to the output file.	    
	    boolean ok = writePositions(cli.outputFile, map);
	    
	    // Exit.
	    System.exit(ok ? 0 : 1);
	}

	// Whoops, look like no options were given.
	System.err.println("Did nothing, no options given :/");
	System.exit(0);
    }

    private static Configuration makeConfig(Data data, String algo) {
	Configuration config = new Configuration();

	// Setup document options.
	config.setnkeys(data.getnkeys());
	config.setndocs(data.getndocs());

	// Setup algorithm options.
	switch (algo) {
	case "default":
	    config.setMethod(0);
	    break;
	case "hybrid":
	    config.setMethod(1);
	    break;
	default:
	    System.err.println("Algorithm must be 'default' or 'hybrid'");
	    return null;
	}

	return config;
    }
     
    private static TopicMap runAnts(Configuration config, Data data) {
	// Run with ants.
	boolean antMode = true;
	
	// Get keywords and documents.
	String[] keywords = data.getKeys();
	Document[] documents = data.getDocs();

	// ??
	DistanceMatrix d = null;

	// Create a TopicMap that doesn't paint.
	TopicMap map = new TopicMap(config, keywords, documents, antMode, d);
	map.dontPaint = true;
	
	// Run the algorithm until it finishes.
	map.run();
	
	return map;
    }

    private static boolean convertToSVG(File input, File output, File colorMap) {
	int xmax, ymax, ndocs;
	Document[] docs;
	
	// Parse the csv file into documents.
	try (BufferedReader reader = new BufferedReader(new FileReader(input))) {
	    
	    String line = reader.readLine();
	    if (line == null) {
		System.err.println("Failed to read CSV header");
		return false;
	    }

	    java.util.List<String> header = Arrays.asList(line.split(","));
	    if (header.size() < 3) {
		System.err.println("Malformed CSV file: need at least 3 columns");
		return false;
	    }

	    // Parse the number of documents.
	    String[] parts = header.get(0).split("\\.");
	    if (parts.length != 2) {
		System.err.println("Malformed CSV header: need Documents.#, where # is the number of documents in the file");
		return false;		
	    }
	    ndocs = Integer.parseInt(parts[1]);

	    // Initialize the documents array.
	    docs = new Document[ndocs];

	    // Parse the X max.
	    parts = header.get(1).split("\\.");
	    if (parts.length != 2) {
		System.err.println("Malformed CSV header: need X.#, where # is the width of the X.Y grid");
		return false;		
	    }
	    xmax = Integer.parseInt(parts[1]);

	    // Parse the Y max.
	    parts = header.get(2).split("\\.");
	    if (parts.length != 2) {
		System.err.println("Malformed CSV header: need Y.#, where # is the height of the X.Y grid");
		return false;		
	    }
	    ymax = Integer.parseInt(parts[1]);

	    int j = 0;
	    while ((line = reader.readLine()) != null) {
		// Split the row into parts.
		java.util.List<String> row = Arrays.asList(line.split(","));
		if (row.size() != 3) {
		    System.err.println("Malformed CSV file: need 3 columns per row");
		    return false;
		}

		String name = row.get(0);
		int xpos = Integer.parseInt(row.get(1));
		int ypos = Integer.parseInt(row.get(2));

		Document doc = new Document();
		doc.name = name;
		doc.setPosition(xpos, ypos);

		docs[j] = doc;
		j++;
	    }	    

	    if (j != ndocs) {
		System.err.println("Malformed CSV header: failed to parse all documents");
		return false;		
	    }
	    
	} catch (IOException e) {
	    System.err.println("Failed to parse input CSV file");
	    System.err.println(e.getMessage());
	    return false;
	}
	
	// Parse the color map if available.
	if (colorMap != null) {
	    try (BufferedReader reader = new BufferedReader(new FileReader(colorMap))) {

		// Skip the header.
		String line = reader.readLine();

		// Parse the colors for the documents.
		int j = 0;
		while ((line = reader.readLine()) != null) {
		    java.util.List<String> row = Arrays.asList(line.split(","));
		    if (row.size() != 2) {
			System.err.println("Malformed CSV file: need 3 columns per row");
			return false;
		    }
		    
		    String color = row.get(1);
		    docs[j].setColorName(color);
		    j++;
		}

		if (j != ndocs) {
		    System.err.println("Malformed or mismatched CSV color map: failed to find all documents");
		    return false;		
		}
		
	    } catch (IOException e) {
		System.err.println("Failed to parse color map CSV file");
		System.err.println(e.getMessage());
		return false;
	    }
	}

	return writeSVG(docs, xmax, ymax, output);
    }

    private static boolean writeSVG(Document[] docs, int xmax, int ymax, File output) {

	// Lines of the SVG file.
	java.util.List<String> svgLines = new ArrayList<String>();

	// Add the header.
	String svgHeader = String.format("<svg width=\"%d\" height=\"%d\" viewBox=\"0 0 %d %d\" xmlns=\"http://www.w3.org/2000/svg\">",
					 xmax*2, ymax*2, xmax, ymax);
	svgLines.add(svgHeader);

	// Add the circles.
	for (int j = 0; j < docs.length; j++) {
	    int xpos = docs[j].getPosition().getX();
	    int ypos = docs[j].getPosition().getY();

	    String color = docs[j].getColorName();
	    if (color == "")
		// A light blue color by default
		color = "#e6f2fa";

	    String circle = String.format("  <circle id=\"circle-%d\" cx=\"%d\" cy=\"%d\" r=\"1\" fill=\"%s\" stroke=\"grey\" stroke-width=\"0.25px\" />",
					  j + 1, xpos, ypos, color);
	    svgLines.add(circle);
	}

	// Add a footer.
	svgLines.add("</svg>");
	
	// Overwrite the SVG file or create a new one.
	try (PrintWriter pw = new PrintWriter(output)) {
	    svgLines.stream().forEach(pw::println);
	} catch (IOException e) {
	    System.err.println("Failed to write to file");
	    System.err.println(e.getMessage());
	    return false;
	}

	return true;
    }
    
    private static boolean writePositions(File file, TopicMap map) {
	int ndocs = map.getConfiguration().getndocs();
	int xmax = map.getConfiguration().getxsize();
	int ymax = map.getConfiguration().getysize();
	
	// CSV header.
	String[] header = {
	    String.format("Document.%d", ndocs),
	    String.format("X.%d", xmax),
	    String.format("Y.%d", ymax)
	};
	
	// Gather the CSV lines.
	java.util.List<String[]> csvLines = new ArrayList<String[]>();
	csvLines.add(header);

	// Iterate through the documents and find their positions.
	Document[] docs = map.getDocuments();
	Position pos = new Position();
	
	for (int j = 0; j < ndocs; j++) {
	    map.getGrid().getPos(j, pos);

	    String[] line = new String[3];
	    line[0] = "\"" + docs[j].name + "\"";
	    line[1] = Integer.toString(pos.getX());
	    line[2] = Integer.toString(pos.getY());

	    csvLines.add(line);
	}
	
	// Overwrite the CSV file or create a new one.
	try (PrintWriter pw = new PrintWriter(file)) {
	    csvLines.stream()
		.map(JavaAntsCLI::joinCommas)
		.forEach(pw::println);
	} catch (IOException e) {
	    System.err.println("Failed to write to file");
	    System.err.println(e.getMessage());
	    return false;
	}

	return true;
    }
    
    private static Data generateData() {
	// Number of fake docs and keys.
 	int ndocs = 90;
	int nkeys = 20;

	// Document embeddings and keys.
	Document[] docs = new Document[ndocs];
	String[] keys = new String[nkeys];
	
	// Generate the keys.
	keys[0] = "Computer Graphics";
	keys[1] = "Splines";
	keys[2] = "Mesh";
	keys[3] = "Visualization";
	keys[4] = "Topic Maps";
	keys[5] = "Fisheye Views";
	keys[6] = "Graphs";
	keys[7] = "Artificial Life";
	keys[8] = "Game of Life";
	keys[9] = "Turing";
	keys[10] = "Chaos";
	keys[11] = "Self-organisation";
	keys[12] = "Artificial Intelligence";
	keys[13] = "Bayesian Reasoning";
	keys[14] = "Symbolic";
	keys[15] = "Expert System";
	keys[16] = "Neural Network";
	keys[17] = "Knowledge";
	keys[18] = "Representation";
	keys[19] = "Robot";

	// Generate the embeddings and documents.
	double data[] = new double[nkeys];
		
	for (int j=0; j<ndocs; j++) {
	    if (j < 30) {
		for (int k=0; k<7; k++) {
		    data[k] =  (int)Math.floor(3.0+Math.random()*3.0);
		}
		for (int k=7; k<20; k++) {
		    data[k] = (int)Math.floor(Math.random()*3.0);
		}
	    }
	    else if (j < 60) {
		for (int k=0; k<7; k++) {
		    data[k] = (int)Math.floor(Math.random()*3.0);
		}
		for (int k=7; k<12; k++) {
		    data[k] = (int)Math.floor(3.0+Math.random()*10.0);
		}
		for (int k=12; k<20; k++) {
		    data[k] = (int)Math.floor(Math.random()*3.0);
		}
	    }	
	    else {
		for (int k=0; k<12; k++) {
		    data[k] = (int)Math.floor(Math.random()*3.0);
		}
		for (int k=12; k<20; k++) {
		    data[k] = (int)Math.floor(30.0+Math.random()*5.0);
		}
	    }
	    
	    docs[j] = new Document();
	    docs[j].setVector(nkeys, data);
	    docs[j].name = String.format("Doc %d", j + 1);
	}

	return new Data(nkeys, ndocs, keys, docs);
    }
    
    private static boolean writeData(File file, Data data) {
	// Num docs and keys.
	int ndocs = data.getndocs();
	int nkeys = data.getnkeys();

	// Documents and keys.
	Document[] documents = data.getDocs();
	String[] keys = data.getKeys();

	// Create the header elements.
	String[] header = new String[1 + ndocs];
	header[0] = "Keys";
	for (int j = 0; j < ndocs; j++) {
	    if (documents[j].name == "") {
		documents[j].name = "Doc " + Integer.toString(j + 1);
	    }
	    header[j + 1] = documents[j].name;
	}

	// Gather the CSV lines.
	java.util.List<String[]> csvLines = new ArrayList<String[]>();
	csvLines.add(header);

	// Add the embedding lines, one per keyword.
	for (int k = 0; k < nkeys; k++) {
	    // Allocate space for keyword name + embedding.
	    String[] line = new String[1 + ndocs];
	    
	    // First column is the key.
	    line[0] = keys[k];
	    
	    // Other columns are the frequencies
	    double[] freqs = null;
	    for (int j = 0; j < ndocs; j++) {
		freqs = documents[j].getVector();
		line[j + 1] = Double.toString(freqs[k]);
	    }

	    // Add the data for this key
	    csvLines.add(line);
	}

	// Overwrite the CSV file or create a new one.
	try (PrintWriter pw = new PrintWriter(file)) {
	    csvLines.stream()
		.map(JavaAntsCLI::joinCommas)
		.forEach(pw::println);
	} catch (IOException e) {
	    System.err.println("Failed to write to file");
	    System.err.println(e.getMessage());
	    return false;
	}
	
	return true;
    }

    private static String joinCommas(String[] data) {
	return Stream.of(data).collect(Collectors.joining(","));
    }

    private static Data parseData(File file) {
	int ndocs, nkeys;
	java.util.List<String> header;
	java.util.List<String> keyList;
	java.util.List<double[]> freqs;
	
	// Parse the keywords and documents from the file.
	try (BufferedReader reader = new BufferedReader(new FileReader(file))) {

	    // Read the first line to get the number of documents and
	    // their names.
	    String line = reader.readLine();
	    if (line == null) {
		System.err.println("Failed to read CSV header");
		return null;
	    }
	    
	    header = Arrays.asList(line.split(","));
	    if (header.size() < 2) {
		System.err.println("Malformed CSV file: need at least 1 doc");
		return null;
	    }
	    
	    // Parse the number of docs.
	    ndocs = header.size() - 1;
	    
	    // Parse out keys and frequencies from the other lines.
	    keyList = new ArrayList<String>();
	    freqs = new ArrayList<double[]>();
	    
	    while ((line = reader.readLine()) != null) {
		// Split the key line.
		java.util.List<String> keyLine = Arrays.asList(line.split(","));
		if (keyLine.size() != ndocs + 1) {
		    System.err.println("Malformed CSV file: need 1 frequency per doc");
		    return null;
		}
		
		// Add the key name to the list.
		keyList.add(keyLine.get(0));
		
		// Parse the frequencies.
		double[] freq = new double[ndocs];
		for (int j = 0; j < ndocs; j++) {
		    freq[j] = Double.parseDouble(keyLine.get(j + 1));
		}
		freqs.add(freq);
	    }
	    
	} catch (IOException e) {
	    System.err.println("Failed to parse CSV file");
	    System.err.println(e.getMessage());
	    return null;
	}

	// Parse the keys into an array.
	nkeys = keyList.size();
	
	String[] keys = new String[nkeys];
	keys = keyList.toArray(keys);
	
	// Create the documents.
	Document[] docs = new Document[ndocs];
	
	double data[] = new double[nkeys];
	for (int j = 0; j < ndocs; j++) {
	    for (int k = 0; k < nkeys; k++) {
		double[] freq = freqs.get(k);
		data[k] = freq[j];
	    }

	    docs[j] = new Document();
	    docs[j].setVector(nkeys, data);
	    docs[j].name = header.get(j + 1);
	}

	return new Data(nkeys, ndocs, keys, docs);
    }
}	
 
 
    


 
