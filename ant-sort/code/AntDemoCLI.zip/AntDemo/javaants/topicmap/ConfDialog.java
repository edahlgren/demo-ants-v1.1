/*  
    Copyright (C) 2004 Julia Handl
    Email: Julia.Handl@gmx.de

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

/*****************************************************************
	Julia Handl - 18004385
	Monash University, 1.7.2001

	File: ConfDialog.java
	Package: JavaAnts.TopicMap

	Description:

	* GUI for the modification and viewing of configuration parameters
		
                                                                                                                        	
*****************************************************************/


package javaants.topicmap;

import javaants.*;
import java.lang.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ConfDialog extends JDialog {

	// GUI fields
	private static JCheckBox homogene;
	private static JTextField sizefield;
	private static JTextField speedfield;
	private static JTextField memoryfield;
	private static JTextField kpfield;
	private static JTextField kdfield;
	private static JCheckBox adaptK;
	private static JCheckBox adaptAlpha;
	private static JTextField alphafield;
	private static JTextField sigmafield;
	private static JTextField docfield;
	private static JTextField keyfield;
	private static JComboBox choice;
	private static JTextField xsizefield;
	private static JTextField ysizefield;
	private static JTextField runfield;
	private static JCheckBox analysis;
	private static JComboBox distfct;
	private static JComboBox textMode;
	private static JTextField astartfield;
	private static JTextField aendfield;
	private static JTextField aintervalfield;
	private static JTextField k1startfield;
	private static JTextField k1endfield;
	private static JTextField k1intervalfield;
	private static JTextField k2startfield;
	private static JTextField k2endfield;
	private static JTextField k2intervalfield;
	private static JTextField uppercutofffield;
	private static JTextField lowercutofffield;
	private static JTextField dimensionfield;
	private static JTextField browserfield;
	private static JCheckBox defaultbox;


	// pointers to data and GUI
	private static Configuration conf;
	private Frame frame;
	private TopicMap map;
	private Document [] documents;
	private String [] keywords;
	


/************ Constructor ***********************************************************************************/


	/** Dialog for the display and modification of the main paramter settings
	* @param conf the current paramter settings
	* @param frame the parent frame of this dialog
	* @param map the currently active topic map (to trigger update)
	* @param init flag indicating whether the topic map has een initialised
	*/
	public ConfDialog(Configuration conf, Frame frame, TopicMap map, boolean init) {

		// store pointers
		this.conf = conf;
		this.frame = frame;
		this.map = map;
		this.documents = documents;
		this.keywords = keywords;

		// generate GUI
		BorderLayout layout = new BorderLayout();
		layout.setHgap(5);
        	layout.setVgap(5);

       		BorderLayout layout0 = new BorderLayout();
		layout0.setHgap(5);
        	layout0.setVgap(5);

        	BorderLayout layout1 = new BorderLayout();
		layout1.setHgap(5);
        	layout1.setVgap(5);

		BorderLayout layout2 = new BorderLayout();
		layout2.setHgap(5);
        	layout2.setVgap(5);

        	BorderLayout layout3 = new BorderLayout();
		layout3.setHgap(5);
        	layout3.setVgap(5);

        	BorderLayout layout4 = new BorderLayout();
		layout4.setHgap(5);
        	layout4.setVgap(5);

        	BorderLayout layout5 = new BorderLayout();
		layout5.setHgap(5);
        	layout5.setVgap(5);

        	BorderLayout layout6 = new BorderLayout();
		layout6.setHgap(5);
        	layout6.setVgap(5);

        	BorderLayout layout7 = new BorderLayout();
		layout7.setHgap(5);
        	layout7.setVgap(5);

        	BorderLayout layout8 = new BorderLayout();
		layout8.setHgap(5);
        	layout8.setVgap(5);

        	BorderLayout layout9 = new BorderLayout();
		layout9.setHgap(5);
        	layout9.setVgap(5);
        	

		this.setTitle("Configuration");
		this.setBackground(Color.lightGray);
	    	
		ImageIcon icon = new ImageIcon("images/ant.gif");
		JTabbedPane tabbedPane = new JTabbedPane();


		// Ant Configuration
        	JPanel sizebox = new JPanel();
		sizebox.setLayout(new BorderLayout());
		JPanel antbox = new JPanel();
        	sizebox.setLayout(new BorderLayout());
        	JLabel sizelabel = new JLabel("Population Size");
		sizebox.add(sizelabel, BorderLayout.WEST);
		sizefield = new JTextField(conf.getsnants());
		sizefield.setPreferredSize(new Dimension(50, 10));
		sizebox.add(sizefield, BorderLayout.EAST);

		JPanel speed = new JPanel();
		speed.setLayout(new BorderLayout());
		
		JPanel speedbox = new JPanel();
		speedbox.setLayout(new BorderLayout());
		JLabel speedlabel = new JLabel("Step size");
		speedbox.add(speedlabel, BorderLayout.WEST);
		speedfield = new JTextField(conf.getsspeed());
		speedfield.setPreferredSize(new Dimension(50, 10));
		speedbox.add(speedfield, BorderLayout.EAST);

		speed.add(speedbox, BorderLayout.NORTH);
		
	    	homogene = new JCheckBox("Homogenous step sizes");
    		homogene.setSelected(conf.gethomogenous());
		speed.add(homogene, BorderLayout.SOUTH);
		

		JPanel memorybox = new JPanel();
		memorybox.setLayout(new BorderLayout());
		JLabel memorylabel = new JLabel("Memory Size");
		memorybox.add(memorylabel, BorderLayout.WEST);
		memoryfield = new JTextField(conf.getsmemsize());
		memoryfield.setPreferredSize(new Dimension(50, 10));
		memorybox.add(memoryfield, BorderLayout.EAST);
		
		JPanel upperbox = new JPanel();
        	upperbox.setLayout(new BorderLayout());
        	upperbox.add(sizebox, BorderLayout.NORTH);
        	upperbox.add(speed, BorderLayout.SOUTH);
        	upperbox.add(memorybox, BorderLayout.CENTER);
                
        	JPanel lowerbox = new JPanel();
        	lowerbox.setLayout(new BorderLayout());
		JLabel picklabel = new JLabel("Pick & Drop Parameters");
		lowerbox.add(picklabel, BorderLayout.NORTH);
		JPanel pbox = new JPanel();
		pbox.setLayout(new BorderLayout());

		JPanel kbox = new JPanel();
		kbox.setLayout(new BorderLayout());
		JPanel innerbox1 = new JPanel();
		innerbox1.setLayout(new BorderLayout());
		JPanel picbox = new JPanel();
		picbox.setLayout(new BorderLayout());
		JLabel kplabel = new JLabel("kp");
        	kpfield = new JTextField(conf.getskp());
        	kpfield.setPreferredSize(new Dimension(50, 10));
		picbox.add(kplabel, BorderLayout.WEST);
        	picbox.add(kpfield, BorderLayout.EAST);
        	kbox.add(picbox, BorderLayout.NORTH);
		

		JPanel dropbox = new JPanel();
		dropbox.setLayout(new BorderLayout());
		JLabel kdlabel = new JLabel("kd");
        	kdfield = new JTextField(conf.getskd());
        	kdfield.setPreferredSize(new Dimension(50, 10));
        	dropbox.add(kdlabel, BorderLayout.WEST);
        	dropbox.add(kdfield, BorderLayout.EAST);
        	kbox.add(dropbox, BorderLayout.SOUTH);
		innerbox1.add(kbox, BorderLayout.CENTER);
		pbox.add(innerbox1, BorderLayout.WEST);
		

		JPanel innerbox = new JPanel();
		innerbox.setLayout(new BorderLayout());
       		JPanel alphabox = new JPanel();
		alphabox.setLayout(new BorderLayout());
		JLabel alphalabel = new JLabel("alpha");
        	alphafield = new JTextField(conf.getsalpha());
        	alphafield.setPreferredSize(new Dimension(50, 10));
        	alphabox.add(alphalabel, BorderLayout.WEST);
        	alphabox.add(alphafield, BorderLayout.EAST);
        	innerbox.add(alphabox, BorderLayout.NORTH);

		adaptAlpha = new JCheckBox("Adaptive alpha");
		adaptAlpha.setSelected(conf.getadaptalpha());
		innerbox.add(adaptAlpha, BorderLayout.CENTER);

        	JPanel sigmabox = new JPanel();
		sigmabox.setLayout(new BorderLayout());
		JLabel sigmalabel = new JLabel("sigma");
        	sigmafield = new JTextField(conf.getssigma());
        	sigmafield.setPreferredSize(new Dimension(100, 10));
        	sigmabox.add(sigmalabel, BorderLayout.WEST);
        	sigmabox.add(sigmafield, BorderLayout.EAST);
        	innerbox.add(sigmabox, BorderLayout.SOUTH);
		
		pbox.add(innerbox, BorderLayout.EAST);
		lowerbox.add(pbox, BorderLayout.CENTER);

		JPanel buttonbox = new JPanel();
		buttonbox.setLayout(new BorderLayout());
		JButton antButton = new JButton("Save changes");
		antButton.setPreferredSize(new Dimension(150, 30));
		antButton.addActionListener(new Save(conf, this, frame, map));
		buttonbox.add(antButton, BorderLayout.WEST);
		JButton closeButton = new JButton("Close");
		closeButton.addActionListener(new Close(this));
		closeButton.setPreferredSize(new Dimension(150, 30));
		buttonbox.add(closeButton, BorderLayout.EAST);

		JPanel box = new JPanel();
        	box.setLayout(layout);
        	box.add(upperbox, BorderLayout.NORTH);
        	box.add(lowerbox, BorderLayout.CENTER);
        	box.add(buttonbox, BorderLayout.SOUTH);
       
       		tabbedPane.addTab("Ant-Colony", icon, box,  "Specify colony settings");	
		tabbedPane.setSelectedIndex(0);

	
		// Document Configuration
		JPanel docbox = new JPanel();
		docbox.setLayout(layout1);
		JPanel docpar = new JPanel();
		docpar.setLayout(layout3);
		JPanel docpanel = new JPanel();
		docpanel.setLayout(new BorderLayout());
		JLabel doclabel = new JLabel("Number of items");
		docpanel.add(doclabel, BorderLayout.WEST);
		docfield = new JTextField(conf.getsndocs());
		docfield.setPreferredSize(new Dimension(50, 10));
		docfield.setEditable(false);
		docpanel.add(docfield, BorderLayout.EAST);
		docpar.add(docpanel, BorderLayout.CENTER);

		JPanel keyPanel = new JPanel();
		keyPanel.setLayout(new BorderLayout());
		JLabel keyLabel = new JLabel("Dimension");
		keyPanel.add(keyLabel, BorderLayout.WEST);
		keyfield = new JTextField(conf.getsnkeys());
		keyfield.setPreferredSize(new Dimension(50, 10));
		keyfield.setEditable(false);
		keyPanel.add(keyfield, BorderLayout.EAST);
		docpar.add(keyPanel, BorderLayout.SOUTH);

		
		JPanel choicePanel = new JPanel();
		choicePanel.setLayout(new BorderLayout());
		JLabel choiceLabel = new JLabel("Distribution");
		choicePanel.add(choiceLabel, BorderLayout.WEST);
		String[] distStrings = { "Test Set A1", "Test Set A2", "Test Set A3"};
		choice = new JComboBox(distStrings);
		choice.setSelectedIndex(conf.getchoice());
		choicePanel.add(choice, BorderLayout.EAST);
		docpar.add(choicePanel, BorderLayout.NORTH);

		JPanel mapbuttonbox = new JPanel();
		mapbuttonbox.setLayout(new BorderLayout());
		JButton mapButton = new JButton("Save changes");
		mapButton.setPreferredSize(new Dimension(150, 30));
		mapButton.addActionListener(new Save(conf ,this, frame, map));
		mapbuttonbox.add(mapButton, BorderLayout.WEST);
		JButton mapcloseButton = new JButton("Close");
		mapcloseButton.setPreferredSize(new Dimension(150, 30));
		mapcloseButton.addActionListener(new Close(this));
		mapbuttonbox.add(mapcloseButton, BorderLayout.EAST);

		JPanel southernbox = new JPanel();
		southernbox.setLayout(layout5);

		southernbox.add(docpar, BorderLayout.NORTH);
		docbox.add(mapbuttonbox, BorderLayout.SOUTH);
		docbox.add(southernbox, BorderLayout.NORTH);
		
	
		tabbedPane.addTab("Document Generator", icon, docbox,  "Specify settings for test data");	

	
		// Map Configuration
		JPanel mapbox = new JPanel();
		mapbox.setLayout(layout2);
		JPanel parbox = new JPanel();
		parbox.setLayout(new BorderLayout());
		JPanel xsizepanel = new JPanel();
		xsizepanel.setLayout(new BorderLayout());
		JLabel xsizelabel = new JLabel("Width");
		xsizepanel.add(xsizelabel, BorderLayout.WEST);
		xsizefield = new JTextField(conf.getsysize());
		xsizefield.setPreferredSize(new Dimension(50, 10));
		xsizepanel.add(xsizefield, BorderLayout.EAST);
		parbox.add(xsizepanel, BorderLayout.NORTH);
		JPanel ysizepanel = new JPanel();
		ysizepanel.setLayout(new BorderLayout());
		JLabel ysizelabel = new JLabel("Height");
		ysizepanel.add(ysizelabel, BorderLayout.WEST);
		ysizefield = new JTextField(conf.getsysize());
		ysizefield.setPreferredSize(new Dimension(50, 10));
		ysizepanel.add(ysizefield, BorderLayout.EAST);
		parbox.add(ysizepanel, BorderLayout.CENTER);
		JPanel runpanel = new JPanel();
		runpanel.setLayout(new BorderLayout());
		JLabel runlabel = new JLabel("Number of iterations");
		runpanel.add(runlabel, BorderLayout.WEST);
		runfield = new JTextField(conf.getsruns());
		runfield.setPreferredSize(new Dimension(50, 10));
		runpanel.add(runfield, BorderLayout.EAST);
		parbox.add(runpanel, BorderLayout.SOUTH);

	
		JPanel docbuttonbox = new JPanel();
		docbuttonbox.setLayout(new BorderLayout());
		JButton docButton = new JButton("Save changes");
		docButton.setPreferredSize(new Dimension(150, 30));
		docButton.addActionListener(new Save(conf ,this, frame, map));
		docbuttonbox.add(docButton, BorderLayout.WEST);
		JButton doccloseButton = new JButton("Close");
		doccloseButton.setPreferredSize(new Dimension(150, 30));
		doccloseButton.addActionListener(new Close(this));
		docbuttonbox.add(doccloseButton, BorderLayout.EAST);

		JPanel centre = new JPanel();
		centre.setLayout(new BorderLayout());

		mapbox.add(parbox, BorderLayout.NORTH);
		mapbox.add(centre, BorderLayout.CENTER);
		mapbox.add(docbuttonbox, BorderLayout.SOUTH);

		tabbedPane.addTab("Topic Map", icon, mapbox,  "Specify settings for topic map");	

		// finish
		this.getContentPane().add(tabbedPane);
		this.pack();
    	this.setSize(500, 300);
    	this.show();
    	this.setVisible(true);
	}


/************ small access functions ********************************************************************/

	public String getlowercutoff() {
		return lowercutofffield.getText();
	}
	public String getuppercutoff() {
		return uppercutofffield.getText();
	}
	public String getdim() {
		return dimensionfield.getText();
	}
	public boolean getDefault() {
		return defaultbox.isSelected();
	}
	public String getxsize() {
		return xsizefield.getText();
	}
	public String getysize() {
		return ysizefield.getText();
	}
	public String getspeed() {
		return speedfield.getText();
	}
	public String getmemsize() {
		return memoryfield.getText();
	}
	public String getruns() {
		return runfield.getText();
	}
	public String getnants() {
		return sizefield.getText();
	}
	public String getnkeys() {
		return keyfield.getText();
	}
	public String getndocs() {
		return docfield.getText();
	}
	public int getchoice() {
		return choice.getSelectedIndex();
	}
	public String getkp() {
		return kpfield.getText();
	}
	public boolean getadaptk() {
		return adaptK.isSelected();
	}
	public String getkd() {
		return kdfield.getText();
	}
	public boolean getadaptalpha() {
		return adaptAlpha.isSelected();
	}
	public String getalpha() {
		return alphafield.getText();
	}
	public String getsigma() {
		return sigmafield.getText();
	}
	public boolean gethomogenous() {
		return homogene.isSelected();
	}
	public int gettextmode() {
		return textMode.getSelectedIndex();
	}
	public int getdistfct() {
		return distfct.getSelectedIndex();
	}
	public boolean gettest() {
		return analysis.isSelected();
	}
	public String getalphastartvalue() {
		return astartfield.getText();
	}
	public String getalphaendvalue() {
		return aendfield.getText();
	}
	public String getalphaintervalvalue() {
		return aintervalfield.getText();
	}
	public String getkdstartvalue() {
		return k1startfield.getText();
	}
	public String getkdendvalue() {
		return k1endfield.getText();
	}
	public String getkdintervalvalue() {
		return k1intervalfield.getText();
	}
	public String getkpstartvalue() {
		return k2startfield.getText();
	}
	public String getkpendvalue() {
		return k2endfield.getText();
	}
	public String getkpintervalvalue() {
		return k2intervalfield.getText();
	}
	public String getbrowser() {
		return browserfield.getText();
	}

}




	
