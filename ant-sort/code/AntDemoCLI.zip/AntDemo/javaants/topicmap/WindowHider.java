package javaants.topicmap;
import java.awt.*;
import java.awt.event.*;


/** Hide the associated window */
public class WindowHider extends WindowAdapter {
   Frame f;


   public WindowHider(Frame f) {
	this.f = f;
	
   }
    public void windowClosing(WindowEvent e) {
      	f.hide();
      	
    }
 }