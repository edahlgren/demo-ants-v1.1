package javaants;

public class floatPoint {
    float x;
    float y;
    floatPoint(float x, float y) {
	this.x = x;
	this.y = y;
    }
}
