/*  
    Copyright (C) 2004 Julia Handl
    Email: Julia.Handl@gmx.de

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

/*****************************************************************
	Julia Handl - 18004385
	Monash University, 1.7.2001

	File: SaveConf.java
	Package: JavaAnts

	Description:

	* Saves the paramter settings to the disk
	
                                                                                                                        	
*****************************************************************/

package javaants;

import java.io.*;
import java.awt.event.*;
import javax.swing.*;

/** Dialog window, Can be used to saves complete paramter settings to the disk
*/
public class SaveConf implements ActionListener {
		JDialog dialog;
		JTextArea area;
		Configuration conf;
		String text;
		String filename;

		/** Constructor
		* @param dialog the dialog containg the textarea area
		* @param area textarea containing user comments
		* @param conf the current paramter settings
		* @param filename the name of the file where the parameters will be stored
		*/
	 	public SaveConf (JDialog dialog, JTextArea area, Configuration conf, String filename) {
			this.dialog = dialog;
			this.area = area;
			this.conf = conf;
			this.filename = filename;
		}

		/** React to user input by reading user comments from the text area and saving the text and the parameters */
		public void actionPerformed(ActionEvent event)  {
			String newtext = "";
			char c;

    		this.text = this.area.getText(); 	
			for (int i=0; i< text.length(); i++) {
				if ((c = text.charAt(i)) == '\n') {
					newtext += System.getProperty("line.separator");
				}
				else newtext+= String.valueOf(c);
			}
			text = newtext;
    	
    		try {
	   			save(text);
    		} catch (IOException e) {
    			System.err.println("Error while writing to file " + filename);
    			System.err.println(e.getMessage());
    		}

    		dialog.hide();
      	}

      	/** Save all parameters and the user comment to the specified file */
		public void save(String text) throws IOException {

			String separator = System.getProperty("line.separator");
			DataOutputStream outputfile = new DataOutputStream(new FileOutputStream(filename));
			outputfile.flush();

			outputfile.writeBytes(separator);
			outputfile.writeBytes(new String("Corresponding image: "+ filename + ".gif"));
			outputfile.writeBytes(separator);
			outputfile.writeBytes(separator);
			outputfile.writeBytes(new String("Description: "));
			outputfile.writeBytes(separator);
			outputfile.writeBytes(text);
			outputfile.writeBytes(separator);
			outputfile.writeBytes(separator);
			

			outputfile.writeBytes(new String("Ant Parameters"));
			outputfile.writeBytes(separator);
			outputfile.writeBytes(new String("nants: " + this.conf.getnants()));
			outputfile.writeBytes(separator);
			outputfile.writeBytes(new String("memsize: " + this.conf.getmemsize()));
			outputfile.writeBytes(separator);
			outputfile.writeBytes(new String("speed: " + this.conf.getspeed()));
			outputfile.writeBytes(separator);
			outputfile.writeBytes(new String("kd: " + this.conf.getkd()));
			outputfile.writeBytes(separator);
			outputfile.writeBytes(new String("kp: " + this.conf.getkp()));
			outputfile.writeBytes(separator);
			outputfile.writeBytes(new String("Adaptive: " + this.conf.getadaptk()));
			outputfile.writeBytes(separator);

			outputfile.writeBytes(new String("alpha: " + this.conf.getalpha()));
			outputfile.writeBytes(separator);
			outputfile.writeBytes(new String("Adaptive: " + this.conf.getadaptalpha()));
			outputfile.writeBytes(separator);
			outputfile.writeBytes(new String("sigma: " + this.conf.getsigma()));
			outputfile.writeBytes(separator);
			outputfile.writeBytes(new String("homogenous: " + this.conf.gethomogenous()));
			outputfile.writeBytes(separator);
			outputfile.writeBytes(separator);
			outputfile.writeBytes(new String("Map Parameters"));
			outputfile.writeBytes(separator);
			outputfile.writeBytes(new String("xsize: " + this.conf.getxsize()));
			outputfile.writeBytes(separator);
			outputfile.writeBytes(new String("ysize: " + this.conf.getysize()));
			outputfile.writeBytes(separator);
			outputfile.writeBytes(new String("iterations: " + this.conf.getiterations()));
			outputfile.writeBytes(separator);
			outputfile.writeBytes(separator);
			
			outputfile.writeBytes(new String("Document Parameters"));
			outputfile.writeBytes(separator);
			outputfile.writeBytes(new String("ndocs: " + this.conf.getndocs()));
			outputfile.writeBytes(separator);
			outputfile.writeBytes(new String("nkeys: " + this.conf.getnkeys()));
			outputfile.writeBytes(separator);
			outputfile.writeBytes(new String("distribution: " + this.conf.getchoice()));
			outputfile.writeBytes(separator);

		
			outputfile.close();
	}
}
