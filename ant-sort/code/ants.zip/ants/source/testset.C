/*  Ant-based Clustering
    Copyright (C) 2004 Julia Handl
    Email: Julia.Handl@gmx.de

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

/***************************************************

date: 7.4.2003

author: Julia Handl (Julia.Handl@gmx.de)

description:
 
hard-coding of two-dimensional artificial test sets

***************************************************/


#include "testset.h"
#include "math.h"
#include "conf.h"
#include "random.h"
#include "gasdev.h"
#include "string.h"
#include <cstdlib>

double mysquare(double);
extern long idum;


// constructor, requires the name of the test set 
// and the current configuration object
testset::testset(char * n, conf * c) {
    par = c;
    point_coordinates = NULL;
    name = n;
 
}


// destructor
// free all allocated memory 
testset::~testset() {
      if (point_coordinates != NULL) {
	for (int i=0; i<par->binsize; i++) {
	    delete point_coordinates[i];
	}
	delete [] point_coordinates;
      }
}


// generation of the testset described by the 
// global string <name>
void testset::generate() {

 

    // "square0"
    if (strcmp(name, "square0") == 0) {
	par->num_cluster = 4;
	par->kclusters = 4;
	par->binsize = 1000;
	par->bindim = 2;
	par->mu_cluster = new USED_DATA_TYPE * [par->num_cluster];
	par->sigma_cluster = new USED_DATA_TYPE * [par->num_cluster];
	par->size_cluster = new int[par->num_cluster];
	
	// allocation of memory to store mean and stdv
	for (int i=0; i<par->num_cluster; i++) {
	    par->mu_cluster[i] = new USED_DATA_TYPE[par->bindim];
	    par->sigma_cluster[i] = new USED_DATA_TYPE[par->bindim];
	}

	// description of the Normal Distributions
	par->mu_cluster[0][0] = 10; par->mu_cluster[0][1] = 10;
	par->mu_cluster[1][0] = 10; par->mu_cluster[1][1] = 0;
	par->mu_cluster[2][0] = 0; par->mu_cluster[2][1] = 10;
	par->mu_cluster[3][0] = 0; par->mu_cluster[3][1] = 0;

	for (int i=0; i<par->num_cluster; i++) {
		par->sigma_cluster[i][0] = 1;
		par->sigma_cluster[i][1] = 1;
		par->size_cluster[i] = par->binsize / par->num_cluster;
	}

	// allocation of memory to store data items
	point_coordinates = new USED_DATA_TYPE* [par->binsize];
	if (point_coordinates == NULL) {
	    cerr << "Testset: Memory allocation failed" << endl;
	    exit(0);
	}

	// generation of the data items
	int ctr = 0;
	for (int i=0; i<par->num_cluster; i++) {
	    for (int j=0; j<par->size_cluster[i]; j++) {
		point_coordinates[ctr] = new USED_DATA_TYPE[par->bindim];
		if (point_coordinates[ctr] == NULL) {
		    cerr << "Testset: Memory allocation failed" << endl;
		    exit(0);
		}
		point_coordinates[ctr][0] = par->mu_cluster[i][0] + gasdev(&idum)*par->sigma_cluster[i][0];
		point_coordinates[ctr][1] = par->mu_cluster[i][1] + gasdev(&idum)*par->sigma_cluster[i][1];
		ctr++;
		//		std::cout << idum << " " << gasdev(&idum) << " " << point_coordinates[ctr-1][0] << " " << point_coordinates[ctr-1][0] << std::endl;
	    }
	}
    }

    // "square1"
  else if (strcmp(name, "square1") == 0) {
	par->num_cluster = 4;
	par->kclusters = 4;
	par->binsize = 1000;
	par->bindim = 2;
	par->mu_cluster = new USED_DATA_TYPE * [par->num_cluster];
	par->sigma_cluster = new USED_DATA_TYPE * [par->num_cluster];
	par->size_cluster = new int[par->num_cluster];
	
	// allocation of memory to store mean and stdv
	for (int i=0; i<par->num_cluster; i++) {
	    par->mu_cluster[i] = new USED_DATA_TYPE[par->bindim];
	    par->sigma_cluster[i] = new USED_DATA_TYPE[par->bindim];
	}

	// description of the Normal Distributions
	par->mu_cluster[0][0] = 10; par->mu_cluster[0][1] = 10;
	par->mu_cluster[1][0] = 10; par->mu_cluster[1][1] = 0;
	par->mu_cluster[2][0] = 0; par->mu_cluster[2][1] = 10;
	par->mu_cluster[3][0] = 0; par->mu_cluster[3][1] = 0;

	for (int i=0; i<par->num_cluster; i++) {
		par->sigma_cluster[i][0] = 2;
		par->sigma_cluster[i][1] = 2;
		par->size_cluster[i] = par->binsize / par->num_cluster;
	}

	// allocation of memory to store data items
	point_coordinates = new USED_DATA_TYPE* [par->binsize];
	if (point_coordinates == NULL) {
	    cerr << "Testset: Memory allocation failed" << endl;
	    exit(0);
	}

	// generation of the data items
	int ctr = 0;
	for (int i=0; i<par->num_cluster; i++) {
    
	    for (int j=0; j<par->size_cluster[i]; j++) {
		point_coordinates[ctr] = new USED_DATA_TYPE[par->bindim];
		if (point_coordinates[ctr] == NULL) {
		    cerr << "Testset: Memory allocation failed" << endl;
		    exit(0);
		}
		point_coordinates[ctr][0] = par->mu_cluster[i][0] + gasdev(&idum)*par->sigma_cluster[i][0];
		point_coordinates[ctr][1] = par->mu_cluster[i][1] + gasdev(&idum)*par->sigma_cluster[i][1];		
		ctr++;
	    }
	}
    }


    // "square2"
    else if (strcmp(name, "square2") == 0) {
	par->num_cluster = 4;
	par->kclusters = 4;
	par->binsize = 1000;
	par->bindim = 2;
	par->mu_cluster = new USED_DATA_TYPE * [par->num_cluster];
	par->sigma_cluster = new USED_DATA_TYPE * [par->num_cluster];
	par->size_cluster = new int[par->num_cluster];
	
	// allocation of memory to store mean and stdv
	for (int i=0; i<par->num_cluster; i++) {
	    par->mu_cluster[i] = new USED_DATA_TYPE[par->bindim];
	    par->sigma_cluster[i] = new USED_DATA_TYPE[par->bindim];
	}

	// description of the Normal Distributions
	par->mu_cluster[0][0] = 9; par->mu_cluster[0][1] = 9;
	par->mu_cluster[1][0] = 9; par->mu_cluster[1][1] = 0;
	par->mu_cluster[2][0] = 0; par->mu_cluster[2][1] = 9;
	par->mu_cluster[3][0] = 0; par->mu_cluster[3][1] = 0;

	for (int i=0; i<par->num_cluster; i++) {
		par->sigma_cluster[i][0] = 2;
		par->sigma_cluster[i][1] = 2;
		par->size_cluster[i] = par->binsize / par->num_cluster;
	}

	// allocation of memory to store data items
	point_coordinates = new USED_DATA_TYPE* [par->binsize];
	if (point_coordinates == NULL) {
	    cerr << "Testset: Memory allocation failed" << endl;
	    exit(0);
	}

	// generation of the data items
	int ctr = 0;
	for (int i=0; i<par->num_cluster; i++) {
	    
	    for (int j=0; j<par->size_cluster[i]; j++) {
		point_coordinates[ctr] = new USED_DATA_TYPE[par->bindim];
		if (point_coordinates[ctr] == NULL) {
		    cerr << "Testset: Memory allocation failed" << endl;
		    exit(0);
		}
		point_coordinates[ctr][0] = par->mu_cluster[i][0] + gasdev(&idum)*par->sigma_cluster[i][0];
		point_coordinates[ctr][1] = par->mu_cluster[i][1] + gasdev(&idum)*par->sigma_cluster[i][1];		

		ctr++;
	    }
	}
    }


    // "square3"
    else if (strcmp(name, "square3") == 0) {
	par->num_cluster = 4;
	par->kclusters = 4;
	par->binsize = 1000;
	par->bindim = 2;
	par->mu_cluster = new USED_DATA_TYPE * [par->num_cluster];
	par->sigma_cluster = new USED_DATA_TYPE * [par->num_cluster];
	par->size_cluster = new int[par->num_cluster];
	
	// allocation of memory to store mean and stdv
	for (int i=0; i<par->num_cluster; i++) {
	    par->mu_cluster[i] = new USED_DATA_TYPE[par->bindim];
	    par->sigma_cluster[i] = new USED_DATA_TYPE[par->bindim];
	}

	// description of the Normal Distributions
	par->mu_cluster[0][0] = 8; par->mu_cluster[0][1] = 8;
	par->mu_cluster[1][0] = 8; par->mu_cluster[1][1] = 0;
	par->mu_cluster[2][0] = 0; par->mu_cluster[2][1] = 8;
	par->mu_cluster[3][0] = 0; par->mu_cluster[3][1] = 0;

	for (int i=0; i<par->num_cluster; i++) {
		par->sigma_cluster[i][0] = 2;
		par->sigma_cluster[i][1] = 2;
		par->size_cluster[i] = par->binsize / par->num_cluster;
	}

	// allocation of memory to store data items
	point_coordinates = new USED_DATA_TYPE* [par->binsize];
	if (point_coordinates == NULL) {
	    cerr << "Testset: Memory allocation failed" << endl;
	    exit(0);
	}

	// generation of the data items
	int ctr = 0;
	for (int i=0; i<par->num_cluster; i++) {
	    for (int j=0; j<par->size_cluster[i]; j++) {
		point_coordinates[ctr] = new USED_DATA_TYPE[par->bindim];
		if (point_coordinates[ctr] == NULL) {
		    cerr << "Testset: Memory allocation failed" << endl;
		    exit(0);
		}
	point_coordinates[ctr][0] = par->mu_cluster[i][0] + gasdev(&idum)*par->sigma_cluster[i][0];
		point_coordinates[ctr][1] = par->mu_cluster[i][1] + gasdev(&idum)*par->sigma_cluster[i][1];
		ctr++;
	    }
	}
    }
	

    // "square4"
    else if (strcmp(name, "square4") == 0) {
	par->num_cluster = 4;
	par->kclusters = 4;
	par->binsize = 1000;
	par->bindim = 2;
	par->mu_cluster = new USED_DATA_TYPE * [par->num_cluster];
	par->sigma_cluster = new USED_DATA_TYPE * [par->num_cluster];
	par->size_cluster = new int[par->num_cluster];
	
	// allocation of memory to store mean and stdv
	for (int i=0; i<par->num_cluster; i++) {
	    par->mu_cluster[i] = new USED_DATA_TYPE[par->bindim];
	    par->sigma_cluster[i] = new USED_DATA_TYPE[par->bindim];
	}

	// description of the Normal Distributions
	par->mu_cluster[0][0] = 7; par->mu_cluster[0][1] = 7;
	par->mu_cluster[1][0] = 7; par->mu_cluster[1][1] = 0;
	par->mu_cluster[2][0] = 0; par->mu_cluster[2][1] = 7;
	par->mu_cluster[3][0] = 0; par->mu_cluster[3][1] = 0;

	for (int i=0; i<par->num_cluster; i++) {
		par->sigma_cluster[i][0] = 2;
		par->sigma_cluster[i][1] = 2;
		par->size_cluster[i] = par->binsize / par->num_cluster;
	}

	// allocation of memory to store data items
	point_coordinates = new USED_DATA_TYPE* [par->binsize];
	if (point_coordinates == NULL) {
	    cerr << "Testset: Memory allocation failed" << endl;
	    exit(0);
	}

	// generation of the data items
	int ctr = 0;
	for (int i=0; i<par->num_cluster; i++) {
	 
	    
	    for (int j=0; j<par->size_cluster[i]; j++) {
		point_coordinates[ctr] = new USED_DATA_TYPE[par->bindim];
		if (point_coordinates[ctr] == NULL) {
		    cerr << "Testset: Memory allocation failed" << endl;
		    exit(0);
		}
		point_coordinates[ctr][0] = par->mu_cluster[i][0] + gasdev(&idum)*par->sigma_cluster[i][0];
		point_coordinates[ctr][1] = par->mu_cluster[i][1] + gasdev(&idum)*par->sigma_cluster[i][1];
		ctr++;
	    }
	}
    }

    // "square5"
    else if (strcmp(name, "square5") == 0) {
	par->num_cluster = 4;
	par->kclusters = 4;
	par->binsize = 1000;
	par->bindim = 2;
	par->mu_cluster = new USED_DATA_TYPE * [par->num_cluster];
	par->sigma_cluster = new USED_DATA_TYPE * [par->num_cluster];
	par->size_cluster = new int[par->num_cluster];
	
	// allocation of memory to store mean and stdv
	for (int i=0; i<par->num_cluster; i++) {
	    par->mu_cluster[i] = new USED_DATA_TYPE[par->bindim];
	    par->sigma_cluster[i] = new USED_DATA_TYPE[par->bindim];
	}

	// description of the Normal Distributions
	par->mu_cluster[0][0] = 6; par->mu_cluster[0][1] = 6;
	par->mu_cluster[1][0] = 6; par->mu_cluster[1][1] = 0;
	par->mu_cluster[2][0] = 0; par->mu_cluster[2][1] = 6;
	par->mu_cluster[3][0] = 0; par->mu_cluster[3][1] = 0;

	for (int i=0; i<par->num_cluster; i++) {
		par->sigma_cluster[i][0] = 2;
		par->sigma_cluster[i][1] = 2;
		par->size_cluster[i] = par->binsize / par->num_cluster;
	}

	// allocation of memory to store data items
	point_coordinates = new USED_DATA_TYPE* [par->binsize];
	if (point_coordinates == NULL) {
	    cerr << "Testset: Memory allocation failed" << endl;
	    exit(0);
	}

	// generation of the data items
	int ctr = 0;
	for (int i=0; i<par->num_cluster; i++) {
	 
	    
	    for (int j=0; j<par->size_cluster[i]; j++) {
		point_coordinates[ctr] = new USED_DATA_TYPE[par->bindim];
		if (point_coordinates[ctr] == NULL) {
		    cerr << "Testset: Memory allocation failed" << endl;
		    exit(0);
		}
		point_coordinates[ctr][0] = par->mu_cluster[i][0] + gasdev(&idum)*par->sigma_cluster[i][0];
		point_coordinates[ctr][1] = par->mu_cluster[i][1] + gasdev(&idum)*par->sigma_cluster[i][1];
		ctr++;
	    }
	}
    }
    // "square6"
    else if (strcmp(name, "square6") == 0) {
	par->num_cluster = 4;
	par->kclusters = 4;
	par->binsize = 1000;
	par->bindim = 2;
	par->mu_cluster = new USED_DATA_TYPE * [par->num_cluster];
	par->sigma_cluster = new USED_DATA_TYPE * [par->num_cluster];
	par->size_cluster = new int[par->num_cluster];
	
	// allocation of memory to store mean and stdv
	for (int i=0; i<par->num_cluster; i++) {
	    par->mu_cluster[i] = new USED_DATA_TYPE[par->bindim];
	    par->sigma_cluster[i] = new USED_DATA_TYPE[par->bindim];
	}

	// description of the Normal Distributions
	par->mu_cluster[0][0] = 5; par->mu_cluster[0][1] = 5;
	par->mu_cluster[1][0] = 5; par->mu_cluster[1][1] = 0;
	par->mu_cluster[2][0] = 0; par->mu_cluster[2][1] = 5;
	par->mu_cluster[3][0] = 0; par->mu_cluster[3][1] = 0;

	for (int i=0; i<par->num_cluster; i++) {
		par->sigma_cluster[i][0] = 2;
		par->sigma_cluster[i][1] = 2;
		par->size_cluster[i] = par->binsize / par->num_cluster;
	}

	// allocation of memory to store data items
	point_coordinates = new USED_DATA_TYPE* [par->binsize];
	if (point_coordinates == NULL) {
	    cerr << "Testset: Memory allocation failed" << endl;
	    exit(0);
	}

	// generation of the data items
	int ctr = 0;
	for (int i=0; i<par->num_cluster; i++) {
	    
	    for (int j=0; j<par->size_cluster[i]; j++) {
		point_coordinates[ctr] = new USED_DATA_TYPE[par->bindim];
		if (point_coordinates[ctr] == NULL) {
		    cerr << "Testset: Memory allocation failed" << endl;
		    exit(0);
		}
		point_coordinates[ctr][0] = par->mu_cluster[i][0] + gasdev(&idum)*par->sigma_cluster[i][0];
		point_coordinates[ctr][1] = par->mu_cluster[i][1] + gasdev(&idum)*par->sigma_cluster[i][1];
		ctr++;
	    }
	}
    }

   // "square7"
    else if (strcmp(name, "square7") == 0) {
	par->num_cluster = 4;
	par->kclusters = 4;
	par->binsize = 1000;
	par->bindim = 2;
	par->mu_cluster = new USED_DATA_TYPE * [par->num_cluster];
	par->sigma_cluster = new USED_DATA_TYPE * [par->num_cluster];
	par->size_cluster = new int[par->num_cluster];
	
	// allocation of memory to store mean and stdv
	for (int i=0; i<par->num_cluster; i++) {
	    par->mu_cluster[i] = new USED_DATA_TYPE[par->bindim];
	    par->sigma_cluster[i] = new USED_DATA_TYPE[par->bindim];
	}

	// description of the Normal Distributions
	par->mu_cluster[0][0] = 4; par->mu_cluster[0][1] = 4;
	par->mu_cluster[1][0] = 4; par->mu_cluster[1][1] = 0;
	par->mu_cluster[2][0] = 0; par->mu_cluster[2][1] = 4;
	par->mu_cluster[3][0] = 0; par->mu_cluster[3][1] = 0;

	for (int i=0; i<par->num_cluster; i++) {
		par->sigma_cluster[i][0] = 2;
		par->sigma_cluster[i][1] = 2;
		par->size_cluster[i] = par->binsize / par->num_cluster;
	}

	// allocation of memory to store data items
	point_coordinates = new USED_DATA_TYPE* [par->binsize];
	if (point_coordinates == NULL) {
	    cerr << "Testset: Memory allocation failed" << endl;
	    exit(0);
	}

	// generation of the data items
	int ctr = 0;
	for (int i=0; i<par->num_cluster; i++) {
	    
	    for (int j=0; j<par->size_cluster[i]; j++) {
		point_coordinates[ctr] = new USED_DATA_TYPE[par->bindim];
		if (point_coordinates[ctr] == NULL) {
		    cerr << "Testset: Memory allocation failed" << endl;
		    exit(0);
		}
		point_coordinates[ctr][0] = par->mu_cluster[i][0] + gasdev(&idum)*par->sigma_cluster[i][0];
		point_coordinates[ctr][1] = par->mu_cluster[i][1] + gasdev(&idum)*par->sigma_cluster[i][1];
		ctr++;
	    }
	}
    }

   
    // sizes1
    else if (strcmp(name, "sizes1") == 0) {
	par->num_cluster = 4;
	par->kclusters = 4;
	par->binsize = 1000;
	par->bindim = 2;
	par->mu_cluster = new USED_DATA_TYPE * [par->num_cluster];
	par->sigma_cluster = new USED_DATA_TYPE * [par->num_cluster];
	par->size_cluster = new int[par->num_cluster];
	
	for (int i=0; i<par->num_cluster; i++) {
	    par->mu_cluster[i] = new USED_DATA_TYPE[par->bindim];
	    par->sigma_cluster[i] = new USED_DATA_TYPE[par->bindim];
	}

	par->mu_cluster[0][0] = 10; par->mu_cluster[0][1] = 10;
	par->mu_cluster[1][0] = 10; par->mu_cluster[1][1] = 0;
	par->mu_cluster[2][0] = 0; par->mu_cluster[2][1] = 10;
	par->mu_cluster[3][0] = 0; par->mu_cluster[3][1] = 0;
	for (int i=0; i<par->num_cluster; i++) {
		par->sigma_cluster[i][0] = 2;
		par->sigma_cluster[i][1] = 2;

	}
	par->size_cluster[0] = 400;
	par->size_cluster[1] = 200;
	par->size_cluster[2] = 200;
	par->size_cluster[3] = 200;

	    
	point_coordinates = new USED_DATA_TYPE* [par->binsize];
	if (point_coordinates == NULL) {
	    cerr << "Testset: Memory allocation failed" << endl;
	    exit(0);
	}
	int ctr = 0;
	for (int i=0; i<par->num_cluster; i++) {
	    
	    for (int j=0; j<par->size_cluster[i]; j++) {
		point_coordinates[ctr] = new USED_DATA_TYPE[par->bindim];
		if (point_coordinates[ctr] == NULL) {
		    cerr << "Testset: Memory allocation failed" << endl;
		    exit(0);
		}
		point_coordinates[ctr][0] = par->mu_cluster[i][0] + gasdev(&idum)*par->sigma_cluster[i][0];
		point_coordinates[ctr][1] = par->mu_cluster[i][1] + gasdev(&idum)*par->sigma_cluster[i][1];
		ctr++;
	    }
	}
    }


    // sizes2
    else if (strcmp(name, "sizes2") == 0) {
	par->num_cluster = 4;
	par->kclusters = 4;
	par->binsize = 1000;
	par->bindim = 2;
	par->mu_cluster = new USED_DATA_TYPE * [par->num_cluster];
	par->sigma_cluster = new USED_DATA_TYPE * [par->num_cluster];
	par->size_cluster = new int[par->num_cluster];
	
	for (int i=0; i<par->num_cluster; i++) {
	    par->mu_cluster[i] = new USED_DATA_TYPE[par->bindim];
	    par->sigma_cluster[i] = new USED_DATA_TYPE[par->bindim];
	}

	par->mu_cluster[0][0] = 10; par->mu_cluster[0][1] = 10;
	par->mu_cluster[1][0] = 10; par->mu_cluster[1][1] = 0;
	par->mu_cluster[2][0] = 0; par->mu_cluster[2][1] = 10;
	par->mu_cluster[3][0] = 0; par->mu_cluster[3][1] = 0;
	for (int i=0; i<par->num_cluster; i++) {
		par->sigma_cluster[i][0] = 2;
		par->sigma_cluster[i][1] = 2;

	}
	par->size_cluster[0] = 571;
	par->size_cluster[1] = 143;
	par->size_cluster[2] = 143;
	par->size_cluster[3] = 143;

	    
	point_coordinates = new USED_DATA_TYPE* [par->binsize];
	if (point_coordinates == NULL) {
	    cerr << "Testset: Memory allocation failed" << endl;
	    exit(0);
	}
	int ctr = 0;
	for (int i=0; i<par->num_cluster; i++) {
	    
	    for (int j=0; j<par->size_cluster[i]; j++) {
		point_coordinates[ctr] = new USED_DATA_TYPE[par->bindim];
		if (point_coordinates[ctr] == NULL) {
		    cerr << "Testset: Memory allocation failed" << endl;
		    exit(0);
		}
		point_coordinates[ctr][0] = par->mu_cluster[i][0] + gasdev(&idum)*par->sigma_cluster[i][0];
		point_coordinates[ctr][1] = par->mu_cluster[i][1] + gasdev(&idum)*par->sigma_cluster[i][1];
		ctr++;
	    }
	}
    }


    // sizes3
    else if (strcmp(name, "sizes3") == 0) {
	par->num_cluster = 4;
	par->kclusters = 4;
	par->binsize = 1000;
	par->bindim = 2;
	par->mu_cluster = new USED_DATA_TYPE * [par->num_cluster];
	par->sigma_cluster = new USED_DATA_TYPE * [par->num_cluster];
	par->size_cluster = new int[par->num_cluster];
	
	for (int i=0; i<par->num_cluster; i++) {
	    par->mu_cluster[i] = new USED_DATA_TYPE[par->bindim];
	    par->sigma_cluster[i] = new USED_DATA_TYPE[par->bindim];
	}

	par->mu_cluster[0][0] = 10; par->mu_cluster[0][1] = 10;
	par->mu_cluster[1][0] = 10; par->mu_cluster[1][1] = 0;
	par->mu_cluster[2][0] = 0; par->mu_cluster[2][1] = 10;
	par->mu_cluster[3][0] = 0; par->mu_cluster[3][1] = 0;
	for (int i=0; i<par->num_cluster; i++) {
		par->sigma_cluster[i][0] = 2;
		par->sigma_cluster[i][1] = 2;

	}
	par->size_cluster[0] = 667;
	par->size_cluster[1] = 111;
	par->size_cluster[2] = 111;
	par->size_cluster[3] = 111;

	    
	point_coordinates = new USED_DATA_TYPE* [par->binsize];
	if (point_coordinates == NULL) {
	    cerr << "Testset: Memory allocation failed" << endl;
	    exit(0);
	}
	int ctr = 0;
	for (int i=0; i<par->num_cluster; i++) {
	    
	    for (int j=0; j<par->size_cluster[i]; j++) {
		point_coordinates[ctr] = new USED_DATA_TYPE[par->bindim];
		if (point_coordinates[ctr] == NULL) {
		    cerr << "Testset: Memory allocation failed" << endl;
		    exit(0);
		}
		point_coordinates[ctr][0] = par->mu_cluster[i][0] + gasdev(&idum)*par->sigma_cluster[i][0];
		point_coordinates[ctr][1] = par->mu_cluster[i][1] + gasdev(&idum)*par->sigma_cluster[i][1];
		ctr++;
	    }
	}
    }


    // sizes4
    else if (strcmp(name, "sizes4") == 0) {
	par->num_cluster = 4;
	par->kclusters = 4;
	par->binsize = 1000;
	par->bindim = 2;
	par->mu_cluster = new USED_DATA_TYPE * [par->num_cluster];
	par->sigma_cluster = new USED_DATA_TYPE * [par->num_cluster];
	par->size_cluster = new int[par->num_cluster];
	
	for (int i=0; i<par->num_cluster; i++) {
	    par->mu_cluster[i] = new USED_DATA_TYPE[par->bindim];
	    par->sigma_cluster[i] = new USED_DATA_TYPE[par->bindim];
	}

	par->mu_cluster[0][0] = 10; par->mu_cluster[0][1] = 10;
	par->mu_cluster[1][0] = 10; par->mu_cluster[1][1] = 0;
	par->mu_cluster[2][0] = 0; par->mu_cluster[2][1] = 10;
	par->mu_cluster[3][0] = 0; par->mu_cluster[3][1] = 0;
	for (int i=0; i<par->num_cluster; i++) {
		par->sigma_cluster[i][0] = 2;
		par->sigma_cluster[i][1] = 2;

	}
	par->size_cluster[0] = 727;
	par->size_cluster[1] = 91;
	par->size_cluster[2] = 91;
	par->size_cluster[3] = 91;

	    
	point_coordinates = new USED_DATA_TYPE* [par->binsize];
	if (point_coordinates == NULL) {
	    cerr << "Testset: Memory allocation failed" << endl;
	    exit(0);
	}
	int ctr = 0;
	for (int i=0; i<par->num_cluster; i++) {

	    
	    for (int j=0; j<par->size_cluster[i]; j++) {
		point_coordinates[ctr] = new USED_DATA_TYPE[par->bindim];
		if (point_coordinates[ctr] == NULL) {
		    cerr << "Testset: Memory allocation failed" << endl;
		    exit(0);
		}
		point_coordinates[ctr][0] = par->mu_cluster[i][0] + gasdev(&idum)*par->sigma_cluster[i][0];
		point_coordinates[ctr][1] = par->mu_cluster[i][1] + gasdev(&idum)*par->sigma_cluster[i][1];
		ctr++;
	    }
	}
    }


    // sizes5
    else if (strcmp(name, "sizes5") == 0) {
	par->num_cluster = 4;
	par->kclusters = 4;
	par->binsize = 1000;
	par->bindim = 2;
	par->mu_cluster = new USED_DATA_TYPE * [par->num_cluster];
	par->sigma_cluster = new USED_DATA_TYPE * [par->num_cluster];
	par->size_cluster = new int[par->num_cluster];
	
	for (int i=0; i<par->num_cluster; i++) {
	    par->mu_cluster[i] = new USED_DATA_TYPE[par->bindim];
	    par->sigma_cluster[i] = new USED_DATA_TYPE[par->bindim];
	}

	par->mu_cluster[0][0] = 10; par->mu_cluster[0][1] = 10;
	par->mu_cluster[1][0] = 10; par->mu_cluster[1][1] = 0;
	par->mu_cluster[2][0] = 0; par->mu_cluster[2][1] = 10;
	par->mu_cluster[3][0] = 0; par->mu_cluster[3][1] = 0;
	for (int i=0; i<par->num_cluster; i++) {
		par->sigma_cluster[i][0] = 2;
		par->sigma_cluster[i][1] = 2;

	}
	par->size_cluster[0] = 769;
	par->size_cluster[1] = 77;;
	par->size_cluster[2] = 77;;
	par->size_cluster[3] = 77;;

	    
	point_coordinates = new USED_DATA_TYPE* [par->binsize];
	if (point_coordinates == NULL) {
	    cerr << "Testset: Memory allocation failed" << endl;
	    exit(0);
	}
	int ctr = 0;
	for (int i=0; i<par->num_cluster; i++) {
    
	    for (int j=0; j<par->size_cluster[i]; j++) {
		point_coordinates[ctr] = new USED_DATA_TYPE[par->bindim];
		if (point_coordinates[ctr] == NULL) {
		    cerr << "Testset: Memory allocation failed" << endl;
		    exit(0);
		}
		point_coordinates[ctr][0] = par->mu_cluster[i][0] + gasdev(&idum)*par->sigma_cluster[i][0];
		point_coordinates[ctr][1] = par->mu_cluster[i][1] + gasdev(&idum)*par->sigma_cluster[i][1];
		ctr++;
	    }
	}
    }
    
    
 

	       
    else {
	cout << "Unknown data set: " << name << endl;
	exit(0);
    }

   

}


double mysquare(double x) {
  return x*x;
}
