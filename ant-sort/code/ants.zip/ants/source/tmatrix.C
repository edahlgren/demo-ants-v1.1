/*  Ant-based Clustering
    Copyright (C) 2004 Julia Handl
    Email: Julia.Handl@gmx.de

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include "tmatrix.h"

// Konstruktor - Allocation of memory
tmatrix::tmatrix(const int s) {
  data = new float *[s];
  size = s;
  for (int i=0; i<s; i++) {
    data[i] = new float [i+1];
  }
  
  for (int i=0; i<s; i++) {
	  for (int j=0; j<=i; j++) {
      data[i][j] = 0;
	  }
  }
}

// Copy-Konstruktor
tmatrix::tmatrix(const tmatrix &t) {
	data = new float *[t.size];
	size = t.size;
	for (int i=0; i<size; i++) {
	    data[i] = new float [i+1];
	}

  for (int i=0; i<size; i++) {
    for (int j=0; j<=i; j++) {
	    data[i][j] = t.data[i][j];
    }
  }
}
           
// Destruktor
tmatrix::~tmatrix() {
  for (int i=0; i<size; i++) {
    delete [] data[i];
  }
  delete [] data;
}

/* Assignment */
void tmatrix::operator=(const tmatrix & t) {
  if (this == &t) return;
  for (int i=0; i<size; i++) {
    delete [] data[i];
  }
  delete [] data;
  
  
	data = new float * [t.size];
	size = t.size;
	for (int i=0; i<size; i++) {
    data[i] = new float [i+1];
	}
  
  for (int i=0; i<size; i++) {
    for (int j=0; j<=i; j++) {
	    data[i][j] = t.data[i][j];
    }
  }
}
    
   
// Access to data within matrix via indices (order doesn't matter)
float &tmatrix::operator()(const int i, const int j) {
  return (i < j)? data[j][i] : data[i][j];
}
  
// read matrix size
const int tmatrix::getsize() {
    return size;
}
