/*  Ant-based Clustering
    Copyright (C) 2004 Julia Handl
    Email: Julia.Handl@gmx.de

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

// For the CLI.
#include <cxxopts.hpp>

#include <iostream>
#include "conf.h"
#include "evaluation.h"
#include "accl.h"

using namespace std;

void write_positions(conf *c, evaluation *e, const char * name);
void write_clusters(conf *c, clustering * cl, int nclusters, const char * name);
long idum;

cxxopts::Options options(char * progname) {

  cxxopts::Options options(progname, " - CLI for the ATTA ant algorithm");
  options.add_options()
    ("i,input", "Name of CSV file containing data vectors", cxxopts::value<std::string>())
    ("num-ants", "Number of ants in the colony (default 10)", cxxopts::value<int>())
    ("ant-memory", "Memory of an ant (default 10)", cxxopts::value<int>())
    ("neighborhood", "Size of an ant's initial neighborhood (default 1)", cxxopts::value<int>())
    ("runs", "Number of runs of the update algorithm (default 50)", cxxopts::value<int>())
    ("iterations", "Number of iterations per run (default (40000)", cxxopts::value<int>())
    ("speed", "Max speed of an ant (default 50)", cxxopts::value<int>())
    ("grid-width", "Width of the clustering grid (default sqrt(num data vectors * 10))", cxxopts::value<int>())
    ("grid-height", "Height of the clustering grid (same as grid-width)", cxxopts::value<int>())
    ("use-cosine", "Whether to use Cosine distance (default Euclidean)", cxxopts::value<bool>());

  return options;
}

int main(int argc, char ** argv) {

  // Random number generator seed.
  idum = 4284509;

  // Keep the options scoped, otherwise the parsed
  // args get destroyed.
  cxxopts::Options opts = options(argv[0]);
  
  // Initialize the config.
  conf c;
  try {

    // Parse the options.
    cxxopts::ParseResult args = opts.parse(argc, argv);

    // Try to load them into the config.
    if (!c.load(args)) {
      // Got a problem loading the data from the arguments.
      cerr << "Failed to load data from CLI args" << endl;
      exit(1);
    }

    // Print the configuration.
    cout << "--- Configuration ---" << endl;
    cout << endl;
    c.print();
    
  } catch (const cxxopts::OptionException& e) {
    cout << "Error parsing options: " << e.what() << endl;
    exit(1);
  }

  // Initialize the data wrapper, which computes dissimilarity
  // in the data loaded by conf::load.
  databin d(&c);

  // The cluster results evaluator, to be used after accl::run.
  evaluation e(&c);
  
  cout << endl;
  cout << "--- Running ant clustering ---" << endl;
  cout << endl;
  
  // Initialize the ant colony.
  accl *antrun = new accl(&c, &d, &e);
  antrun->init();

  // Run the ant colony clustering algorithm.
  antrun->run();

  // Partition the grid into distinct clusters.
  antrun->constructclustering();

  // Initialize the results evaluator.
  e.init(&d, antrun->getmapping(), antrun->getclustering(), NULL);

  cout << endl;
  cout << "--- Results ---" << endl;
  cout << endl;
  
  // Number of clusters.
  int nclusters = e.clusternumber();
  cout << "Number of clusters: " << nclusters << endl;

  // Unsupervised clustering stats
  cout << "Variance = " << e.variance() << endl;
  cout << "Dunn Index = " << e.dunn_av() << endl;
  cout << endl;

  // Print a mapping of data items to cluster numbers.
  const char *stdout = "/dev/stdout";
  write_clusters(&c, antrun->getclustering(), nclusters, stdout);

  // Save grid positions of items to a file, for visualizations.
  const char *pos_file = "positions.csv";
  write_positions(&c, &e, pos_file);
  
  // Exit, we're done.
  return 0;
} 

void write_positions(conf *c, evaluation *e, const char * name) {
  ofstream out(name);

  // Write out the header
  out << "Item" << ","
      << "X(" << c->imax << ")" << ","
      << "Y(" << c->jmax << ")" << endl;

  // Write out each position in the grid
  for (int i = 0; i < c->binsize; i++) {
    out << c->binNames.at(i) << ","
	<< e->xpos(i) << ","
	<< e->ypos(i) << endl;
  }
}

void write_clusters(conf *c, clustering * cl, int nclusters, const char * name) {
  // Group data vecs by cluster.
  std::vector<std::vector<std::string>> clusters(nclusters);
  for (int i = 0; i < c->binsize; i++) {
    // Get cluster number.
    int cn = (*cl)[i];

    // Associate its name with the cluster.
    std::string name = c->binNames.at(i);
    clusters.at(cn).push_back(name);
  }
  
  ofstream out(name);
  for (int i = 0; i < nclusters; i++) {

    // Grab cluster.
    std::vector<std::string> &vecs = clusters.at(i);
    
    // Print cluster number.
    out << "Cluster " << (i + 1)
	<< " (" << vecs.size() << " items)"<< ":"
	<< endl;

    // Print data item names.
    for (int j = 0; j < vecs.size(); j++) {
      if ((j % 5) == 0)
	out << endl;
      
      out << "\t" << vecs.at(j);
    }
    out << endl;
    out << endl;
  }
}
