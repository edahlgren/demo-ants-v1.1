/*  Ant-based Clustering
    Copyright (C) 2004 Julia Handl
    Email: Julia.Handl@gmx.de

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

/***************************************************

date: 7.4.2003

author: Julia Handl (julia.Handl@gmx.de)

description: 
- wrapper class for all parameter settings

***************************************************/

#ifndef CONF_JH_2003
#define CONF_JH_2003

// For the CLI.
#include <cxxopts.hpp>

#include <iostream>
#include <fstream>
 
#define FALSE 0
#define TRUE 1

using namespace std;

struct conf {

  //////////////////////////////////////////////////////////
  // Fields
  //////////////////////////////////////////////////////////
  
  // General clustering paramters for ATTA.
  const static int clustering = TRUE;
  const static int newprob = TRUE;
  const static int increase = TRUE;
  const static int weighting = FALSE;
  const static int adaptalpha = TRUE;
  const static int lookahead = TRUE;
  int initradius;
  
  // Parameters used by ACCL
  constexpr static double kd = 0.3;
  constexpr static double kp = 0.3;
  const static int maxfailure = 100;
  
  int colonysize;
  int memorysize;
  int clusterphase;
  int maxspeed;
  double alpha;
  double alphasigma;
  int generations;
  int generation_length;
  int radius;

  // Grid parameters
  int imax;
  int jmax;

  // Data parameters
  int binsize;
  int bindim;
  std::vector<std::string> binNames;
  std::vector<std::vector<float>> bin;
  int use_cosine;
  
  // FIXME: filled in by databin.
  float mu;
  float max;

  // Supervised only: see evaluation.C
  int kclusters = 0;
  int *size_cluster;
  
  // Whether data was loaded.
  int loaded = 0;
  
  // Files
  std::string dataFile;

  //////////////////////////////////////////////////////////
  // Methods
  //////////////////////////////////////////////////////////

  // Print the configuration.
  void print();
  
  // Initialize the configuration from CLI args.
  // Where the magic happens.
  int load(cxxopts::ParseResult args);

  // Name of the ith vector parsed from the data file, for
  // displaying results.
  std::string vectorName(int i) {
    return binNames.at(i);
  }
};

#endif
