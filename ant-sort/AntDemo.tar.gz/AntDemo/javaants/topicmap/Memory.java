/*  
    Copyright (C) 2004 Julia Handl
    Email: Julia.Handl@gmx.de

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

/*****************************************************************
	Julia Handl - 18004385
	Monash University, 1.7.2001

	File: Memory.java
	Package: JavaAnts.TopicMap

	Description:

	* Ant memory
	* Stores the last handled data elements and their positions
	* Used to bias the random walk
	* Stors the current bias and the current "best remembered" position
		
                                                                                                                     	
*****************************************************************/

package javaants.topicmap;

import javaants.Position;
import javaants.Document;
import javaants.Configuration;
import java.lang.*;
import java.io.*;


/** Ant Memory */
public class Memory implements Serializable {
	private boolean init;				// Memory should be fully initialised before it is used
	private Position [] pos;			// Stored document positions
	private int [] doc;					// Stored document numbers
	private int next;					// next free memory position (or next to overwrite respectively)
	private int size;					// memory size
	private Document[] documents;		// Document vector (to look up similarities)

	private boolean oriented;			// is the match good enough that I rely on my memory?
	private Position target;			// current memorized target position
	private double bias;				// current bias (how good was the match?)
	
	private Grid grid;
	private Configuration conf;

/****************** Constructor **************************************************************/

	/** Constructor
	* @param size the memory size
	* @param documents the current documents in the ant's environment
	* @param grid the ant's current environment	
	* @param c the current parameter settings
	*/
	public Memory(int size, Document[] documents, Grid grid, Configuration c) {
		this.size = size;
		this.pos = new Position[size];
		this.doc = new int[size];
		this.next = 0;
		this.init = true;
		this.oriented = false;
		this.documents = documents;
		this.target = new Position();
		this.grid = grid;
		this.conf = c;
		for (int i=0; i< size; i++) {
			this.pos[i] = new Position();
		}
	
	}


/************ access functions ***************************************************************/

	/** Flag: Use memory or not?
	* @return retures true if the memory is readily initialised and oriented towards a target position */
	public boolean isOriented() {
		return this.oriented;
	}

	/** In which direction to go?
	* @param pos storage space: the target position will be stored in here
	*/
	public void targetPos(Position pos) {
		pos.set(this.target);
		return;
	}

	/** How goog is the memory position?
	* @return return the current bias
	*/
	public double getBias() {
		return this.bias;
	}


/************ modification functions ***************************************************************/

	/** Set flag: Activate or deactivate memory
	* @param bool the new flag value
	*/
	public void setOriented(boolean bool) {
		this.oriented = bool;
	}

	/** Store a new document and its position in the memory
	* @param doc the document number
	* @param pos the document position
	*/
	public void store(int doc, Position pos) {
		if (this.size == 0) return;
		this.doc[next] = doc;
		this.pos[next].set(pos);
		next++;
		if (next == this.size) {
			init = false;
			next = 0;
		}
	}

	/** Look up best match for the currently picked up document
	* @param current the number of the picked document
	*/
	public void orient(int current) {
		double dist;
		double min;

		if (this.size == 0) return;
		Position minpos = new Position();
		
		if ( !this.init ) {
			min = grid.distance(current, this.doc[0]);
			minpos.set(this.pos[0]);
			for (int i=1; i<this.size; i++) {
				dist = grid.distance(current, this.doc[i]);
				// check whether match is better
				if (dist < min) {
					min = dist;
					minpos.set(this.pos[i]);
				}
			}
			this.oriented = true;
			this.target.set(minpos);
			this.bias = 1.0 /  (1.0 + min/conf.getdistscale());
			
		}
	}
	
	/**
	* Orient the memory for a document and get the newly determined target position
	* @param current the number of the considered document
	* @param pos storage space for the target positions
	*/
	public void getBestMatchPosition(int current, Position pos) {
		orient(current);
		pos.set(this.target);
		return;
	}
	
}
