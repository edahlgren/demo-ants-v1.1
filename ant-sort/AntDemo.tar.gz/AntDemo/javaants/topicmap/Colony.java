/*  
    Copyright (C) 2004 Julia Handl
    Email: Julia.Handl@gmx.de

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

/*****************************************************************
	Julia Handl - 18004385
	Monash University, 1.7.2001

	File: Colony.java
	Package: JavaAnts.TopicMap

	Description:

	* Represents the entire ant colony
	* Contains an array of ants
	* Stores pointer to the environment
	* Environment provides all necessary information (e.g. density)
	* Ant provides their own actions
		
                                                                                                                        	
*****************************************************************/

package javaants.topicmap;

import javaants.Document;
import javaants.Position;
import javaants.Configuration;
import java.lang.*;
import java.io.*;

/** Ant-Colony Model */
public class Colony implements Serializable {

	private Ant [] ants;					// Array of ants
		
	// Pointers to the environment
	private Configuration conf;   			// Configuration
	private Document [] documents;          // available data elements
	private Grid grid;                      // Grid
	private boolean adapt = true;
	private boolean init = true;
	private boolean inita = true;
	private double limit;
	
	
	
/************** Constructor ************************************************************/	

	/** Constructor
	* @param conf the current paramter setting
	* @param grid the colony's environment
	* @param documents the document data in the environment
	*/
	public Colony(Configuration conf, Grid grid, Document [] documents) {
		Position pos = new Position();
	
		this.conf = conf;
		this.grid = grid;
		this.documents = documents;
		
		if (conf.getadaptalpha() == true) {
			this.conf.setalpha(conf.getalphastart());
			adapt = true;
			limit = 0.5*Math.abs(this.conf.getalphaend()-this.conf.getalphastart())/this.conf.getalphainterval();
			System.out.println(limit);
		}
		else this.adapt = false;
		

		int ctr = 0;
				
		this.ants = new Ant[this.conf.getnants()];

		for (int i = this.conf.getndocs()-this.conf.getnants(); i < this.conf.getndocs(); i++) {
	
			// ants have already been advised random positions (Grid Constructor)
			grid.getPos(i, pos);
				
			// initialize each ant: speed, current load, current position and pointers to the environment
			if (this.conf.gethomogenous() == false) {
			        this.ants[ctr++] = new Ant(grid, (int)Math.ceil(Math.random()*this.conf.getspeed()), pos, i, documents, conf);
			}
			else {
				this.ants[ctr++] = new Ant(grid, this.conf.getspeed(), pos, i, documents, conf);
			}
			// hence, the data element is removed from the grid
			grid.remove(pos);
		}
	}


/************* small access function *****************************************************************/	
	
	/** Tell me all the members of this colony
	* @return array of all ants
	*/
	public Ant [] getAnts() {
		return this.ants;
	}


/************* Sorting functions *****************************************************************/		
	
	
    /** Ant-Q
    *
    */
	public void sort() {
		int select, index;
		int dropctr = 0;
		int adaptctr = 1;
		int actionctr = 0;
		
		Position oldpos = new Position();
		Position newpos = new Position();
		
		// adapive kd and kp
		if (this.conf.getadaptk() == true) {
			if (adapt == false)  {
		
				if (init == true) {
					this.conf.setkp(this.conf.getkpstart());
					this.conf.setkd(this.conf.getkdstart());
					init = false;
				}
					
				double kd = this.conf.getkd();
				double kp = this.conf.getkp();
				double kdinterval = 0;	
				double kpinterval = 0;

				if ((kdinterval = this.conf.getkdinterval()) >= 0.0) {
					if (kd > this.conf.getkdend()) {
						this.conf.setkd(kd-kdinterval);
						if (conf.getTest() == true) System.out.println("Update: kd = " + this.conf.getkd());
					}
				}
				else {
					if (kd < this.conf.getkdend()) {
						this.conf.setkd(kd-kdinterval);
						if (conf.getTest() == true) System.out.println("Update: kd = " + this.conf.getkd());
					}
				}
				if ((kpinterval = this.conf.getkpinterval()) >= 0.0) {
					if (kd > this.conf.getkpend()) {
						this.conf.setkp(kp-kpinterval);
						if (conf.getTest() == true) System.out.println("Update: kp = " + this.conf.getkp());
					}
				}
				else {
					if (kp < this.conf.getkpend()) {
						this.conf.setkd(kp-kpinterval);
						if (conf.getTest() == true) System.out.println("Update: kp = " + this.conf.getkp());
					}
				}
			}
		}
		// main loop
		for (int k = 0; k< conf.getiterations(); k++) {

				if (this.conf.getadaptalpha() == true) {
				// check whether alpha has to be adapted
				
					if (adaptctr == 250)  {
						double interval = 0;
						if ((interval = this.conf.getalphainterval()) >= 0.0) {
							
							if ((adapt == true) && (actionctr <= limit) && (this.conf.getalpha() < conf.getalphaend())) {
								limit *= (1.0 - actionctr / limit);
								this.conf.setalpha(this.conf.getalpha() + interval);
								System.out.println("Update: alpha = " + this.conf.getalpha());
							}
							else adapt = false;
							
							adaptctr = 0;
							actionctr = 0;
						}
						else {
							if ((adapt == true) && (actionctr <= limit) && (this.conf.getalpha() > conf.getalphaend())) {
								limit--;
								this.conf.setalpha(this.conf.getalpha() + interval);
								System.out.println("Update: alpha = " + this.conf.getalpha());
							}
							//else adapt = false;
							adaptctr = 0;
							actionctr = 0;
						}
					}
				}

				adaptctr++;

				// chose one ant randomly
				select = (int)Math.floor(Math.random()*conf.getnants());

				// try to drop its burden
				if (ants[select].drop() == true) {
					if (ants[select].getReset() == false) {
						dropctr++;
						actionctr++;
					}

					// save old position
					ants[select].getPosition(oldpos);

					// select new document (by index)
					index = (int)Math.floor(Math.random()*(this.conf.getndocs()-conf.getnants()));

					// go to the position of selected document
					grid.getPos(index, newpos);
					ants[select].setPosition(newpos);

					// try to pick the document up
					while (ants[select].pick() == false) {
						// try the next one
						index = (int)Math.floor(Math.random()*(this.conf.getndocs()-conf.getnants()));
						grid.getPos(index, newpos);
						ants[select].setPosition(newpos);
					}

					// insert old document in the index
					grid.setPos(oldpos, index);
		
				}

				// let the ant move
				ants[select].step();
				
			}
			if (conf.getTest() == true) System.out.println("DropCtr: " + dropctr);
		
		
	}	


	/** Original ant-algorithm */
	public void oldsort() {
		int select, load;
		int dropctr = 0;
	
		Position oldpos = new Position();
		Position newpos = new Position();
	
		// Main Loop
		for (int k = 0; k< conf.getiterations(); k++) {

				// chose one ant randomly
				select = (int)Math.floor(Math.random()*this.conf.getnants());
				load = ants[select].getLoad();

				// if ant carries sth, ty to drop it
				if ( load != -1) {
					if (ants[select].drop() == true) {
						dropctr++;
						ants[select].getPosition(oldpos);
						grid.setPos(oldpos, load);
					}
				}
				// otherwise try to pick sth up
				else ants[select].pick();
				
				ants[select].step();
			}
			
		
	}


	/* Make the ants drop all elements before generating the topic map */
    public void finish() {
		int select;

		for (select = 0; select < conf.getnants(); select++) {
		
				ants[select].finish();

		}
	
     }
	/* Restart sorting process after a user interruption */
     public void resume() {
		int select;
							
		for (select = 0; select < conf.getnants(); select++) {
		
				ants[select].resume();

		}
	
     }






}
