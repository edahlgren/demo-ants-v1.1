package javaants.topicmap;
import java.awt.*;
import java.awt.event.*;

/** Close the associated window */
public class WindowCloser extends WindowAdapter {
    public void windowClosing(WindowEvent e) {
      	System.exit(0);
    }
 }



