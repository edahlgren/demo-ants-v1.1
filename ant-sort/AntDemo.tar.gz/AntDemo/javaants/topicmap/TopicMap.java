/*  
    Copyright (C) 2004 Julia Handl
    Email: Julia.Handl@gmx.de

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

/*****************************************************************
	Julia Handl - 18004385
	Monash University, 1.7.2001

	File: TopicMap.java
	Package: JavaAnts.TopicMap

	Description:

	* Topic Map Visualization
	* Uses underlying grid
	* Provides several measurement functions
	
                                                                                                                     	
*****************************************************************/

package javaants.topicmap;

import javaants.*;

import java.lang.*;
import java.util.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import javax.swing.*;
import java.net.URL;
import java.io.*;

/** Wrapping class for the document and ant data. Also contains the basic grid
*/
public class TopicMap extends Canvas implements Runnable  {

	private Colony antColony;			/* the active ant colony */
	private Grid grid;					/* the active grid */
	private String [] keywords;			/* the current keywords */
	private Document [] documents;		/* the current documents */
	private Configuration conf;			/* all parameter settings */
	private BufferedImage bi; 			/* use of a buffered image to avoid recomputation */
   	private boolean stop = false;		/* user interrupt */
   	private boolean antMode = true;		/* choice of sorting method */
	private boolean activated = true;	/* activate mouse event listener only with completed map */
	private boolean interrupt = false;	/* keep track of user interrrups */
	private Frame contourframe;			/* pointer to the final topic map frame */

		
/********************** Constructor **************************************************************/
	
	/**
	* Default Constructor: Data has to be read from disk
	* @param contourframe the frame employed for the display of the final topic map
	*/
	public TopicMap() {
		this.activated = false;
	}

	/** Constructor
	* @param conf the current parameter settings
	* @param keywords the keywords spanning document space
	* @param antMode switch between ant and MDS mode
	* @param documents the current documents
	*/
	public TopicMap(Configuration conf, String [] keywords,  Document [] documents, boolean antMode, DistanceMatrix d) {

		this.antMode = antMode;
		this.setBackground(Color.lightGray);
		this.keywords = keywords;
		this.documents = documents;
		this.conf = conf;

		this.grid = new Grid(conf, documents, antMode, d);

	
		// new colony
		this.antColony = new Colony(conf, this.grid, documents);
		this.activated = false;
		

		this.setSize(conf.getxsize()*5,conf.getysize()*5);
	
		
		
	}

	/** Constructor
	* @param conf the current parameter settings
	* @param keywords the keywords spanning document space
	* @param documents the current documents
	* @param antMode switch between ant and MDS mode
	* @param interrupt flag indicating interrupted sorting
	* @param contourframe the frame employed for the display of the final topic map
	* @param grid the current underlying grid
	* @param colony the current antColony
	*/
	public TopicMap(Configuration conf, String [] keywords,  Document [] documents, boolean antMode, boolean interrupt, Grid grid, Colony antColony) {

		this.antMode = antMode;
		this.interrupt = interrupt;
		this.setBackground(Color.lightGray);
		this.keywords = keywords;
		this.documents = documents;
		this.conf = conf;

		this.grid = grid;

	
		//  new colony
		this.antColony = antColony;
		this.activated = false;
		this.setSize(conf.getxsize()*5,conf.getysize()*5);

		
	
	
	}
	
	/**
	* Enable clicking on the map
	* @param value the new flag value (enabled = true, disabled = false)
	*/
	public void setActivated(boolean value) {
		this.activated = value;
	}
	





/******************* access functions *************************************************************/
	
	/** Return the mean dissimilarity of the current document collection (compute by class grid)
	* @return the mean dissimilarity used for scaling
	*/
	public double getScaleFactor() {
		return grid.getScaleFactor();
	}
	/** Return the underlying grid
	* @return the current grid
	*/
	public Grid getGrid() {
		return this.grid;
	}
	/** Return the current image
	* @return the employed buffered image
	*/
	public BufferedImage getImage() {
		return this.bi;
	}
	/** Return the paramter settings
	* @return the current configuration
	*/
	public Configuration getConfiguration() {
		return this.conf;
	}
	/** Return the current document data
	* @return the array of documents
	*/
	public Document [] getDocuments() {
		return this.documents;
	}
	/*** Return the current keywords spanning document space
	* @param the array of keywords
	*/
	public String [] getKeywords() {
		return this.keywords;
	}
	/** Return the value of the flag indicating whether ant-mode is active
	* @return true if ant-based clustering is active
	*/
	public boolean getAntMode() {
		return this.antMode;
	}



/************ action ..... *********************************************************************/

	/** Reinitialisation of the topic map
	* @param config the new parameter setting
	* @param keywds the new keywords
	* @param the new document data
	*/
	public void init(Configuration config, String [] keywds,  Document [] docs, DistanceMatrix d) {
	
		if (antMode == false) return;

		this.keywords = keywds;
		this.documents = docs;
		this.conf = config;
		this.grid = new Grid(conf, documents, true, d);
		
		this.antColony = new Colony(conf, this.grid, documents);
	
		this.setSize(conf.getxsize()*5,conf.getysize()*5);
			
		paint(this.getGraphics());

	}

	/** Interrupt ant-based sorting process
	*/
	public void stop() {
	    stop = true;
	}

	/** Start ant-based sorting process
	*/
	public void run() {
	
		if (antMode == false) return;
		activated = false;
	   	stop = false;
	   	   	
	   	// resume after user interrupt
	   	if (interrupt == true) {
	   	
	   		interrupt = false;
	   		this.antColony.resume();
	   	}
		

		// check runtime
		long start = System.currentTimeMillis();	
	     	
		int i=0;
		int mode = conf.getMethod();
				
		// Main Loop, stop after max iterations or at user interrupt
		while(( stop == false ) && (i < conf.getruns())) {
			
			System.out.println(i++);
			if ( mode != 1) {
				this.antColony.sort();
			}
			else {
				this.antColony.oldsort();
			}
			paint(this.getGraphics());
			documentUpdate();
		   	
		}
	
		interrupt = true;
		this.antColony.finish();	
		long end = System.currentTimeMillis();
		System.out.println("Evaluation took " + (end - start) + " milliseconds");
	
		System.out.println("Pearson correlation: " + computePearson(false));
			
		this.activated = true;

		
	
	}


	


	/** Keep track of document positions (update document variable using grid information)
	*/
	public void documentUpdate() {
		int docnbr;

		// update positions of all inactive documents
		for (int i=0; i < conf.getysize(); i++) {
			for (int j =0; j< conf.getxsize(); j++) {
				if ( !grid.free(i, j) ) {
					// get grid position
					docnbr = grid.at(i, j);

					// use for update of document position
					documents[docnbr].setPosition(i, j);
				}
			}
		}

		// update positions of all active documents
		Ant [] ants = antColony.getAnts();
		Position pos = new Position();
		for (int i=0; i< conf.getnants(); i++) {
			docnbr = ants[i].getLoad();
			if (docnbr != -1) {
				// get ant position
				ants[i].getPosition(pos);

				// use for update of ant position
				documents[docnbr].setPosition(pos);
			}
		}
	}

	// paint the map
	public void paint(Graphics g){
        Graphics2D g2 = (Graphics2D)g;

		if ((bi == null) || ((activated != true) || (antMode == false))) {

	        bi = (BufferedImage)createImage(this.conf.getxsize()*5, this.conf.getysize()*5);
		
    	   	 int color, xpos, ypos;
      		Graphics ghelp = bi.createGraphics();
      		// paint all documents (one grid cell has a size of 5 x 5 pixel)
			for (int i=0; i < conf.getysize(); i++) {
				for (int j =0; j< conf.getxsize(); j++) {
					color = grid.getColor(i, j);

					// artificial data: different colours used
					if (color != 0) {
						
						switch(color) {
							case 1: color = Color.black.getRGB();  break;
							case 2: color = Color.blue.getRGB();break;
							case 3: color = Color.red.getRGB(); break;
							case 4: color = Color.green.getRGB(); break;
							case 5:	color = Color.magenta.getRGB(); break;
							case 6: color = Color.orange.getRGB(); break;
							case 7: color = Color.cyan.getRGB(); break;
							case 8: color = Color.gray.getRGB(); break;
							case 9: color = Color.pink.getRGB(); break;
							case 10: color = Color.lightGray.getRGB(); break;
						}
						xpos = j*5;
						ypos = i*5;
				 		for (int yd=ypos; yd< ypos+5; yd++) {
        					for (int xd=xpos; xd < xpos+5; xd++) {
	        					bi.setRGB(xd,yd,color);
					
    	    				}
        				}
        			}
        		}
        	}
        

		       // paint ants as black spots
		/*	if (antMode == true) {
	   		    Ant [] ants = antColony.getAnts();
        		Position pos = new Position();
        		for (int i=0; i < conf.getnants();i++) {
        			ants[i].getPosition(pos);
					xpos = pos.getX()*5; 
					ypos = pos.getY()*5; 
					for (int yd=ypos; yd< ypos+5; yd++) {
        				for (int xd=xpos; xd < xpos+5; xd++) {
	        				bi.setRGB(xd,yd,Color.black.getRGB());
    	    			}
        			}
        		}
    		}*/
    	}
	    g2.drawImage(bi, 0, 0, this);
	}

/************ Measurements & Plots ******************************************************/


	/** Compute Pearson correlation
	* @return Pearson correlation computed for the entire grid
	* @param ignore the positions of documents that are currently picked up
	*/
	public double computePearson(boolean ignore) {
		double xsum = 0;
		double ysum = 0;
		double xysum = 0;
		double diff = 0;
		double xsquaresum = 0;
		double ysquaresum = 0;
		double N = 0;
		
		
		for (int i=0; i < conf.getndocs(); i++) {
			if (ignore == true) {
				if (documents[i].isPicked() == true) continue;
			}
			for (int j=0; j < i; j++) {
				if (ignore == true) {
					if (documents[j].isPicked() == true) continue;
				}
				N++;
				double x = Math.abs(grid.distance(i,j));
				double y = Math.abs(documents[i].currentDistance(documents[j], conf.getysize(), conf.getxsize()));
				xsum += x;
				xsquaresum += (x*x);
				ysum += y;
				ysquaresum += (y*y);
				xysum += (x*y);
			}
		}
		double num = xysum - xsum*ysum/N;
		double denom = Math.sqrt((xsquaresum - xsum*xsum/N)*(ysquaresum-ysum*ysum/N));
		if (denom == 0) return 0;
		return num / denom ;
	}

}





