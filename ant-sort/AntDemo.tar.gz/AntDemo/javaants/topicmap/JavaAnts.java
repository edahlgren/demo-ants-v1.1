/*  
    Copyright (C) 2004 Julia Handl
    Email: Julia.Handl@gmx.de

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

/*****************************************************************
	Julia Handl - 18004385
	Monash University, 1.7.2001

	File: JavaAnts.java
	Package: JavaAnts.TopicMap

	Description:

	* Main program and GUI

		
                                                                                                                     	
*****************************************************************/

package javaants.topicmap;

import javaants.*;
import javaants.exception.*;
import java.lang.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
   
/** Main program and GUI */
public class JavaAnts {
	
	private static TopicMap map;					// current topic map
	private static Configuration configuration;		// parameter configuration

	private static Data data;					// current data collection
	private static String [] keywords;			// current keywords
	private static Document [] documents;		// current documents
	
	private static Frame frame;

	
	private static boolean init = false;			// is map already initialized?
	private static boolean antMode = true;			// shall I use ants?


	
	

	/** Main routine
	* @param no arguments necessary
	*/
	public static void main(String args[]) {
	
		try {
	    		UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			
       		} catch (Exception e) {
       		
       			/// dann halt nicht ....
       		}

		try {

	

		// create configuration
 	   	configuration = new Configuration();
    		Configuration c = configuration.read();
  		if (c != null) configuration = c;
    		
		// create frame and menu bars

		frame = new Frame();
		frame.setTitle("Ant-based clustering");
    		frame.setBackground(Color.lightGray);
    		frame.setLayout(new BorderLayout());
    		MenuBar antBar = new MenuBar();

   		// File menu
		Menu file = new Menu("Data");
		

		// Work with hardcoded test data
    		MenuItem create = new MenuItem("Generate Test Data");
    		create.addActionListener(new ActionListener() {
    		public void actionPerformed(ActionEvent event) { 
				
  			
	  			
    				configuration.setTextMode(0);
    				data = generate(configuration.getchoice());

    				if (configuration.getchoice() == 0) {
    					configuration.setTestData(true);
    				}
    				else {
    					configuration.setTestData(false);
	    			}
    				
  				init(false,"");

      		}});
    		file.add(create);
 	
  		antBar.add(file);
  		
  		
    		Menu dist = new Menu("Mode");
    		// Toggle between Ants versions
			MenuItem toggle = new MenuItem("Ant-Q");
			toggle.addActionListener(new ActionListener() {
  			public void actionPerformed(ActionEvent e) {
  				
  			 			  			
				configuration.setMethod(0);
				System.out.println("Switching to Ant-Q Mode");
				antMode = true;
      				if (init == true) init(false,"");
      			
      			
   			}});
   			MenuItem toggle1 = new MenuItem("Ants");
			toggle1.addActionListener(new ActionListener() {
  			public void actionPerformed(ActionEvent e) {
  								
  			  			
				configuration.setMethod(1);
				System.out.println("Switching to Ant Mode");
				antMode = true;
				
				
				if (init == true) init(false,"");
      			
      			
   			}});
		
   		
   			dist.add(toggle);
  			dist.add(toggle1);
			antBar.add(dist);
    		

    			

		// Configuration menu
    		Menu confs = new Menu("Configuration"); 

    		// Allow configuration modifications
    		MenuItem ant = new MenuItem("Modify");
    		ant.addActionListener(new ActionListener() {
  			public void actionPerformed(ActionEvent e) {

    			
      				new ConfDialog(configuration, frame, map, init);
      				init = false;
      			
      				
      				
  			}});
      		confs.add(ant);	
		antBar.add(confs);
	    
    		// Execute menu
  		Menu execute = new Menu("Ants");

  		// Scatter the documents randomly on the map
  	      	MenuItem scatter = new MenuItem("Scatter Documents");
	       	scatter.addActionListener(new ActionListener(){
  	       	 	public void actionPerformed(ActionEvent event) {
  
  	       	 		try {
  	       	 			if (antMode == false) throw new WrongModeException();
  	       	 			
  	       	 			if (init == false) throw new NoInitException();
  	       	 			if (init == true) init(false,"");
  	       	 			  	       	 			
  	       	 		} catch (NoInitException e) {
  	       	 			System.out.println(e.getMessage());
  	       	 	    } catch(WrongModeException e) {
				System.out.println(e.getMessage());
			}	

      	         }});
      		execute.add(scatter);

      		// Run ants as own thread
  			MenuItem run = new MenuItem("Start / Resume Sorting");
  			run.addActionListener(new ActionListener() {
  			public void actionPerformed(ActionEvent event) {
	  	
  				try {
  			 		if (init == false) throw new NoInitException();
  			 		if (antMode == false) throw new WrongModeException();
					       
					new Thread(map).start();
				} catch (NoInitException e) {
					System.out.println(e.getMessage());
  				} catch(WrongModeException e) {
					System.out.println(e.getMessage());
				}
			}});
  			execute.add(run);

  			// Halt execution of ants sorting
			MenuItem stop = new MenuItem("Stop Sorting");
			stop.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent event) {
				    try {
			    		if (init == false) throw new NoInitException();
			    		if (antMode == false) throw new WrongModeException();
						map.stop();
			    	} catch (NoInitException e) {
						System.out.println(e.getMessage());
			    	} catch(WrongModeException e) {
						System.out.println(e.getMessage());
					}
			}});
			execute.add(stop);
			

			antBar.add(execute);

	
    
    		// Help menu
    		Menu info = new Menu("Info");
    		MenuItem help = new MenuItem("Help");
    		final String helpstring =
    					"How to use (step by step):\n\n" +
    					"1) Specify operating mode." +
    					"   Menu: Mode -> (Ant-Q | Ants)\n" +
    					"2) Specify configuration settings if desired. Otherwise default options are used." +
    					"   Menu: Configuration->Modify\n" +
    					"3) Generate an artificial data set using Data -> Generate Test Data\n" +
    					"4) Start sorting, stop it and possibly restart it." +
    					"   Menu: Ants -> (Start sorting | Stop sorting | Scatter)\n\n\n" +
 	   					"Additional info:\n\n" +
						"- Ants: Basic ant-based clustering algorithm\n" +
						"- Ant-Q: Extended ant-based clustering algorithm (described in Handl and Meyer 2002)\n\n";

   					    	
    					
    					
    					
    		help.addActionListener(new ActionListener() {
    			 public void actionPerformed(ActionEvent event) {
	    			 ImageIcon icon = new ImageIcon("images/ant.gif");
      				JOptionPane.showMessageDialog(null,
      					helpstring, "Help",
				    	JOptionPane.INFORMATION_MESSAGE, icon);
    		}});
    		info.add(help);
    		MenuItem about = new MenuItem("About");
    		about.addActionListener(new ActionListener() {
    			 public void actionPerformed(ActionEvent event) {
	    			ImageIcon icon = new ImageIcon("images/ant.gif");
		 		
      				JOptionPane.showMessageDialog(null, 
      					"Basic ant-based clustering demo \nCopyright (c) Julia Handl, Monash University, 2001", "About", 
				    	JOptionPane.INFORMATION_MESSAGE, icon);
			}});
    		info.add(about);
    		antBar.add(info);

   	   	frame.setMenuBar(antBar);
    		frame.addWindowListener(new WindowCloser()); 
    		frame.pack();
    		frame.setSize(54*7+10, 54*7+48);
    		frame.show();
    		frame.setVisible(true);
  	
              		    			
		} catch (Exception e) {
			System.err.println("Exception in Main Routine");
			System.err.println(e.getMessage());
			System.exit(0);
		}
	}
 

/**************** Equivalent initialisation once some form of data is provided ********************************/

	private static void init(boolean old, String filename) {
		DistanceMatrix d = null;

		keywords = new String[data.getnkeys()];
		documents = new Document[data.getndocs()];
		System.out.println("Keywords: "+ data.getnkeys());
		System.out.println("Documents: "+ data.getndocs());
		
		// store data	
		keywords = data.getKeys();
		documents = data.getDocs();
		configuration.setndocs(data.getndocs());
		configuration.setnkeys(data.getnkeys());
		
		
			
		// remove old maps
		if (map != null) frame.remove(map);
			



		// create the new topic map			
		map = new TopicMap(configuration, keywords, documents, antMode, d);
	
		
		// update frame
		frame.add(map, BorderLayout.CENTER);
		frame.pack();
   	 	frame.setSize(configuration.getxsize()*5+10,configuration.getysize()*5+48);
   	 	frame.show();
		frame.setVisible(true);
	   	init = true;
		if ((antMode == false) || (old == true)) ;
		else new Thread(map).start();
	}
		

 
/************** I/O Functions **********************************************************************/

	/** Save a document collection to disk
	* @param data the provided document collections
	* @param filename the name of the file to write to
	*/
	public static void save(Data data, String filename) {
		try {
			ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(filename));
			output.writeInt(data.getndocs());
			output.writeInt(data.getnkeys());
			output.writeObject(data.getDocs());
			output.writeObject(data.getKeys());

			output.flush();
			output.close();
		} catch (IOException e) {
			System.out.println("Error occured when writing from file " + filename);
			System.out.println(e.getMessage());
		}
		return;
	}

	/** Function to read a document collection from disk
	* @param filename the name of the file to read from
	* @return the loaded document collection
	*/
	public static Data read(String filename) {
		Data data = null;
		Document [] docs;
		String [] keys;
		int ndocs, nkeys;
		try {
			ObjectInputStream input = new ObjectInputStream(new FileInputStream(filename));
			ndocs = input.readInt();
			nkeys = input.readInt();
			docs = (Document [])input.readObject();
			keys = (String [])input.readObject();
			input.close();
			data = new Data(nkeys, ndocs, keys, docs);
		} catch (Exception e) {
			System.out.println("Error occured when reading from file " + filename);
			System.out.println(e.getMessage());
		}
		return data;
	}



/*********** hardcoded generation of artificial data *************************************/

/** Generate the hardcoded data for the test distributions
* @param dist switch between the three possible distributions (0, 1 or 2)
* @return the generated test data
*/
public static Data generate(int dist) {
	int ndocs = 400;
	int nkeys = 2;

	String [] keys = new String[2];
	keys[0] = new String("ycoord");
	keys[1] = new String("xcoord");
		
	Document[] docs = null;

	


	// Hard-coded test distribution (Uniform Distribution)
	if (dist == 1) {

		ndocs = 450;
		docs = new Document[ndocs + nkeys];
		Random generator = new Random();

		Position center[] = new Position[9];
		center[0] = new Position(0, 0);
		center[1] = new Position(0, 8);
		center[2] = new Position(8, 0);
		center[3] = new Position(8, 8);
		center[4] = new Position(0, 16);
		center[5] = new Position(16, 0);
		center[6] = new Position(16, 8);
		center[7] = new Position(8, 16);
		center[8] = new Position(16, 16);
		Position var[] = new Position [10];
		var[0] = new Position(2, 2);
		var[1] = new Position(2, 2);
		var[2] = new Position(2, 2);
		var[3] = new Position(2, 2);
		var[4] = new Position(2, 2);
		var[5] = new Position(2, 2);
		var[6] = new Position(2, 2);
		var[7] = new Position(2, 2);
		var[8] = new Position(2, 2);
				
		double data[] = new double[2];
		Position pos;
		
		// create individual vectors distributed randomly around the given mean
		for (int j=0; j< 50; j++) {
			for (int i = 0; i< 9; i++) {
				data[0] = Math.random() * 4*var[i].getY() + center[i].getY();
				data[1] = Math.random() * 4*var[i].getX() + center[i].getX();
				pos = new Position((int)Math.round(data[0]), (int)Math.round(data[1]));
				docs[j*9+i] = new Document(data, 2, pos, i+1);
			}
		}
		

		
	}
	
	// Hard-coded test distribution (Normal Distribution)
	else if (dist == 0) {
		
	        ndocs = 800;
		nkeys = 2;

		docs = new Document[ndocs + nkeys];
		Random generator = new Random();

		Position center[] = new Position[4];
		center[0] = new Position(0, 0);
		center[1] = new Position(0, 8);
		center[2] = new Position(8, 0);
		center[3] = new Position(8, 8);
		Position var[] = new Position [4];
		var[0] = new Position(2, 2);
		var[1] = new Position(2, 2);
		var[2] = new Position(2, 2);
		var[3] = new Position(2, 2);
	
		double data[] = new double[2];
		Position pos;
		
		for (int i = 0; i< 4; i++) {
			for (int j=0; j< 200 ; j++) {
				data[0] = generator.nextGaussian() * var[i].getY() + center[i].getY();
				data[1] = generator.nextGaussian() * var[i].getX() + center[i].getX();
				pos = new Position((int)Math.round(data[0]), (int)Math.round(data[1]));
				docs[i*200+j] = new Document(data, 2, pos, i+1);

			}
		}



	}

	else if (dist == 2) {

		ndocs = 90;
		nkeys = 20;
		docs = new Document[ndocs+nkeys];
		
		
		keys = new String[nkeys];
		keys[0] = "Computer Graphics";
		keys[1] = "Splines";
		keys[2] = "Mesh";
		keys[3] = "Visualization";
		keys[4] = "Topic Maps";
		keys[5] = "Fisheye Views";
		keys[6] = "Graphs";

		keys[7] = "Artificial Life";
		keys[8] = "Game of Life";
		keys[9] = "Turing";
		keys[10] = "Chaos";
		keys[11] = "Self-organisation";

		keys[12] = "Artificial Intelligence";
		keys[13] = "Bayesian Reasoning";
		keys[14] = "Symbolic";
		keys[15] = "Expert System";
		keys[16] = "Neural Network";
		keys[17] = "Knowledge";
		keys[18] = "Representation";
		keys[19] = "Robot";


		double data[] = new double[nkeys];
			
		for (int j=0; j<ndocs; j++) {
		
			int color = 1;
			if (j < 30) {
				for (int k=0; k<7; k++) {
					data[k] =  (int)Math.floor(3.0+Math.random()*3.0);
				}
				for (int k=7; k<20; k++) {
					data[k] = (int)Math.floor(Math.random()*3.0);
				}
				color = 2;
			}
			else if (j < 60) {
				for (int k=0; k<7; k++) {
					data[k] = (int)Math.floor(Math.random()*3.0);
				}
				for (int k=7; k<12; k++) {
					data[k] = (int)Math.floor(3.0+Math.random()*10.0);
				}
				for (int k=12; k<20; k++) {
					data[k] = (int)Math.floor(Math.random()*3.0);
				}
				color = 3;
			}	
			else {
				for (int k=0; k<12; k++) {
					data[k] = (int)Math.floor(Math.random()*3.0);
				}
				for (int k=12; k<20; k++) {
					data[k] = (int)Math.floor(30.0+Math.random()*5.0);
				}
				color = 4;
			}
		
			docs[j] = new Document(color);
			docs[j].setVector(nkeys, data);
		}


			
		
	}
	return new Data(nkeys, ndocs, keys, docs);
	}

}	


 
       
 
 
    


 
