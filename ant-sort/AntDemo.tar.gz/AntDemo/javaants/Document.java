/*  
    Copyright (C) 2004 Julia Handl
    Email: Julia.Handl@gmx.de

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

/*****************************************************************
	Julia Handl - 18004385
	Monash University, 1.7.2001

	File: Document.java
	Package: JavaAnts

	Description:

	* Represents an individual document
	* Stores all essential information e.g. grid position
                                                                                                                        	
*****************************************************************/

package javaants;

import java.net.*;
import java.lang.*;
import java.util.*;
import java.io.*;

/** Stores the data for an individual document
	using compressed storage format for sparse document vectors
	 */

public class Document implements Serializable {

	public int [] index;		
	public double [] data;

	public int MAXINDEX;

	private boolean isPicked = false;		// flag whether document is just
 								// being transported or not

	private boolean dummy = false;		// marker for dummy keyword vectors
	private int keywordNbr = -1;			// index of represented keywords

	private Position pos;				// position on the grid
	private Position initpos;			// starting position
	private int color = 1;				// colour - used for observations

	
   	private int nkeys = 0;					// dimensionality
	private double [] vector;				// document vector





/*********** Constructor ****************************************************************************/

	/** Default Constructor */
	public Document() {
		
		this.pos = new Position();
		this.initpos = new Position();
	}
	
	

	/** Constructor permitting the specification of document colour */
	public Document(int color) {
		
    	this.color = color;
		this.pos = new Position();
		this.initpos = new Position();
		

	}

	/** Constructor given a pregenerated keyword vector, its size, a grid position and a color */
	public Document(double [] vector, int nkeys, Position pos, int color) {
		int i;
		int j=0;
		int l=0;
	
		this.vector = new double[nkeys];
		System.arraycopy(vector, 0, this.vector, 0, nkeys);
		this.nkeys = nkeys;
		
		this.pos = new Position();
		this.initpos = new Position();
		this.pos.set(pos.getY(), pos.getX());
		this.initpos.set(pos.getY(), pos.getX());
		this.color = color;
	

		for (i=0; i<nkeys; i++) {
			if (vector[i] != 0.0) {	
				l++;
			}
		}
		index = new int[l+1];
		data = new double[l];
		MAXINDEX = nkeys;
		index[l] = MAXINDEX;

		for (i=0; i<nkeys; i++) {
			if (vector[i] != 0.0) {
				index[j] = i;
				data[j] = vector[i];
				j++;
			}
		}


	}


	
	
/********** Distance functions********************************************************************************************/


	/** Euclidean Map-Distance
	* @return the Euclidean distance to another document on the grid
	* @param document the considered document
	* @param ysize the grid height
	* @param xsize the grid width
	*/
	public double currentDistance(Document document, int ysize, int xsize) {
	
		Position pos1, pos2;
		pos1 = this.getPosition();
		pos2 = document.getPosition();
		
		double xdiff = Math.abs(pos1.getX() - pos2.getX());
		xdiff = Math.min(xdiff, xsize-xdiff);
		double ydiff = Math.abs(pos1.getY() - pos2.getY());
		ydiff = Math.min(ydiff, ysize-ydiff);
	
		// Euclidean distance betweeen the two document positions
		return Math.sqrt(xdiff*xdiff + ydiff*ydiff);
	}
	
	

	/** Index of dissimilarity  in document space
	* 
	* @return the distance in document space to another document
	* @param document the considered document
	*/
	
public float distance(Document d, int measure, int mode) {
	
	int i=0;
	int j=0;
	
	double sum = 0.0;


	while (true) {
		while (index[i] < d.index[j]) {
			sum += data[i]*data[i];
			i++;
		}

		if (index[i] == d.index[j]) {
			if (data[i] > d.data[j]) {
				sum += (data[i] - d.data[j])+(data[i] - d.data[j]);
			}
			i++;
			j++;
		}
		if (index[i] == MAXINDEX) break;
	
		while (d.index[j] < index[i]) {
			sum += d.data[j]*d.data[j];
			j++;
		}	
	
		if (index[i] == d.index[j]) {
			if (data[i] > d.data[j]) {
				sum += (data[i] - d.data[j])*(data[i] - d.data[j]);
			}
			i++;
			j++;
		}
		if (d.index[j] == MAXINDEX) break;
	}	
	return (float) Math.sqrt(sum);
}
	
	
	
	
		
/*********** Access & Modification Functions ****************************************************************************/



    	
	/** Determine vector size
	* @return the vector dimension
	*/
	public int getNKeys() {
		return this.nkeys;
	}
	
	/** Determine the vector representation
	* @return the associated document vector
	*/
	public double [] getVector() {
		return this.vector;
	}
	
	/** Determine one coordinate of the vector representation
	* @param index specify coordinate position
	* @return the coordinate at the specified position
	*/
	public double getValue(int index) {
		return this.vector[index];
	} 

	
	/** Determine vector length (dot product)
	* @return the length of the associated document vector
	*/
	public double getSum() {
		double sum = 0;
		for (int i=0; i<nkeys; i++) {
			sum += Math.abs(vector[i]);
		}
		return sum;
	}


    /** Store the associated document vector
	* @param nkeys the size of the document vector
	* @param vector the associated document vector
	*/
	public void setVector(int nkeys, double [] vector) {
		int i;
		int j=0;
		int l = 0;

		this.nkeys = nkeys;
		this.vector = new double[nkeys];
		System.arraycopy(vector, 0, this.vector, 0, nkeys);

		for (i=0; i<nkeys; i++) {
			if (vector[i] != 0.0) {	
				l++;
			}
		}
		index = new int[l+1];
		data = new double[l];
		MAXINDEX = nkeys;
		index[l] = MAXINDEX;

		for (i=0; i<nkeys; i++) {
			if (vector[i] != 0.0) {
				index[j] = i;
				data[j] = vector[i];
				j++;
			}
		}



	}	


	
   

	
/****** document position *********/
		
	/** Get document position
	* @return the current document position on the grid
	*/
	public Position getPosition() {
		return this.pos;
	}
	
	/** Get initial document position
	* @return the starting position of the document on the grid
	*/
	public Position getinitPosition() {
		return this.initpos;
	}
	
	/** Set document position
	* @param pos the current position of the document on the grid
	*/
	public void setPosition(Position pos) {
		this.pos.set(pos.getY(), pos.getX());
	}
	
	/** Set document position
	* @param x the x coordinate of the current position of the document on the grid
	* @param y the y coordinate of the current position of the document on the grid
	*/
	public void setPosition(int y, int x) {
		this.pos.set(y, x);
	}

/******* document colour **********/
		
	/** Set document colour
	* @param color the colour to be attached to this document
	*/
	public void setColor(int color) {
		this.color = color;
	}
	
	/** Get document colour
	* @return the colour attached to this document
	*/
	public int getColor() {
		return this.color;
	}



/******** misc **********************/

	/** Is this document currently being transported by an ant?
	* @return truth value signalising whether document is being transported or not
	*/
	public boolean isPicked() {
		return isPicked;
	}

	/** Set picked flag
	* @param value the new truth value
	*/
	public void setPicked(boolean value) {
		this.isPicked = value;
	}


}
